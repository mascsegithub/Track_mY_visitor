-- phpMyAdmin SQL Dump
-- version 3.5.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 11, 2017 at 12:22 PM
-- Server version: 5.5.25a
-- PHP Version: 5.4.4

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `trackmyvisitor_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `t_authorise_visitor`
--

CREATE TABLE IF NOT EXISTS `t_authorise_visitor` (
  `SpecialVisitorId` bigint(20) NOT NULL AUTO_INCREMENT,
  `SpecialVisitorName` varchar(100) NOT NULL,
  `SpecialVisitorCompany` varchar(100) NOT NULL,
  `EmailAddress` varchar(100) NOT NULL,
  `Phone` varchar(50) NOT NULL,
  `EmployeeId` int(11) NOT NULL,
  `AppointmentDate` date NOT NULL,
  `QRAttachment` varchar(225) DEFAULT NULL,
  `EventId` int(11) NOT NULL,
  `VisitorImage` varchar(225) DEFAULT NULL,
  `VisitorTypeId` int(11) NOT NULL,
  PRIMARY KEY (`SpecialVisitorId`),
  KEY `FK_AuthorizeVisitor_Employee` (`EmployeeId`),
  KEY `FK_AuthorizeVisitor_Event` (`EventId`),
  KEY `FK_AuthorizeVisitor_VisitorType` (`VisitorTypeId`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=23 ;

--
-- Dumping data for table `t_authorise_visitor`
--

INSERT INTO `t_authorise_visitor` (`SpecialVisitorId`, `SpecialVisitorName`, `SpecialVisitorCompany`, `EmailAddress`, `Phone`, `EmployeeId`, `AppointmentDate`, `QRAttachment`, `EventId`, `VisitorImage`, `VisitorTypeId`) VALUES
(17, 'Abdus Salam', 'Career Soft', 'nurulkabissr@yahoo.com', '01924663946', 138, '2017-01-11', '17_138_1484478407.png', 23, '80_abdus_salam.jpg', 1),
(20, 'Nazim mahmud', 'Softworks', 'nazims1.ma@gmail.com', '01721624499', 137, '2017-01-11', '20_137_1484478294.png', 24, 'n.png', 1),
(21, 'Rubel Mia', 'NESM', 'nurulkabissrf@yahoo.com', '01715010789', 121, '2017-01-14', '21_121_1484728112.png', 24, '1.png', 1),
(22, 'আব্দুস সালাম', 'কারিয়ার ', 'nazims1.mas@gmail.com', '০১৯২৪৬৬৩৯৪৮', 181, '2017-01-18', '22_181_1484722503.png', 27, 'n.png', 131);

-- --------------------------------------------------------

--
-- Table structure for table `t_company`
--

CREATE TABLE IF NOT EXISTS `t_company` (
  `CompanyId` int(11) NOT NULL AUTO_INCREMENT,
  `CompanyName` varchar(100) DEFAULT NULL,
  `api_key` varchar(100) NOT NULL,
  `CompanyImage` varchar(255) DEFAULT NULL,
  `LangCode` varchar(50) NOT NULL DEFAULT 'en',
  `LanguageAdded` text NOT NULL,
  `TimeZoneId` varchar(100) NOT NULL DEFAULT 'Asia/Dhaka',
  PRIMARY KEY (`CompanyId`),
  UNIQUE KEY `CompanyName` (`CompanyName`),
  KEY `TimeZoneId` (`TimeZoneId`),
  KEY `LangCode` (`LangCode`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=225 ;

--
-- Dumping data for table `t_company`
--

INSERT INTO `t_company` (`CompanyId`, `CompanyName`, `api_key`, `CompanyImage`, `LangCode`, `LanguageAdded`, `TimeZoneId`) VALUES
(112, 'Softworks', '8c13e3f9fa542d9f46b3c4146cbead93', 'softworks_logo_for_facebook.png', 'en', '', 'Asia/Dhaka'),
(156, 'uTech', 'a44245b615bc4a489d03c35dfb9de604', 'com.gif', 'en', '', 'Asia/Dhaka'),
(158, 'Simpro', '8591e00c4e7f3d2c1cdf94080c6db90a', NULL, 'en', '', 'Asia/Dhaka'),
(159, 'hdhdj', '3b1f1b773236d829164fbfa21ef940c3', NULL, 'en', '', 'Asia/Dhaka'),
(164, 'SoftWorks Ltd.', 'ecfd978aaf543f1c08ba693c1eb057d9', 'envoy_logo.png', 'bn', '[{"LangCode":"bn","LangTitle":"Bengali/Bangla"},{"LangCode":"en","LangTitle":"English"},{"LangCode":"fr","LangTitle":"French"}]', 'Asia/Dhaka'),
(167, 'AMARCOMPANY2', '0fa8f8e8b417fc4a74cfdcc5aa19fb57', NULL, 'en', '', 'Asia/Dhaka'),
(168, 'S Special', '5d04ccd1f086d4ae32195658b95b668c', NULL, 'en', '', 'Asia/Dhaka'),
(169, 'DhakaIT Bd', '09f61a4467d0ad720c5a3d1089118b75', 'index.png', 'en', '', 'Asia/Dhaka'),
(173, 'SW', 'c97b32e0ed44b19e93f429a28305e261', 'Intel_swoosh_logo_300x198.jpg', 'en', '', 'Asia/Dhaka'),
(184, 'Niceit', '9ede6dce9d92f023088ce5772c8c89ae', 'index.png', 'en', '', 'Asia/Dhaka'),
(185, 'ddd', '603a492fc3674c95c62823dd01d261b4', NULL, 'en', '', 'Asia/Dhaka'),
(186, 'Softworksbd', 'b730868240b6362629af64d8f973e3c4', NULL, 'en', '', 'Asia/Dhaka'),
(188, 'AMARCOMPANY', 'e303f3919bdb304e6b136f291b3697f4', NULL, 'en', '', 'Asia/Dhaka'),
(189, 'Soft', '5e5ccfd4016bbbc6ede38365b8c1a7f1', NULL, 'en', '', 'Asia/Dhaka'),
(190, 'CRDA', '31655302172e5471b466a518047ef429', NULL, 'en', '', 'Asia/Dhaka'),
(191, 'Kdjdj', '14e3135df8ac98a3b875bb6c6a7dbf97', NULL, 'en', '', 'Asia/Dhaka'),
(192, 'Rx71 Limited', 'fbacc807319fb93a81beeb66650491ba', NULL, 'en', '', 'Asia/Dhaka'),
(193, '15666666666', '06716a114d7d02caaacf1476cb37bf92', NULL, 'en', '', 'Asia/Dhaka'),
(194, 'IISD-ELA', 'a29ef47eba711a5a77d43872fe15d5c2', NULL, 'en', '', 'Asia/Dhaka'),
(195, 'Sheworks', '12e6f1eda78e12f7ad776b05c1dfdf3d', NULL, 'en', '', 'Asia/Dhaka'),
(196, 'Soft Ltd', '4bc0ab6246f7a6af7e73266a5dfb2209', NULL, 'en', '', 'Asia/Dhaka'),
(197, 'Aglos Office', '1b14249db24e88318d438afa29835db5', NULL, 'en', '', 'Asia/Dhaka'),
(198, ' GQUYP  *Vg', 'f45a4b49552e85a9370a8d056fba7a14', NULL, 'en', '', 'Asia/Dhaka'),
(199, 'Kp', 'd8fdfb520d9655194e6bef08f3e1b97d', NULL, 'en', '', 'Asia/Dhaka'),
(200, 'Dhaka Bank', '7fcfaca6e5fbfef8aef677136e5a2c92', NULL, 'fr', '', 'Asia/Amman'),
(201, 'New Company', '9b3ddc6b343a31077ab8ef00a438d062', NULL, 'fr', '', 'Asia/Dhaka'),
(202, 's.s', 'efaa05d47921a1abb2564ee1fbffd001', NULL, 'fr', '', 'Asia/Dhaka'),
(203, 'test2 C', 'f72e226c543cc1994da6996cfa77343a', NULL, 'fr', '', 'Asia/Dhaka'),
(204, 'test2 Cs', 'd04fd8692985c25b8853c6bbe62891b1', NULL, 'fr', '', 'Asia/Dhaka'),
(205, 'test2 com', '2e28d36350f357b63e8caf041d404566', NULL, 'fr', '', 'Asia/Dhaka'),
(206, 'Auto Soft', 'cc08994d37280ce837634c6fb8cb45b6', NULL, 'fr', '', 'Asia/Dhaka'),
(207, 'fixed soft', '08e49b2650c003e261d97c3a5bf2ab76', NULL, 'fr', '', 'Asia/Dhaka'),
(209, 'faisal it', '74f58e51f204870d919ba0dae06443f7', 'index1.png', 'fr', '', 'Asia/Dhaka'),
(220, 'Robi ltd.', 'f1162566d28c8ac6910ecdac1e03319a', '', 'en', '', 'Asia/Dhaka'),
(221, 'SoftWorks Ltd BD.', 'bed81f40b2a3397d10da84b8e698d666', '', 'en', '', 'Asia/Dhaka'),
(222, 'S Soft', '91b5a0db9e8990befde17e52e197998c', NULL, 'en', '', 'Asia/Dhaka'),
(223, 'SS SOFT', '419ef4036fc982bc876ac2180ba8a84b', NULL, 'en', '', 'Asia/Dhaka'),
(224, 'ss SS', '0233f4187f8c2db682a669aea941cb0b', NULL, 'en', '', 'Asia/Dhaka');

-- --------------------------------------------------------

--
-- Table structure for table `t_division`
--

CREATE TABLE IF NOT EXISTS `t_division` (
  `DivisionId` tinyint(4) NOT NULL AUTO_INCREMENT,
  `DivisionName` varchar(100) DEFAULT NULL,
  `SiteId` int(11) DEFAULT NULL,
  PRIMARY KEY (`DivisionId`),
  KEY `FK_Division_Site` (`SiteId`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=75 ;

--
-- Dumping data for table `t_division`
--

INSERT INTO `t_division` (`DivisionId`, `DivisionName`, `SiteId`) VALUES
(1, 'Software Development', 122),
(2, 'Administration', 122),
(9, 'Accounts', 122),
(14, 'Administration', 116),
(16, 'Administration', 118),
(20, 'Administration', 122),
(23, 'Administration', 125),
(24, 'Administration', 127),
(25, 'Administration', 127),
(26, 'Administration', 127),
(27, 'Administration', 127),
(28, 'Procurements', 122),
(29, 'Costing Deparment', 122),
(30, 'Human Resource', 122),
(31, 'Finance', 122),
(32, 'Software Support', 122),
(33, 'Research and Development', 122),
(34, 'Odit', 122),
(35, 'Administration', 132),
(36, 'Administration', 133),
(38, 'Administration', 135),
(39, 'Administration', 136),
(40, 'Administration', 139),
(41, 'Administration', 140),
(42, 'Administration', 141),
(43, 'Administration', 142),
(44, 'Administration', 143),
(45, 'Administration', 144),
(46, 'Administration', 145),
(47, 'Administration', 146),
(48, 'Administration', 147),
(49, 'Administration', 148),
(50, 'Administration', 149),
(51, 'Administration', 150),
(52, 'Administration', 151),
(53, 'Administration', 152),
(54, 'Administration', 153),
(55, 'Administration', 154),
(56, 'Administration', 155),
(57, 'Administration', 156),
(59, 'Administration', 158),
(70, 'Administration', 169),
(71, 'Administration', 170),
(74, 'Administration', 171);

-- --------------------------------------------------------

--
-- Table structure for table `t_employee`
--

CREATE TABLE IF NOT EXISTS `t_employee` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `FirstName` varchar(25) NOT NULL,
  `LastName` varchar(25) NOT NULL,
  `UserName` varchar(100) NOT NULL,
  `FullName` varchar(100) DEFAULT NULL,
  `EmailAddress` varchar(100) NOT NULL,
  `JobTitle` varchar(100) DEFAULT NULL,
  `MobileNo` varchar(50) DEFAULT NULL,
  `DeskPhoneNo` varchar(50) DEFAULT NULL,
  `Password` varchar(100) NOT NULL,
  `Block` tinyint(1) DEFAULT '0',
  `Activation` tinyint(1) DEFAULT '1',
  `IsHost` tinyint(1) DEFAULT '1' COMMENT 'Pin to ''Host selection'' screen',
  `IsSiteAdmin` tinyint(1) DEFAULT '0',
  `IsCompanyAdmin` tinyint(1) DEFAULT '0',
  `SendEmail` tinyint(1) DEFAULT '1' COMMENT 'Send ''Welcome'' email',
  `CountryName` varchar(50) DEFAULT NULL,
  `CompanyId` int(11) DEFAULT NULL,
  `SiteId` int(11) DEFAULT NULL COMMENT 'Can be visited at',
  `DivisionId` tinyint(3) DEFAULT NULL,
  `RegisterDate` datetime DEFAULT NULL,
  `LastVisitDate` datetime DEFAULT NULL,
  `EmployeeImage` varchar(255) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `FK_Employee_Company` (`CompanyId`),
  KEY `FK_Employee_Division` (`DivisionId`),
  KEY `FK_Employee_Site` (`SiteId`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=185 ;

--
-- Dumping data for table `t_employee`
--

INSERT INTO `t_employee` (`Id`, `FirstName`, `LastName`, `UserName`, `FullName`, `EmailAddress`, `JobTitle`, `MobileNo`, `DeskPhoneNo`, `Password`, `Block`, `Activation`, `IsHost`, `IsSiteAdmin`, `IsCompanyAdmin`, `SendEmail`, `CountryName`, `CompanyId`, `SiteId`, `DivisionId`, `RegisterDate`, `LastVisitDate`, `EmployeeImage`) VALUES
(79, 'Nazim', 'Mahmud', 'Nazim', 'Nazim Mahmud', 'nazim1.ma@gmail.com', 'IT Officer ', '5555', '52555 888', '061e744a5b8b9b57b15266af05bbf68b', 0, 1, 1, 1, 1, 1, NULL, 112, 70, 1, NULL, NULL, 'GardenCakes_RobinToste.png'),
(114, 'Anwar', 'Hossain', 'Anwar', 'Anwar Hossain', 's.anwar369@gmail.com', 'Executive', '', '', '202cb962ac59075b964b07152d234b70', 0, 1, 1, 1, 1, 1, NULL, 158, 116, 14, NULL, NULL, 'abrar_jaheen.jpg'),
(116, 'nazim', 'mahmud', 'nazim', 'nazim mahmud', 'nazim1.ma@yahoo.com', NULL, NULL, NULL, '061e744a5b8b9b57b15266af05bbf68b', 0, 1, 1, 1, 1, 1, NULL, 167, 118, 16, NULL, NULL, ''),
(121, 'Mahmudul', 'Islam', 'Mahmudul', 'Mahmudul Islam', 'mahmudmia@yahoo.com', 'IT Admin', '01715010789', '', '8e2036c4740bac0869663e1207a11560', 0, 1, 1, 1, 1, 1, NULL, 164, 122, 1, NULL, NULL, 'Mahmudul_Islam.jpg'),
(128, 'Imran', 'Hasan', 'Imran', 'Imran Hasan', 'hasantarif2@yahoo.com', 'Test Job title', '01709270838', '123456', '', 0, 1, 1, 0, 0, 1, NULL, 112, 70, 2, NULL, NULL, ''),
(132, 'Nazim', 'Mahmud', 'Nazim', 'Nazim Mahmud', 'nazim1.ma@gmail.com', 'Programmer', '01915826995', '01915826995', '', 0, 1, 1, 0, 0, 1, NULL, 164, 122, 1, NULL, NULL, 'n.png'),
(133, 'Imran', 'Hasan', 'Imran', 'Imran Hasan', 'ihtarif@gmail.com', 'Sr. Programmer', '01709270838', '123456', '', 0, 1, 1, 0, 0, 1, NULL, 164, 122, 1, NULL, NULL, 'f_39719.jpg'),
(134, 'Md. Baharul', 'Islam', 'Md. Baharul', 'Md. Baharul Islam', 'rubel28.diit@gmail.com', 'Jr. Programmer', '01718488334', '', '', 0, 1, 1, 0, 0, 1, NULL, 164, 122, 1, NULL, NULL, 'Capture.png'),
(135, 'Sujit Kumar', 'Sen', 'Sujit Kumar', 'Sujit Kumar Sen', 'sujit2j8@gmail.com', 'Sr. Programmer', '01736888310', '01736888310', '', 0, 1, 1, 0, 0, 1, NULL, 164, 122, 1, NULL, NULL, 'Image.JPG'),
(136, 'Mahbub', 'Alam', 'Mahbub', 'Mahbub Alam', 'mahbub86dc@yahoo.com', 'Jr. Programmer', '01620540104', '', '', 0, 1, 1, 0, 0, 1, NULL, 164, 122, 1, NULL, NULL, 'IMG_20131003_204248.jpg'),
(137, 'Rubel', 'Mea', 'Rubel', 'Rubel Mea', 'rubel714@yahoo.com', 'Sr. Programmer', '01921232956', '', '', 0, 1, 1, 0, 0, 1, NULL, 164, 122, 1, NULL, NULL, 'rubel.jpg'),
(138, 'Abdus', 'Salam', 'Abdus', 'Abdus Salam', 'salam.softworkss@gmail.com', 'Jr. Programmer', '01924663948', '', '', 0, 1, 1, 0, 0, 1, NULL, 164, 122, 1, NULL, NULL, '80_abdus_salam.jpg'),
(139, 'Hasan', 'Mahmud', 'Hasan', 'Hasan Mahmud', 'hmahmud70@gmail.com', 'EXECUTIVE DIRECTOR', '01819295651', '', '', 0, 1, 1, 0, 0, 0, NULL, 164, 122, 20, NULL, NULL, 'Hasan_Mahmud.jpg'),
(140, 'Md. Elias', 'Miah', 'Md. Elias', 'Md. Elias Miah', 'eliasparvez@yahoo.com', 'Support Manager', '01682191200', '', '', 0, 1, 1, 0, 0, 1, NULL, 164, 122, 32, NULL, NULL, '17022012.jpg'),
(145, 'Imran', 'Hasan', 'Imran', 'Imran Hasan', 'hasantarif@yahoo.com', NULL, '01959609789', NULL, 'e10adc3949ba59abbe56e057f20f883e', 0, 1, 1, 1, 1, 1, NULL, 188, 135, 38, NULL, NULL, ''),
(147, 'Navya', 'K', 'Navya', 'Navya K', 'likhithanavya.k@apcrda.org', NULL, NULL, NULL, 'f187d836c95f897cfba084d838ecc560', 0, 1, 1, 1, 1, 1, NULL, 190, 139, 40, NULL, NULL, ''),
(148, 'Pankaj', 'Kumar', 'Pankaj', 'Pankaj Kumar', 'pankajuttam99@gmail.com\n', NULL, NULL, NULL, '', 0, 1, 1, 1, 1, 1, NULL, 191, 140, 41, NULL, NULL, ''),
(149, 'Mehedi', 'Hasan', 'Mehedi', 'Mehedi Hasan', 'mehedirandroidapps@gmail.com', NULL, NULL, NULL, '91ec8d992540095dccbaa04a3e5ba55f', 0, 1, 1, 1, 1, 1, NULL, 192, 141, 42, NULL, NULL, ''),
(151, 'Roger', 'Mollot', 'Roger', 'Roger Mollot', 'rmollot@iisd-ela.org', NULL, '2042294755', NULL, '', 0, 1, 1, 1, 1, 1, NULL, 194, 143, 44, NULL, NULL, ''),
(152, 'She', 'Works', 'She', 'She Works', 'sheworks.tri@gmail.com ', NULL, NULL, NULL, '', 0, 1, 1, 1, 1, 1, NULL, 195, 144, 45, NULL, NULL, ''),
(153, 'Nazim', 'Mahmud', 'Nazim', 'Nazim Mahmud', 'nazimmahmud83@gmail.com', 'Programmer', '01915826995', '01915826995', '061e744a5b8b9b57b15266af05bbf68b', 0, 1, 1, 1, 1, 1, NULL, 196, 145, 46, NULL, NULL, ''),
(154, 'Bail', 'Hardisty', 'Bail', 'Bail Hardisty', 'baileyedisonhardisty@gmail.com\n', NULL, NULL, NULL, '', 0, 1, 1, 1, 1, 1, NULL, 197, 146, 47, NULL, NULL, ''),
(156, 'Sudipto', 'Mukherjee', 'Sudipto', 'Sudipto Mukherjee', 'sudipto.pri@gmail.com', NULL, NULL, NULL, '', 0, 1, 1, 1, 1, 1, NULL, 199, 148, 49, NULL, NULL, ''),
(157, 'Anwar', 'Hossain', 'Anwar', 'Anwar Hossain', 'anwarcs36@yahoo.com', 'Manager Software Development', '01721624499', '', '', 0, 1, 1, 0, 0, 1, NULL, 164, 122, 1, NULL, NULL, 'anwar_02.jpg'),
(158, 'Sarifuddin ', 'Ahmed', 'Sarifuddin ', 'Sarifuddin  Ahmed', 'sharif@gmail.com', NULL, '01924663948', NULL, '', 0, 1, 1, 1, 1, 1, NULL, 200, 149, 50, NULL, NULL, ''),
(160, 'S A', 'MAS', 'S A', 'S A MAS', 'mas@gmail.com', NULL, '1924663556', NULL, '', 0, 1, 1, 1, 1, 1, NULL, 202, 151, 52, NULL, NULL, ''),
(167, 'Al', 'Amin', 'Al', 'Al Amin', 'al_a@gmail.com', NULL, '1924668848', NULL, '05c1378567147d85edbd9155be15fbe9', 0, 1, 1, 1, 1, 1, NULL, 207, 156, 57, NULL, NULL, ''),
(169, 'Faisal ', 'Iqbal', 'Faisal ', 'Faisal  Iqbal', 'faisal@gmail.com', 'Programmer', '01995628344', '', '05c1378567147d85edbd9155be15fbe9', 0, 1, 1, 1, 1, 1, NULL, 209, 158, 59, NULL, NULL, 'em.jpg'),
(180, 'Kobir', 'Mia', 'Kobir', 'Kobir Mia', 'kobir@gmail.com', NULL, '0185545845854', NULL, '4355e4e97c1f49d7d432b5aa00899989', 0, 1, 1, 1, 1, 1, NULL, 220, 169, 70, NULL, NULL, ''),
(181, 'Abdus', 'Salam', 'Abdus', 'Abdus Salam', 'salam.softworks@gmail.com', NULL, '01924663948', NULL, '3f1e21d141600bd212f4387ebf5a218f', 0, 1, 1, 1, 1, 1, NULL, 221, 170, 71, NULL, NULL, ''),
(184, 'Salman  ', 'Sakib', 'Salman  ', 'Salman   Sakib', 'salam.pustcse@gmail.com', NULL, '01924663556', NULL, '3f1e21d141600bd212f4387ebf5a218f', 0, 1, 1, 1, 1, 1, NULL, 224, 171, 74, NULL, NULL, '');

-- --------------------------------------------------------

--
-- Table structure for table `t_event`
--

CREATE TABLE IF NOT EXISTS `t_event` (
  `EventId` int(11) NOT NULL AUTO_INCREMENT,
  `EventName` varchar(300) NOT NULL,
  `EventDate` varchar(150) NOT NULL,
  `CompanyId` int(11) NOT NULL,
  PRIMARY KEY (`EventId`),
  KEY `FK_Event_Company` (`CompanyId`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=28 ;

--
-- Dumping data for table `t_event`
--

INSERT INTO `t_event` (`EventId`, `EventName`, `EventDate`, `CompanyId`) VALUES
(23, 'Event 2', '11th Jan Meeting', 164),
(24, 'Event1', '8th Jan meeting for 1 day', 164),
(25, 'Event112', '15 th jan', 209),
(26, 'Event 2', '11th Jan Meeting', 220),
(27, '২০ জানুয়ারী মিতিং ', '২০.০১.১৭', 221);

-- --------------------------------------------------------

--
-- Table structure for table `t_language`
--

CREATE TABLE IF NOT EXISTS `t_language` (
  `LangCode` varchar(50) NOT NULL,
  `LangTitle` varchar(50) NOT NULL,
  `BActive` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`LangCode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `t_language`
--

INSERT INTO `t_language` (`LangCode`, `LangTitle`, `BActive`) VALUES
('aa', 'Afar', 0),
('ab', 'Abkhazian', 0),
('af', 'Afrikaans', 0),
('am', 'Amharic', 0),
('ar', 'Arabic', 0),
('as', 'Assamese', 0),
('ay', 'Aymara', 0),
('az', 'Azerbaijani', 0),
('ba', 'Bashkir', 0),
('be', 'Belarusian', 0),
('bg', 'Bulgarian', 0),
('bh', 'Bihari', 0),
('bi', 'Bislama', 0),
('bn', 'Bengali/Bangla', 1),
('bo', 'Tibetan', 0),
('br', 'Breton', 0),
('ca', 'Catalan', 0),
('co', 'Corsican', 0),
('cs', 'Czech', 0),
('cy', 'Welsh', 0),
('da', 'Danish', 0),
('de', 'German', 0),
('dz', 'Bhutani', 0),
('el', 'Greek', 0),
('en', 'English', 1),
('eo', 'Esperanto', 0),
('es', 'Spanish', 0),
('et', 'Estonian', 0),
('eu', 'Basque', 0),
('fa', 'Persian', 0),
('fi', 'Finnish', 0),
('fj', 'Fiji', 0),
('fo', 'Faeroese', 0),
('fr', 'French', 1),
('fy', 'Frisian', 0),
('ga', 'Irish', 0),
('gd', 'Scots/Gaelic', 0),
('gl', 'Galician', 0),
('gn', 'Guarani', 0),
('gu', 'Gujarati', 0),
('ha', 'Hausa', 0),
('hi', 'Hindi', 0),
('hr', 'Croatian', 0),
('hu', 'Hungarian', 0),
('hy', 'Armenian', 0),
('ia', 'Interlingua', 0),
('ie', 'Interlingue', 0),
('ik', 'Inupiak', 0),
('in', 'Indonesian', 0),
('is', 'Icelandic', 0),
('it', 'Italian', 0),
('iw', 'Hebrew', 0),
('ja', 'Japanese', 0),
('ji', 'Yiddish', 0),
('jw', 'Javanese', 0),
('ka', 'Georgian', 0),
('kk', 'Kazakh', 0),
('kl', 'Greenlandic', 0),
('km', 'Cambodian', 0),
('kn', 'Kannada', 0),
('ko', 'Korean', 0),
('ks', 'Kashmiri', 0),
('ku', 'Kurdish', 0),
('ky', 'Kirghiz', 0),
('la', 'Latin', 0),
('ln', 'Lingala', 0),
('lo', 'Laothian', 0),
('lt', 'Lithuanian', 0),
('lv', 'Latvian/Lettish', 0),
('mg', 'Malagasy', 0),
('mi', 'Maori', 0),
('mk', 'Macedonian', 0),
('ml', 'Malayalam', 0),
('mn', 'Mongolian', 0),
('mo', 'Moldavian', 0),
('mr', 'Marathi', 0),
('ms', 'Malay', 0),
('mt', 'Maltese', 0),
('my', 'Burmese', 0),
('na', 'Nauru', 0),
('ne', 'Nepali', 0),
('nl', 'Dutch', 0),
('no', 'Norwegian', 0),
('oc', 'Occitan', 0),
('om', '(Afan)/Oromoor/Oriya', 0),
('pa', 'Punjabi', 0),
('pl', 'Polish', 0),
('ps', 'Pashto/Pushto', 0),
('pt', 'Portuguese', 0),
('qu', 'Quechua', 0),
('rm', 'Rhaeto-Romance', 0),
('rn', 'Kirundi', 0),
('ro', 'Romanian', 0),
('ru', 'Russian', 0),
('rw', 'Kinyarwanda', 0),
('sa', 'Sanskrit', 0),
('Sangro', 'sg', 0),
('sd', 'Sindhi', 0),
('sh', 'Serbo-Croatian', 0),
('si', 'Singhalese', 0),
('sk', 'Slovak', 0),
('sl', 'Slovenian', 0),
('sm', 'Samoan', 0),
('sn', 'Shona', 0),
('so', 'Somali', 0),
('sq', 'Albanian', 0),
('sr', 'Serbian', 0),
('ss', 'Siswati', 0),
('st', 'Sesotho', 0),
('su', 'Sundanese', 0),
('sv', 'Swedish', 0),
('sw', 'Swahili', 0),
('ta', 'Tamil', 0),
('te', 'Telugu', 0),
('tg', 'Tajik', 0),
('th', 'Thai', 0),
('ti', 'Tigrinya', 0),
('tk', 'Turkmen', 0),
('tl', 'Tagalog', 0),
('tn', 'Setswana', 0),
('to', 'Tonga', 0),
('tr', 'Turkish', 0),
('ts', 'Tsonga', 0),
('tt', 'Tatar', 0),
('tw', 'Twi', 0),
('uk', 'Ukrainian', 0),
('ur', 'Urdu', 0),
('uz', 'Uzbek', 0),
('vi', 'Vietnamese', 0),
('vo', 'Volapuk', 0),
('wo', 'Wolof', 0),
('xh', 'Xhosa', 0),
('yo', 'Yoruba', 0),
('zh', 'Chinese', 0),
('zu', 'Zulu', 0);

-- --------------------------------------------------------

--
-- Table structure for table `t_language_text`
--

CREATE TABLE IF NOT EXISTS `t_language_text` (
  `LangCode` varchar(50) NOT NULL,
  `LangTextName` varchar(200) NOT NULL,
  `LangText` text NOT NULL,
  `CompanyId` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `t_language_text`
--

INSERT INTO `t_language_text` (`LangCode`, `LangTextName`, `LangText`, `CompanyId`) VALUES
('en', 'MY_VISITOR', 'Track My Visitor', 164),
('en', 'WELCOME', 'Welcome', 164),
('en', 'TOUCH_TO_START', 'Tap anywhere to start', 164),
('en', 'HOW_MAY_I_HELP_YOU', 'Choose your visit purpose', 164),
('en', 'VISITOR_TYPE', 'Visitor Type', 164),
('en', 'I_WANT_TO_SIGN_OUT', 'Sign me out', 164),
('en', 'QR_CODE', 'QR Code', 164),
('en', 'TELL_ABOUT_YOURSELF', 'Tell about yourself', 164),
('en', 'VISITOR_NAME', 'Name', 164),
('en', 'VISITOR_COMPANY', 'Company', 164),
('en', 'YOU_MUST_FILL_THE_NAME', 'You must fill the name', 164),
('en', 'YOU_MUST_FILL_THE_COMPANY', 'You must fill the company', 164),
('en', 'TAKE_A_PICTURE', 'Take a picture', 164),
('en', 'PLEASE_LOOK_AT_THE_SCREEN_FOR_5_SECONDS', 'Please look at the screen for 5 seconds', 164),
('en', 'YOUR_SELECTED_PICTURE', 'It''s your selected picture', 164),
('en', 'TAKE_PICTURE_AGAIN', 'Take snap again', 164),
('en', 'WHO_ARE_YOU_VISITING', 'Who are you visiting?', 164),
('en', 'NAME_OF_HOST', 'Please type in name of person you are visiting', 164),
('en', 'IS_EVERYTHING_CORRECT', 'Is everything correct?', 164),
('en', 'LOOKS_GOOD_TO_GO', 'Looks good to go', 164),
('en', 'SIGNING_OUT', 'Signing out', 164),
('en', 'PLEASE_TYPE_YOUR_NAME_FOR_LOGGING_OUT', 'Please type your name for logging out', 164),
('en', 'YOU_HAVE_SIGNED_OUT_THANKS_FOR_VISITING_US', 'You have signed out. Thanks for visiting us.', 164),
('en', 'CONNECTING_YOUR_HOST', 'Connecting your host.......', 164),
('en', 'POSTING_YOUR_INFORMATION', 'Posting your information to server', 164),
('en', 'EMAIL', 'Email', 164),
('en', 'PASSWORD', 'Password', 164),
('en', 'LOGIN', 'Login', 164),
('en', 'SIGN_IN', 'Sign In', 164),
('fr', 'MY_VISITOR', 'Suivre mon visiteur', 164),
('fr', 'WELCOME', 'Bienvenue', 164),
('fr', 'TOUCH_TO_START', 'Appuyez n''importe où pour commencer', 164),
('fr', 'HOW_MAY_I_HELP_YOU', 'Choisissez le but de votre visite', 164),
('fr', 'VISITOR_TYPE', 'Visitor Type', 164),
('fr', 'I_WANT_TO_SIGN_OUT', 'Sign me out', 164),
('fr', 'QR_CODE', 'QR Code', 164),
('fr', 'TELL_ABOUT_YOURSELF', 'Tell about yourself', 164),
('fr', 'VISITOR_NAME', 'Name', 164),
('fr', 'VISITOR_COMPANY', 'Company', 164),
('fr', 'YOU_MUST_FILL_THE_NAME', 'You must fill the name', 164),
('fr', 'YOU_MUST_FILL_THE_COMPANY', 'You must fill the company', 164),
('fr', 'TAKE_A_PICTURE', 'Take a picture', 164),
('fr', 'PLEASE_LOOK_AT_THE_SCREEN_FOR_5_SECONDS', 'Please look at the screen for 5 seconds', 164),
('fr', 'YOUR_SELECTED_PICTURE', 'It''s your selected picture', 164),
('fr', 'TAKE_PICTURE_AGAIN', 'Take snap again', 164),
('fr', 'WHO_ARE_YOU_VISITING', 'Who are you visiting?', 164),
('fr', 'NAME_OF_HOST', 'Please type in name of person you are visiting', 164),
('fr', 'IS_EVERYTHING_CORRECT', 'Is everything correct?', 164),
('fr', 'LOOKS_GOOD_TO_GO', 'Looks good to go', 164),
('fr', 'SIGNING_OUT', 'Signing out', 164),
('fr', 'PLEASE_TYPE_YOUR_NAME_FOR_LOGGING_OUT', 'Please type your name for logging out', 164),
('fr', 'YOU_HAVE_SIGNED_OUT_THANKS_FOR_VISITING_US', 'You have signed out. Thanks for visiting us.', 164),
('fr', 'CONNECTING_YOUR_HOST', 'Connecting your host.......', 164),
('fr', 'POSTING_YOUR_INFORMATION', 'Posting your information to server', 164),
('fr', 'EMAIL', 'Email', 164),
('fr', 'PASSWORD', 'Password', 164),
('fr', 'LOGIN', 'Login', 164),
('fr', 'SIGN_IN', 'Sign In', 164),
('bn', 'MY_VISITOR', 'ট্র্যাক মাই ভিজিটর', 164),
('bn', 'WELCOME', 'স্বাগতম', 164),
('bn', 'TOUCH_TO_START', 'শুরু করার জন্য স্পর্শ করুন ', 164),
('bn', 'HOW_MAY_I_HELP_YOU', 'আপনাকে  কিভাবে সাহায্য করতে পারি ?', 164),
('bn', 'VISITOR_TYPE', 'ভিজিটরের প্রকার', 164),
('bn', 'I_WANT_TO_SIGN_OUT', 'আমি সাইন আউট করতে চাই', 164),
('bn', 'QR_CODE', 'QR Code', 164),
('bn', 'TELL_ABOUT_YOURSELF', 'নিজের সম্পর্কে বলুন', 164),
('bn', 'VISITOR_NAME', 'নাম ', 164),
('bn', 'VISITOR_COMPANY', 'কোম্পানি', 164),
('bn', 'YOU_MUST_FILL_THE_NAME', 'আপনাকে  নাম পূরণ করতে হবে', 164),
('bn', 'YOU_MUST_FILL_THE_COMPANY', 'আপনাকে  কোম্পানি নাম পূরণ করতে হবে', 164),
('bn', 'TAKE_A_PICTURE', 'একটি ছবি তুলুন ', 164),
('bn', 'PLEASE_LOOK_AT_THE_SCREEN_FOR_5_SECONDS', 'দয়া করে 5 সেকেন্ডের জন্য স্ক্রীন দিকে তাকান', 164),
('bn', 'YOUR_SELECTED_PICTURE', 'এটা আপনার নির্বাচিত ছবি', 164),
('bn', 'TAKE_PICTURE_AGAIN', 'ছবি আবার তুলুন ', 164),
('bn', 'WHO_ARE_YOU_VISITING', 'আপনি  কার কাছে  যাবেন ?', 164),
('bn', 'PLEASE_TYPE_YOUR_NAME_FOR_LOGGING_OUT', 'কার কাছে আপনি পরিদর্শন  করতে এসেছেন তার নাম লেখুন', 164),
('bn', 'IS_EVERYTHING_CORRECT', 'সবকিছু কি সঠিক?', 164),
('bn', 'LOOKS_GOOD_TO_GO', 'দেখতে ভাল  লাগছে , সাবমিট করুন ', 164),
('bn', 'SIGNING_OUT', 'সাইন আউট করা হচ্ছে', 164),
('bn', 'PLEASE_TYPE_YOUR_NAME_FOR_LOGGING_OUT', 'লগ আউট করার জন্য আপনার নাম টাইপ করুন', 164),
('bn', 'YOU_HAVE_SIGNED_OUT_THANKS_FOR_VISITING_US', 'আপনি সাইন আউট করেছেন. আমাদের পরিদর্শন করার জন্য ধন্যবাদ.', 164),
('bn', 'CONNECTING_YOUR_HOST', 'আপনার হোস্ট সংযুক্ত হচ্ছে.......', 164),
('bn', 'POSTING_YOUR_INFORMATION', 'সার্ভারে আপনার তথ্য পোস্টিং হচ্ছে', 164),
('bn', 'EMAIL', 'ইমেইল', 164),
('bn', 'PASSWORD', 'পাসওয়ার্ড', 164),
('bn', 'LOGIN', 'লগইন', 164),
('bn', 'SIGN_IN', 'প্রবেশ  করুন ', 164),
('bn', 'NAME_OF_HOST', 'আপনি  কার কাছে যাবেন তার নাম লিখুন', 164),
('en', 'SCAN_YOUR_QR_CODE', 'Please scan your QR code', 164),
('bn', 'SCAN_YOUR_QR_CODE', 'দয়াকরে আপনার QR কোড স্ক্যান করুন', 164),
('fr', 'SCAN_YOUR_QR_CODE', 'Veuillez analyser votre code QR', 164);

-- --------------------------------------------------------

--
-- Table structure for table `t_setting_language_string`
--

CREATE TABLE IF NOT EXISTS `t_setting_language_string` (
  `LangCode` varchar(50) NOT NULL,
  `LangTextName` varchar(200) NOT NULL,
  `LangText` text NOT NULL,
  KEY `LangCode` (`LangCode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `t_setting_language_string`
--

INSERT INTO `t_setting_language_string` (`LangCode`, `LangTextName`, `LangText`) VALUES
('en', 'MY_VISITOR', 'Track My Visitor'),
('en', 'WELCOME', 'Welcome'),
('en', 'TOUCH_TO_START', 'Tap anywhere to start'),
('en', 'HOW_MAY_I_HELP_YOU', 'Choose your visit purpose'),
('en', 'VISITOR_TYPE', 'Visitor Type'),
('en', 'I_WANT_TO_SIGN_OUT', 'Sign me out'),
('en', 'QR_CODE', 'QR Code'),
('en', 'TELL_ABOUT_YOURSELF', 'Tell about yourself'),
('en', 'VISITOR_NAME', 'Name'),
('en', 'VISITOR_COMPANY', 'Company'),
('en', 'YOU_MUST_FILL_THE_NAME', 'You must fill the name'),
('en', 'YOU_MUST_FILL_THE_COMPANY', 'You must fill the company'),
('en', 'TAKE_A_PICTURE', 'Take a picture'),
('en', 'PLEASE_LOOK_AT_THE_SCREEN_FOR_5_SECONDS', 'Please look at the screen for 5 seconds'),
('en', 'YOUR_SELECTED_PICTURE', 'It''s your selected picture'),
('en', 'TAKE_PICTURE_AGAIN', 'Take snap again'),
('en', 'WHO_ARE_YOU_VISITING', 'Who are you visiting?'),
('en', 'NAME_OF_HOST', 'Please type in name of person you are visiting'),
('en', 'IS_EVERYTHING_CORRECT', 'Is everything correct?'),
('en', 'LOOKS_GOOD_TO_GO', 'Looks good to go'),
('en', 'SIGNING_OUT', 'Signing out'),
('en', 'PLEASE_TYPE_YOUR_NAME_FOR_LOGGING_OUT', 'Please type your name for logging out'),
('en', 'YOU_HAVE_SIGNED_OUT_THANKS_FOR_VISITING_US', 'You have signed out. Thanks for visiting us.'),
('en', 'CONNECTING_YOUR_HOST', 'Connecting your host.......'),
('en', 'POSTING_YOUR_INFORMATION', 'Posting your information to server'),
('en', 'EMAIL', 'Email'),
('en', 'PASSWORD', 'Password'),
('en', 'LOGIN', 'Login'),
('en', 'SIGN_IN', 'Sign In'),
('bn', 'MY_VISITOR', 'ট্র্যাক মাই ভিজিটর'),
('bn', 'WELCOME', 'স্বাগতম'),
('bn', 'TOUCH_TO_START', 'শুরু করার জন্য স্পর্শ করুন '),
('bn', 'HOW_MAY_I_HELP_YOU', 'আপনাকে  কিভাবে সাহায্য করতে পারি ?'),
('bn', 'VISITOR_TYPE', 'ভিজিটরের প্রকার'),
('bn', 'I_WANT_TO_SIGN_OUT', 'আমি সাইন আউট করতে চাই'),
('bn', 'QR_CODE', 'QR Code'),
('bn', 'TELL_ABOUT_YOURSELF', 'নিজের সম্পর্কে বলুন'),
('bn', 'VISITOR_NAME', 'নাম '),
('bn', 'VISITOR_COMPANY', 'কোম্পানি'),
('bn', 'YOU_MUST_FILL_THE_NAME', 'আপনাকে  নাম পূরণ করতে হবে'),
('bn', 'YOU_MUST_FILL_THE_COMPANY', 'আপনাকে  কোম্পানি নাম পূরণ করতে হবে'),
('bn', 'TAKE_A_PICTURE', 'একটি ছবি তুলুন '),
('bn', 'PLEASE_LOOK_AT_THE_SCREEN_FOR_5_SECONDS', 'দয়া করে 5 সেকেন্ডের জন্য স্ক্রীন দিকে তাকান'),
('bn', 'YOUR_SELECTED_PICTURE', 'এটা আপনার নির্বাচিত ছবি'),
('bn', 'TAKE_PICTURE_AGAIN', 'ছবি আবার তুলুন '),
('bn', 'WHO_ARE_YOU_VISITING', 'আপনি  কার কাছে  যাবেন ?'),
('bn', 'PLEASE_TYPE_YOUR_NAME_FOR_LOGGING_OUT', 'কার কাছে আপনি পরিদর্শন  করতে এসেছেন তার নাম লেখুন'),
('bn', 'IS_EVERYTHING_CORRECT', 'সবকিছু কি সঠিক?'),
('bn', 'LOOKS_GOOD_TO_GO', 'দেখতে ভাল  লাগছে , সাবমিট করুন '),
('bn', 'SIGNING_OUT', 'সাইন আউট করা হচ্ছে'),
('bn', 'PLEASE_TYPE_YOUR_NAME_FOR_LOGGING_OUT', 'লগ আউট করার জন্য আপনার নাম টাইপ করুন'),
('bn', 'YOU_HAVE_SIGNED_OUT_THANKS_FOR_VISITING_US', 'আপনি সাইন আউট করেছেন. আমাদের পরিদর্শন করার জন্য ধন্যবাদ.'),
('bn', 'CONNECTING_YOUR_HOST', 'আপনার হোস্ট সংযুক্ত হচ্ছে.......'),
('bn', 'POSTING_YOUR_INFORMATION', 'সার্ভারে আপনার তথ্য পোস্টিং হচ্ছে'),
('bn', 'EMAIL', 'ইমেইল'),
('bn', 'PASSWORD', 'পাসওয়ার্ড'),
('bn', 'LOGIN', 'লগইন'),
('bn', 'SIGN_IN', 'প্রবেশ  করুন '),
('bn', 'NAME_OF_HOST', 'আপনি  কার কাছে যাবেন তার নাম লিখুন'),
('fr', 'MY_VISITOR', 'Track My Visitor'),
('fr', 'WELCOME', 'Welcome'),
('fr', 'TOUCH_TO_START', 'Tap anywhere to start'),
('fr', 'HOW_MAY_I_HELP_YOU', 'Choose your visit purpose'),
('fr', 'VISITOR_TYPE', 'Visitor Type'),
('fr', 'I_WANT_TO_SIGN_OUT', 'Sign me out'),
('fr', 'QR_CODE', 'QR Code'),
('fr', 'TELL_ABOUT_YOURSELF', 'Tell about yourself'),
('fr', 'VISITOR_NAME', 'Name'),
('fr', 'VISITOR_COMPANY', 'Company'),
('fr', 'YOU_MUST_FILL_THE_NAME', 'You must fill the name'),
('fr', 'YOU_MUST_FILL_THE_COMPANY', 'You must fill the company'),
('fr', 'TAKE_A_PICTURE', 'Take a picture'),
('fr', 'PLEASE_LOOK_AT_THE_SCREEN_FOR_5_SECONDS', 'Please look at the screen for 5 seconds'),
('fr', 'YOUR_SELECTED_PICTURE', 'It''s your selected picture'),
('fr', 'TAKE_PICTURE_AGAIN', 'Take snap again'),
('fr', 'WHO_ARE_YOU_VISITING', 'Who are you visiting?'),
('fr', 'NAME_OF_HOST', 'Please type in name of person you are visiting'),
('fr', 'IS_EVERYTHING_CORRECT', 'Is everything correct?'),
('fr', 'LOOKS_GOOD_TO_GO', 'Looks good to go'),
('fr', 'SIGNING_OUT', 'Signing out'),
('fr', 'PLEASE_TYPE_YOUR_NAME_FOR_LOGGING_OUT', 'Please type your name for logging out'),
('fr', 'YOU_HAVE_SIGNED_OUT_THANKS_FOR_VISITING_US', 'You have signed out. Thanks for visiting us.'),
('fr', 'CONNECTING_YOUR_HOST', 'Connecting your host.......'),
('fr', 'POSTING_YOUR_INFORMATION', 'Posting your information to server'),
('fr', 'EMAIL', 'Email'),
('fr', 'PASSWORD', 'Password'),
('fr', 'LOGIN', 'Login'),
('fr', 'SIGN_IN', 'Sign In'),
('en', 'SCAN_YOUR_QR_CODE', 'Please scan your QR code'),
('bn', 'SCAN_YOUR_QR_CODE', 'দয়াকরে আপনার QR কোড স্ক্যান করুন'),
('fr', 'SCAN_YOUR_QR_CODE', 'Veuillez analyser votre code QR');

-- --------------------------------------------------------

--
-- Table structure for table `t_site`
--

CREATE TABLE IF NOT EXISTS `t_site` (
  `SiteId` int(11) NOT NULL AUTO_INCREMENT,
  `SiteName` varchar(100) NOT NULL,
  `StreetAddress` text,
  `EmergencyContact` varchar(50) DEFAULT NULL,
  `SystemAssistantContct` varchar(50) DEFAULT NULL,
  `SiteLogo` varchar(150) DEFAULT NULL,
  `CompanyId` int(11) DEFAULT NULL,
  PRIMARY KEY (`SiteId`),
  KEY `FK_Site_Company` (`CompanyId`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=172 ;

--
-- Dumping data for table `t_site`
--

INSERT INTO `t_site` (`SiteId`, `SiteName`, `StreetAddress`, `EmergencyContact`, `SystemAssistantContct`, `SiteLogo`, `CompanyId`) VALUES
(70, 'Head Office', 'Dhaka', '01924669488', '22549996', NULL, 112),
(111, 'Head Office', NULL, NULL, NULL, NULL, 156),
(116, 'Head Office', NULL, NULL, NULL, NULL, 158),
(118, 'Head Office', NULL, NULL, NULL, NULL, 159),
(122, 'Head Office', '21/15, Babar Road, Mohammadpur', '01924669488', '01924669488', NULL, 164),
(125, 'Head Office', NULL, NULL, NULL, NULL, 167),
(127, 'Head Office', 'Dhaka  ', '01924669488', '022549996', NULL, 184),
(128, 'Head Office2', 'Dhaka', '01924669488', '22549996', NULL, 112),
(129, 'ABCSS', 'Dhaka', '01924669488', '22549996', NULL, 184),
(131, 'ST', '', '01924669488', '', NULL, 184),
(132, 'Head Office', NULL, NULL, NULL, NULL, 185),
(133, 'Head Office', NULL, NULL, NULL, NULL, 186),
(135, 'Head Office', NULL, NULL, NULL, NULL, 188),
(136, 'Head Office', NULL, NULL, NULL, NULL, 189),
(139, 'Head Office', NULL, NULL, NULL, NULL, 190),
(140, 'Head Office', NULL, NULL, NULL, NULL, 191),
(141, 'Head Office', NULL, NULL, NULL, NULL, 192),
(142, 'Head Office', NULL, NULL, NULL, NULL, 193),
(143, 'Head Office', NULL, NULL, NULL, NULL, 194),
(144, 'Head Office', NULL, NULL, NULL, NULL, 195),
(145, 'Head Office', 'Dhaka', '01915826995', '01915826995', NULL, 196),
(146, 'Head Office', NULL, NULL, NULL, NULL, 197),
(147, 'Head Office', NULL, NULL, NULL, NULL, 198),
(148, 'Head Office', NULL, NULL, NULL, NULL, 199),
(149, 'Head Office', NULL, NULL, NULL, NULL, 200),
(150, 'Head Office', NULL, NULL, NULL, NULL, 201),
(151, 'Head Office', NULL, NULL, NULL, NULL, 202),
(152, 'Head Office', NULL, NULL, NULL, NULL, 203),
(153, 'Head Office', NULL, NULL, NULL, NULL, 204),
(154, 'Head Office', NULL, NULL, NULL, NULL, 205),
(155, 'Head Office', NULL, NULL, NULL, NULL, 206),
(156, 'Head Office', NULL, NULL, NULL, NULL, 207),
(158, 'Head Office', 'Dhaka', '01924669488', '022549996', NULL, 209),
(169, 'Head Office', NULL, NULL, NULL, NULL, 220),
(170, 'Head Office', 'মিরপুর ,বাংলাদেশ', '০১৯২৪৬৬৩৪৮', '০১৯২৪৬৬৩৯৪৮', NULL, 221),
(171, 'Head Office', NULL, NULL, NULL, NULL, 224);

-- --------------------------------------------------------

--
-- Table structure for table `t_timezone`
--

CREATE TABLE IF NOT EXISTS `t_timezone` (
  `TimeZoneId` varchar(100) NOT NULL,
  `TimeZoneName` varchar(100) NOT NULL,
  `BActive` tinyint(1) NOT NULL,
  PRIMARY KEY (`TimeZoneId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `t_timezone`
--

INSERT INTO `t_timezone` (`TimeZoneId`, `TimeZoneName`, `BActive`) VALUES
('Asia/Aden', 'Asia/Aden', 0),
('Asia/Almaty', 'Asia/Almaty', 0),
('Asia/Amman', 'Asia/Amman', 0),
('Asia/Anadyr', 'Asia/Anadyr', 0),
('Asia/Aqtau', 'Asia/Aqtau', 0),
('Asia/Aqtobe', 'Asia/Aqtobe', 0),
('Asia/Ashgabat', 'Asia/Ashgabat', 0),
('Asia/Atyrau', 'Asia/Atyrau', 0),
('Asia/Baghdad', 'Asia/Baghdad', 0),
('Asia/Bahrain', 'Asia/Bahrain', 0),
('Asia/Baku', 'Asia/Baku', 0),
('Asia/Bangkok', 'Asia/Bangkok', 1),
('Asia/Barnaul', 'Asia/Barnaul', 0),
('Asia/Beirut', 'Asia/Beirut', 0),
('Asia/Bishkek', 'Asia/Bishkek', 0),
('Asia/Brunei', 'Asia/Brunei', 0),
('Asia/Chita', 'Asia/Chita', 0),
('Asia/Choibalsan', 'Asia/Choibalsan', 0),
('Asia/Colombo', 'Asia/Colombo', 0),
('Asia/Damascus', 'Asia/Damascus', 0),
('Asia/Dhaka', 'Asia/Dhaka', 1),
('Asia/Dili', 'Asia/Dili', 0),
('Asia/Dubai', 'Asia/Dubai', 1),
('Asia/Dushanbe', 'Asia/Dushanbe', 0),
('Asia/Famagusta', 'Asia/Famagusta', 0),
('Asia/Gaza', 'Asia/Gaza', 0),
('Asia/Hebron', 'Asia/Hebron', 0),
('Asia/Hong_Kong', 'Asia/Hong_Kong', 1),
('Asia/Hovd', 'Asia/Hovd', 0),
('Asia/Ho_Chi_Minh', 'Asia/Ho_Chi_Minh', 0),
('Asia/Irkutsk', 'Asia/Irkutsk', 0),
('Asia/Jakarta', 'Asia/Jakarta', 0),
('Asia/Jayapura', 'Asia/Jayapura', 0),
('Asia/Jerusalem', 'Asia/Jerusalem', 0),
('Asia/Kabul', 'Asia/Kabul', 0),
('Asia/Kamchatka', 'Asia/Kamchatka', 0),
('Asia/Karachi', 'Asia/Karachi', 0),
('Asia/Kathmandu', 'Asia/Kathmandu', 0),
('Asia/Khandyga', 'Asia/Khandyga', 0),
('Asia/Kolkata', 'Asia/Kolkata', 0),
('Asia/Krasnoyarsk', 'Asia/Krasnoyarsk', 0),
('Asia/Kuala_Lumpur', 'Asia/Kuala_Lumpur', 1),
('Asia/Kuching', 'Asia/Kuching', 0),
('Asia/Kuwait', 'Asia/Kuwait', 0),
('Asia/Macau', 'Asia/Macau', 0),
('Asia/Magadan', 'Asia/Magadan', 0),
('Asia/Makassar', 'Asia/Makassar', 0),
('Asia/Manila', 'Asia/Manila', 0),
('Asia/Muscat', 'Asia/Muscat', 0),
('Asia/Nicosia', 'Asia/Nicosia', 0),
('Asia/Novokuznetsk', 'Asia/Novokuznetsk', 0),
('Asia/Novosibirsk', 'Asia/Novosibirsk', 0),
('Asia/Omsk', 'Asia/Omsk', 0),
('Asia/Oral', 'Asia/Oral', 0),
('Asia/Phnom_Penh', 'Asia/Phnom_Penh', 0),
('Asia/Pontianak', 'Asia/Pontianak', 0),
('Asia/Pyongyang', 'Asia/Pyongyang', 0),
('Asia/Qatar', 'Asia/Qatar', 0),
('Asia/Qyzylorda', 'Asia/Qyzylorda', 0),
('Asia/Riyadh', 'Asia/Riyadh', 0),
('Asia/Sakhalin', 'Asia/Sakhalin', 0),
('Asia/Samarkand', 'Asia/Samarkand', 0),
('Asia/Seoul', 'Asia/Seoul', 0),
('Asia/Shanghai', 'Asia/Shanghai', 0),
('Asia/Singapore', 'Asia/Singapore', 1),
('Asia/Srednekolymsk', 'Asia/Srednekolymsk', 0),
('Asia/Taipei', 'Asia/Taipei', 0),
('Asia/Tashkent', 'Asia/Tashkent', 0),
('Asia/Tbilisi', 'Asia/Tbilisi', 0),
('Asia/Tehran', 'Asia/Tehran', 0),
('Asia/Thimphu', 'Asia/Thimphu', 0),
('Asia/Tokyo', 'Asia/Tokyo', 1),
('Asia/Tomsk', 'Asia/Tomsk', 0),
('Asia/Ulaanbaatar', 'Asia/Ulaanbaatar', 0),
('Asia/Urumqi', 'Asia/Urumqi', 0),
('Asia/Ust-Nera', 'Asia/Ust-Nera', 0),
('Asia/Vientiane', 'Asia/Vientiane', 0),
('Asia/Vladivostok', 'Asia/Vladivostok', 0),
('Asia/Yakutsk', 'Asia/Yakutsk', 0),
('Asia/Yangon', 'Asia/Yangon', 0),
('Asia/Yekaterinburg', 'Asia/Yekaterinburg', 0),
('Asia/Yerevan', 'Asia/Yerevan', 0),
('Australia/Canberra', 'Australia/Canberra', 1),
('Europe/Moscow', 'Europe/Moscow', 1),
('US/Central', 'US/Central', 1);

-- --------------------------------------------------------

--
-- Table structure for table `t_visitor`
--

CREATE TABLE IF NOT EXISTS `t_visitor` (
  `VisitorId` bigint(20) NOT NULL AUTO_INCREMENT,
  `VisitorName` varchar(100) NOT NULL,
  `VisitorCompany` varchar(100) NOT NULL,
  `VisitorTypeId` int(11) DEFAULT NULL,
  `EmployeeId` int(11) NOT NULL,
  `SignInTime` datetime NOT NULL,
  `SignOutTime` datetime NOT NULL,
  `date` date NOT NULL,
  `Phone` varchar(50) NOT NULL,
  `EmailAddress` varchar(100) NOT NULL,
  `EstDuration` varchar(40) NOT NULL,
  `ImagePath` varchar(255) NOT NULL,
  PRIMARY KEY (`VisitorId`),
  KEY `FK_Visitor_VisitorType` (`VisitorTypeId`),
  KEY `FK_Visitor_Employee` (`EmployeeId`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=183 ;

--
-- Dumping data for table `t_visitor`
--

INSERT INTO `t_visitor` (`VisitorId`, `VisitorName`, `VisitorCompany`, `VisitorTypeId`, `EmployeeId`, `SignInTime`, `SignOutTime`, `date`, `Phone`, `EmailAddress`, `EstDuration`, `ImagePath`) VALUES
(77, 'Monir', 'Color Expert Ltd', 1, 137, '2016-12-27 09:30:43', '2017-01-19 13:08:49', '2016-12-27', '', '', '2000286', '99.jpg'),
(78, 'Hasibul', 'Soft BD', 1, 132, '2016-12-27 10:14:38', '2017-01-19 13:08:42', '2016-12-27', '', '', '1997644', '98.jpg'),
(79, 'Shove Islam', 'V3 Communications Limited', 1, 132, '2016-12-20 14:00:43', '2016-12-20 15:33:43', '2016-12-20', '', '', '5580', '1.jpg'),
(80, 'Abdullah Al Sakeeb', 'Grameen Solutions', 1, 133, '2016-12-21 11:38:32', '2016-12-21 11:54:32', '2016-12-21', '', '', '960', '2.jpg'),
(81, 'Abdullah Al Sakeeb', 'Grameen Solutions', 1, 133, '2016-12-22 11:39:58', '2016-12-22 12:04:58', '2016-12-22', '', '', '1500', '2.jpg'),
(82, 'Binoy Roy', 'Ministry of Women and Children''s Affairs', 1, 132, '2016-12-18 14:43:47', '2016-12-18 15:45:47', '2016-12-18', '', '', '3720', '3.jpg'),
(83, 'Homauyn Kabir', 'Robi Axiata Limited', 1, 132, '2016-12-19 10:45:48', '2016-12-19 12:12:48', '2016-12-19', '', '', '5220', '4.jpg'),
(84, 'Ilias Shah', 'Parallaxlogic Infotech', 1, 132, '2016-12-20 10:47:54', '2016-12-20 12:00:54', '2016-12-20', '', '', '4380', '5.jpg'),
(85, 'A.b. Siddique', 'Telephone Shilpa Sangstha Ltd. Tongi, Gazipur', 1, 132, '2016-12-21 13:50:39', '2016-12-21 14:12:39', '2016-12-21', '', '', '1320', '6.jpg'),
(86, 'S.m. Moniruzzaman', 'Lexicon Group', 1, 132, '2016-12-22 13:52:12', '2016-12-22 14:45:12', '2016-12-22', '', '', '3180', '7.jpg'),
(87, 'Zahidul Islam', 'AdaSoft International Limited', 1, 132, '2016-12-18 12:54:08', '2016-12-18 13:20:08', '2016-12-18', '', '', '1560', '8.jpg'),
(88, 'Masud Rana', 'Padma Group', 1, 132, '2016-12-19 14:55:34', '2016-12-19 15:10:34', '2016-12-19', '', '', '900', '9.jpg'),
(89, 'Mehedi Hasan', 'Wedevs ', 1, 138, '2016-12-19 15:05:04', '2016-12-19 15:23:04', '2016-12-19', '', '', '1080', '10.jpg'),
(90, 'Humauyn Kabir', 'Green University', 1, 138, '2016-12-22 16:06:14', '2016-12-22 16:45:14', '2016-12-22', '', '', '2340', '11.jpg'),
(91, 'Rasel Rana', 'Fortuna Group', 1, 138, '2016-12-21 10:07:15', '2016-12-21 10:30:15', '2016-12-21', '', '', '1380', '12.jpg'),
(92, 'Nurnabi Milan', 'N N Solution', 1, 138, '2016-12-20 12:08:25', '2016-12-20 13:14:25', '2016-12-20', '', '', '3960', '13.jpg'),
(93, 'MJ Shohel', 'BRAC', 1, 138, '2016-12-19 10:09:44', '2016-12-19 11:10:44', '2016-12-19', '', '', '3660', '14.jpg'),
(94, 'Masud Parvez', 'ACI Formulation Ltd', 1, 136, '2016-12-20 12:39:01', '2016-12-20 12:50:01', '2016-12-20', '', '', '660', '20.jpg'),
(95, 'Jr Ajad', 'Banglalink', 1, 136, '2016-12-19 15:44:31', '2016-12-19 16:10:31', '2016-12-19', '', '', '1560', '15.jpg'),
(96, 'Reaz Hossain', 'Best Electronics', 1, 136, '2016-12-19 15:45:50', '2016-12-19 15:54:50', '2016-12-19', '', '', '540', '16.jpg'),
(97, 'Abdullah Al Mamun', 'Saturday Advertising', 1, 132, '2016-12-20 10:47:16', '2016-12-20 11:07:16', '2016-12-20', '', '', '1200', '17.jpg'),
(98, 'Mydul Islam Apon', 'Seven Circle (BD) Ltd', 1, 136, '2016-12-21 12:48:58', '2016-12-21 12:55:58', '2016-12-21', '', '', '420', '18.jpg'),
(99, 'Mahabub Rimon', 'Somoy Media Limited', 1, 136, '2016-12-20 10:50:22', '2016-12-20 11:02:22', '2016-12-20', '', '', '720', '19.jpg'),
(100, 'Sheikh Al Mamun', 'FCI Group', 1, 132, '2016-12-20 09:51:31', '2016-12-20 10:32:31', '2016-12-20', '', '', '2460', '21.jpg'),
(101, 'M.D. Saeb Ahmed Shakil', 'Research and Development Collective (RDC)', 1, 132, '2016-12-19 10:10:03', '2016-12-19 11:25:03', '2016-12-19', '', '', '4500', '22.jpg'),
(102, 'Rahim', 'USBBD Tech', 1, 132, '2016-12-19 11:42:29', '2016-12-19 11:55:29', '2016-12-19', '', '', '780', '100.jpg'),
(103, 'Akramul Islam', 'Khulna University', 1, 137, '2016-12-19 11:51:54', '2016-12-19 12:11:54', '2016-12-19', '', '', '1200', '23.jpg'),
(104, 'Jashim', 'International Labor Organization (ILO)', 1, 134, '2016-12-20 12:53:53', '2016-12-20 13:01:53', '2016-12-20', '', '', '480', '24.jpg'),
(105, 'Kamran Khan', 'amIT Solution', 1, 137, '2016-12-19 10:55:46', '2016-12-19 13:02:46', '2016-12-19', '', '', '7620', '25.jpg'),
(106, 'Mamunur Rashid', 'Dushra Soft', 1, 134, '2016-12-18 12:31:12', '2016-12-18 12:43:12', '2016-12-18', '', '', '720', '26.jpg'),
(107, 'Nayan', 'Just', 1, 137, '2016-12-18 12:32:08', '2016-12-18 12:53:08', '2016-12-18', '', '', '1260', '27.jpg'),
(108, 'Shimul Mahamud', 'Cristal Ltd.', 1, 134, '2016-12-20 11:33:09', '2016-12-20 11:45:09', '2016-12-20', '', '', '720', '28.jpg'),
(109, 'Tanmoy Biswas', 'Walton Group', 1, 137, '2016-12-20 10:34:15', '2016-12-20 11:40:15', '2016-12-20', '', '', '3960', '30.jpg'),
(110, 'Tanvir Akter', 'Khulna University', 1, 137, '2016-12-19 11:35:26', '2016-12-19 12:02:26', '2016-12-19', '', '', '1620', '31.jpg'),
(111, 'Reza Sarker', 'Color Expert Ltd', 1, 137, '2016-12-21 12:31:12', '2016-12-21 12:56:12', '2016-12-21', '', '', '1500', '32.jpg'),
(112, 'Mezbah Uddin', 'Veritas Pharmaceuticals Ltd', 1, 137, '2016-12-21 14:31:12', '2016-12-21 14:45:12', '2016-12-21', '', '', '840', '33.jpg'),
(113, 'Sourav Tamim', 'Global Graphics Lab', 1, 137, '2016-12-21 09:31:12', '2016-12-21 10:03:12', '2016-12-21', '', '', '1920', '34.jpg'),
(114, 'Shamim Ahammed', 'Oployee Labs', 1, 137, '2016-12-21 11:31:12', '2016-12-21 11:55:12', '2016-12-21', '', '', '1440', '35.jpg'),
(115, 'Dider Alam', 'Central Insurance Company Ltd.', 1, 137, '2016-12-20 09:31:12', '2016-12-20 11:05:12', '2016-12-20', '', '', '5640', '36.jpg'),
(116, 'Nazmul Hoque', 'Bombay Sweets and Company Limited', 1, 137, '2016-12-20 12:31:12', '2016-12-20 11:22:12', '2016-12-20', '', '', '-4140', '37.jpg'),
(117, 'Zaher Ul Islam', 'Power save electronics bangladesh', 1, 137, '2016-12-19 10:31:12', '2016-12-19 11:15:12', '2016-12-19', '', '', '2640', '38.jpg'),
(118, 'Jony', 'Natty com pvt. ltd.', 1, 137, '2016-12-18 15:31:12', '2016-12-18 17:02:12', '2016-12-18', '', '', '5460', '39.jpg'),
(119, 'Liton Shaha', 'Optimal IT', 1, 137, '2016-12-18 16:31:12', '2016-12-18 18:25:12', '2016-12-18', '', '', '6840', '40.jpg'),
(120, 'MD. Kawsar', 'Azad Hind Printing And Publishing company Ltd', 3, 140, '2016-12-18 10:28:54', '2016-12-18 12:12:54', '2016-12-18', '', '', '6240', '41.jpg'),
(121, 'Sabbir Ahmed', 'Ajkerdeal', 2, 121, '2016-12-19 12:31:26', '2016-12-19 14:52:26', '2016-12-19', '', '', '8460', '49.jpg'),
(122, 'Roni Talukdar', 'Pinch Kitchen', 3, 140, '2016-12-20 13:28:54', '2016-12-20 14:23:54', '2016-12-20', '', '', '3300', '42.jpg'),
(123, 'Rico', 'DHL', 2, 139, '2016-12-21 14:31:26', '2016-12-21 15:02:26', '2016-12-21', '', '', '1860', '50.jpg'),
(124, 'Md. Fawad Hasan', 'DHL Express', 2, 139, '2016-12-22 15:28:54', '2016-12-22 17:24:54', '2016-12-22', '', '', '6960', '51.jpg'),
(125, 'Md. Emran Karim', 'Darusalam Electic', 3, 140, '2016-12-22 14:28:54', '2016-12-22 15:15:54', '2016-12-22', '', '', '2820', '43.jpg'),
(126, 'Md. Sarwar Hossain', 'A.B. Traders', 3, 140, '2016-12-21 10:21:54', '2016-12-21 11:28:54', '2016-12-21', '', '', '4020', '44.jpg'),
(127, 'Kamrul Hasan', 'Bearing Sales Corporation', 3, 140, '2016-12-22 09:28:54', '2016-12-22 10:12:54', '2016-12-22', '', '', '2640', '45.jpg'),
(128, 'Nirbash Ahmed', 'Asadullah Hardware Store', 3, 140, '2016-12-18 12:28:54', '2016-12-18 13:50:54', '2016-12-18', '', '', '4920', '46.jpg'),
(129, 'Abdul Hamid Khan', 'Fedex', 2, 139, '2016-12-18 10:28:54', '2016-12-18 12:33:54', '2016-12-18', '', '', '7500', '52.jpg'),
(130, 'Md. Afsar Ahsan', 'Fedex', 2, 121, '2016-12-19 13:02:54', '2016-12-19 14:28:54', '2016-12-19', '', '', '5160', '53.jpg'),
(131, 'Md. Nayeem Abdullah', 'Bangladesh Machineries', 3, 140, '2016-12-21 10:00:54', '2016-12-21 11:22:54', '2016-12-21', '', '', '4920', '47.jpg'),
(132, 'Saiful Islam', 'Bengal Hardware Store', 3, 140, '2016-12-22 12:28:54', '2016-12-22 11:02:54', '2016-12-22', '', '', '-5160', '48.jpg'),
(133, 'Mahumd', 'Zzzzz', 2, 133, '2016-12-28 14:20:45', '2017-01-17 16:06:08', '2016-12-28', '', '', '1734323', '133-mahumd.jpg'),
(134, 'Anwar Hossain', 'BNMPC', 3, 121, '2016-12-28 14:41:09', '2017-01-19 13:08:33', '2016-12-28', '', '', '1895244', '121-anwar-hossain.jpg'),
(135, 'Anwar Hossain', 'Softworks Limited', 3, 121, '2017-01-05 12:58:20', '2017-01-19 13:08:35', '2017-01-05', '', '', '1210215', '121-anwar-hossain.jpg'),
(136, 'Jahirul Islam', 'Bangladesh Bank', 2, 121, '2017-01-05 13:13:45', '2017-01-19 13:08:40', '2017-01-05', '', '', '1209295', '121-jahirul-islam.jpg'),
(137, 'Sumon', 'Hash Tech', 1, 79, '2017-01-05 14:48:55', '0000-00-00 00:00:00', '2017-01-05', '', '', '', '79-sumon.jpg'),
(138, 'Anwar Hossain', 'Softworks Limited', 3, 121, '2017-01-05 14:53:38', '2017-01-19 13:08:27', '2017-01-05', '', '', '1203289', '121-anwar-hossain.jpg'),
(139, 'Anwar Hossain', 'Softworks Limited', 2, 121, '2017-01-05 15:36:50', '2017-01-19 13:08:29', '2017-01-05', '', '', '1200699', '121-anwar-hossain.jpg'),
(140, 'Anwar Hossain', 'Softworks Limited', 1, 121, '2017-01-05 15:37:32', '2017-01-19 13:08:23', '2017-01-05', '', '', '1200651', '121-anwar-hossain.jpg'),
(141, 'Nayeem Hossain', 'National Television', 2, 121, '2017-01-05 17:23:26', '2017-01-19 13:08:38', '2017-01-05', '', '', '1194312', '121-nayeem-hossain.jpg'),
(142, 'Habibur Rahman', 'Anlima yarn dying', 2, 121, '2017-01-05 19:34:05', '2017-01-19 13:09:01', '2017-01-05', '', '', '1186496', '121-habibur-rahman.jpg'),
(143, 'Jamal Haider', 'Haider Construction', 3, 121, '2017-01-06 10:23:47', '2017-01-19 13:08:45', '2017-01-06', '', '', '1133098', '121-jamal-haider.jpg'),
(145, 'Abrar Zaheen', 'St. Joseph Higher Secondary School', 1, 157, '2017-01-07 14:39:27', '2017-01-19 13:08:55', '2017-01-07', '', '', '1031368', '157-abrar-zaheen.jpg'),
(146, 'Abrar Zaheen', 'National Television', 3, 137, '2017-01-07 14:43:39', '2017-01-19 13:08:53', '2017-01-07', '', '', '1031114', '137-abrar-zaheen.jpg'),
(148, 'Alim', 'A C Soft', 1, 139, '2017-01-16 13:01:00', '2017-01-19 13:08:59', '2017-01-16', '', '', '259679', ''),
(149, 'Sumon', 'Hash Tech', 1, 121, '2017-01-16 17:16:09', '2017-01-19 13:08:11', '2017-01-16', '', '', '244322', '121-sumon.jpg'),
(150, 'Al Amin', 'DB Bank', 1, 121, '2017-01-17 10:46:13', '2017-01-19 13:08:57', '2017-01-17', '456', 'salam.mascse@gmail.com', '181364', '12.jpg'),
(151, 'Anwar Hossain', 'Softworks Limited', 3, 157, '2017-01-17 13:16:25', '2017-01-19 13:08:31', '2017-01-17', '', '', '172326', '157-anwar-hossain.jpg'),
(152, 'Anwar Hossain', 'Softworks Limited', 1, 134, '2017-01-17 16:13:37', '2017-01-19 13:08:25', '2017-01-17', '', '', '161688', '134-anwar-hossain.jpg'),
(153, 'Anwar Hossain', 'Softworks Limited', 2, 157, '2017-01-17 17:43:48', '2017-01-19 13:08:20', '2017-01-17', '', '', '156272', '157-anwar-hossain.jpg'),
(154, 'Anwar Hossain', 'Softworks Limited', 133, 181, '2017-01-18 11:48:36', '2017-01-18 18:01:00', '2017-01-18', '', '', '22344', '181-anwar-hossain.jpg'),
(155, 'Nayeem Hossain', 'NTV', 131, 181, '2017-01-18 11:51:04', '2017-01-18 18:16:18', '2017-01-18', '', '', '23114', '181-nayeem-hossain.jpg'),
(156, 'Anwar Hossain', 'Softworks Limited', 132, 181, '2017-01-18 15:45:17', '2017-01-19 09:06:57', '2017-01-18', '', '', '62500', '181-anwar-hossain.jpg'),
(157, 'Anwar Hossain', 'Softworks Limited', 132, 181, '2017-01-18 15:46:43', '2017-01-19 12:37:09', '2017-01-18', '', '', '75026', '181-anwar-hossain.jpg'),
(158, 'Anwar Hossain', 'Bangladesh Bank', 132, 181, '2017-01-18 17:49:31', '0000-00-00 00:00:00', '2017-01-18', '', '', '', '181-anwar-hossain.jpg'),
(159, 'Sajidul Munir', 'SoftWorks Ltd.', 1, 121, '2017-01-19 12:30:39', '2017-01-19 13:08:47', '2017-01-19', '', '', '2288', '121-sajidul-munir.jpg'),
(160, 'Sajidul Munir', 'SoftWorks Ltd.', 1, 121, '2017-01-19 12:36:45', '2017-01-19 13:08:17', '2017-01-19', '', '', '1892', '121-sajidul-munir.jpg'),
(161, 'Sajidul Munir', 'SoftWorks Ltd.', 1, 121, '2017-01-19 12:40:41', '2017-01-19 13:08:51', '2017-01-19', '', '', '1690', '121-sajidul-munir.jpg'),
(162, 'Sajidul Munir', 'SoftWorks Lt`.', 1, 121, '2017-01-19 13:09:29', '2017-01-19 13:10:03', '2017-01-19', '', '', '34', '121-sajidul-munir.jpg'),
(163, 'Sajidul Munir', 'SoftWorks Ltd.', 1, 121, '2017-01-19 13:11:09', '2017-01-19 13:38:57', '2017-01-19', '', '', '1668', '121-sajidul-munir.jpg'),
(164, 'Anwar Hossain', 'Adabor, Dhaka', 1, 135, '2017-01-19 13:13:02', '2017-01-19 13:29:19', '2017-01-19', '', '', '977', '135-anwar-hossain.jpg'),
(165, 'Anwar Hossain', 'Adabor, Dhaka', 1, 135, '2017-01-19 13:13:32', '2017-01-19 17:14:11', '2017-01-19', '', '', '14439', '135-anwar-hossain.jpg'),
(166, 'Sajidul Munir', 'SoftWorks Ltd.', 1, 121, '2017-01-19 13:15:07', '2017-01-19 13:16:19', '2017-01-19', '', '', '72', '121-sajidul-munir.jpg'),
(167, 'Anwar Hossain', 'Bangladesh Bank', 3, 140, '2017-01-19 13:18:49', '2017-01-19 13:42:13', '2017-01-19', '', '', '1404', '140-anwar-hossain.jpg'),
(168, 'Anwar Hossain', 'Bangladesh Bank', 1, 137, '2017-01-19 13:38:10', '2017-01-19 15:13:57', '2017-01-19', '', '', '5747', '137-anwar-hossain.jpg'),
(169, 'Anwar Hossain', 'Mirpur', 3, 121, '2017-01-19 13:38:50', '2017-01-19 16:27:02', '2017-01-19', '', '', '10092', '121-anwar-hossain.jpg'),
(170, 'Sajidul Munir', 'SoftWorks Ltd.', 1, 121, '2017-01-19 13:42:04', '0000-00-00 00:00:00', '2017-01-19', '', '', '', '121-sajidul-munir.jpg'),
(171, 'Sajidul Munir', 'SoftWorks Ltd.', 1, 121, '2017-01-19 13:42:38', '2017-01-19 17:05:11', '2017-01-19', '', '', '12153', '121-sajidul-munir.jpg'),
(172, 'Anwar Hossain', 'Bangladesh Bank', 3, 137, '2017-01-19 17:11:14', '0000-00-00 00:00:00', '2017-01-19', '', '', '', '137-anwar-hossain.jpg'),
(173, 'Anwar Hossain', 'NTV', 3, 139, '2017-01-19 17:14:00', '2017-01-19 17:14:08', '2017-01-19', '', '', '8', '139-anwar-hossain.jpg'),
(174, 'Anwar Hossain', 'Bangladesh Bank', 131, 181, '2017-01-19 17:17:49', '2017-01-19 17:18:53', '2017-01-19', '', '', '64', '181-anwar-hossain.jpg'),
(175, 'Anwar Hossain', 'Bangladesh Bank', 1, 137, '2017-01-24 10:56:43', '2017-01-24 12:42:06', '2017-01-24', '', '', '6323', '137-anwar-hossain.jpg'),
(176, 'Anwar Hossain', 'Bangladesh Bank', 1, 121, '2017-01-24 12:51:14', '2017-01-24 13:30:16', '2017-01-24', '', '', '2342', '121-anwar-hossain.jpg'),
(177, 'Sajidul Munir', 'SoftWorks Ltd.', 1, 121, '2017-01-24 13:36:40', '2017-01-24 13:57:56', '2017-01-24', '', '', '1276', '121-sajidul-munir.jpg'),
(178, 'Sajidul Munir', 'SoftWorks Ltd.', 1, 121, '2017-01-24 13:38:55', '2017-01-24 15:28:51', '2017-01-24', '', '', '6596', '121-sajidul-munir.jpg'),
(179, 'Anwar Hossain', 'Softworks Limited', 3, 132, '2017-01-24 13:58:48', '2017-01-24 14:01:16', '2017-01-24', '', '', '148', '132-anwar-hossain.jpg'),
(180, 'Anwar Hossain', 'Bangladesh Bank', 3, 139, '2017-01-24 13:59:59', '2017-01-24 14:01:01', '2017-01-24', '', '', '62', '139-anwar-hossain.jpg'),
(181, 'Nayeem Hossain', 'Mirpur', 1, 138, '2017-01-24 14:00:53', '2017-01-24 14:01:05', '2017-01-24', '', '', '12', '138-nayeem-hossain.jpg'),
(182, 'Nayeem Hossain', 'Bangladesh Bank', 2, 140, '2017-01-24 17:19:32', '2017-01-24 17:21:01', '2017-01-24', '', '', '89', '140-nayeem-hossain.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `t_visitortype`
--

CREATE TABLE IF NOT EXISTS `t_visitortype` (
  `VisitorTypeId` int(11) NOT NULL AUTO_INCREMENT,
  `VisitorType` varchar(50) NOT NULL,
  `CompanyId` int(11) DEFAULT NULL,
  PRIMARY KEY (`VisitorTypeId`),
  KEY `FK_VisitorType_Company` (`CompanyId`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=143 ;

--
-- Dumping data for table `t_visitortype`
--

INSERT INTO `t_visitortype` (`VisitorTypeId`, `VisitorType`, `CompanyId`) VALUES
(1, 'Visitor', 164),
(2, 'Delivery', 164),
(3, 'Contractor', 164),
(128, 'Visitor', 220),
(129, 'Contractor', 220),
(130, 'Delivery', 220),
(131, 'ভিজিটর', 221),
(132, 'কন্টাক্টর', 221),
(133, 'ডেলিভারি', 221),
(134, 'Visitor', 222),
(135, 'Contractor', 222),
(136, 'Delivery', 222),
(137, 'Visitor', 223),
(138, 'Contractor', 223),
(139, 'Delivery', 223),
(140, 'Visitor', 224),
(141, 'Contractor', 224),
(142, 'Delivery', 224);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `t_authorise_visitor`
--
ALTER TABLE `t_authorise_visitor`
  ADD CONSTRAINT `FK_AuthorizeVisitor_Employee` FOREIGN KEY (`EmployeeId`) REFERENCES `t_employee` (`Id`),
  ADD CONSTRAINT `FK_AuthorizeVisitor_Event` FOREIGN KEY (`EventId`) REFERENCES `t_event` (`EventId`),
  ADD CONSTRAINT `FK_AuthorizeVisitor_VisitorType` FOREIGN KEY (`VisitorTypeId`) REFERENCES `t_visitortype` (`VisitorTypeId`);

--
-- Constraints for table `t_company`
--
ALTER TABLE `t_company`
  ADD CONSTRAINT `t_company_ibfk_1` FOREIGN KEY (`TimeZoneId`) REFERENCES `t_timezone` (`TimeZoneId`),
  ADD CONSTRAINT `t_company_ibfk_2` FOREIGN KEY (`LangCode`) REFERENCES `t_language` (`LangCode`);

--
-- Constraints for table `t_division`
--
ALTER TABLE `t_division`
  ADD CONSTRAINT `FK_Division_Site` FOREIGN KEY (`SiteId`) REFERENCES `t_site` (`SiteId`);

--
-- Constraints for table `t_employee`
--
ALTER TABLE `t_employee`
  ADD CONSTRAINT `FK_Employee_Company` FOREIGN KEY (`CompanyId`) REFERENCES `t_company` (`CompanyId`),
  ADD CONSTRAINT `FK_Employee_Division` FOREIGN KEY (`DivisionId`) REFERENCES `t_division` (`DivisionId`),
  ADD CONSTRAINT `FK_Employee_Site` FOREIGN KEY (`SiteId`) REFERENCES `t_site` (`SiteId`);

--
-- Constraints for table `t_event`
--
ALTER TABLE `t_event`
  ADD CONSTRAINT `FK_Event_Company` FOREIGN KEY (`CompanyId`) REFERENCES `t_company` (`CompanyId`);

--
-- Constraints for table `t_setting_language_string`
--
ALTER TABLE `t_setting_language_string`
  ADD CONSTRAINT `t_setting_language_string_ibfk_1` FOREIGN KEY (`LangCode`) REFERENCES `t_language` (`LangCode`);

--
-- Constraints for table `t_site`
--
ALTER TABLE `t_site`
  ADD CONSTRAINT `FK_Site_Company` FOREIGN KEY (`CompanyId`) REFERENCES `t_company` (`CompanyId`);

--
-- Constraints for table `t_visitor`
--
ALTER TABLE `t_visitor`
  ADD CONSTRAINT `FK_Visitor_Employee` FOREIGN KEY (`EmployeeId`) REFERENCES `t_employee` (`Id`),
  ADD CONSTRAINT `FK_Visitor_VisitorType` FOREIGN KEY (`VisitorTypeId`) REFERENCES `t_visitortype` (`VisitorTypeId`);

--
-- Constraints for table `t_visitortype`
--
ALTER TABLE `t_visitortype`
  ADD CONSTRAINT `FK_VisitorType_Company` FOREIGN KEY (`CompanyId`) REFERENCES `t_company` (`CompanyId`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
