<?php
	//$BaseUrl = $_SERVER['SERVER_NAME'].'/trackmyvisitor/';
	$BaseUrl = '/trackmyvisitor/api/v1/';
	
	//$SiteBaseUrl = $_SERVER['SERVER_NAME'].'/trackmyvisitor/';
	$SiteBaseUrl = '/trackmyvisitor/';
	$ImageUploadUrl = 'http://trackmyvisitor/';
	
	$ImageBaseUrl = "http://" . gethostname() . '/trackmyvisitor/images/';
//	$ImageBaseUrl = 'http://localhost/trackmyvisitor/images/';
        
    $httpsOrHttp = ((!empty($_SERVER['HTTPS'])) && ($_SERVER['HTTPS'] != 'off')) ? 'https' : 'http';
    $ImageUrl = $httpsOrHttp.'://'.$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF']);

?>