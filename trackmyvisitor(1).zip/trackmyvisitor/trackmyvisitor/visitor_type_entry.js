function resetForm(id) {
    $('#' + id).each(function () {
        this.reset();
    });
}
function onConfirmWhenVisitorTypeAdd() {
    var error = 0;
    var VisitorType = $("#VisitorType").val();
    if (VisitorType == '') {
        $("#visitorTypeVal").html('Please enter Visitor Type');
        $("#VisitorType").addClass('invalidval');
        error = 1;
    }
    else {
        $("#visitorTypeVal").html('');
        $("#VisitorType").removeClass('invalidval');
    }
    if (error == 1) {
        return false;
    }
    else {
        $.ajax({
            "async": true,
            url: baseUrl + "visitor-type-create",
            "method": "POST",
            "data": $('#visitor_type_add_form').serialize() + '&CompanyId=' + COMPANYID,
            "headers": {
                "Apikey": APIKEY,
                "cache-control": "no-cache"
            },
            success: function (response)
            {
                //console.log(response);
                //return false;
                $("#AllVisitorTypeTable").hide();
                $("#AddNewVisitorType").show();
                if (response['error'] == false) {
                    $("#MessageShow").html(response['message']);
                    $('#myModal').modal('show');
                    //return false;
                }
                else {
                    $("#MessageShow").html(response['message']);
                    $('#myModal').modal('show');
                    //return false;
                }

            }
        });
    }
}

function onConfirmWhenvisitorTypeEdit(response) {

    response = response['visitorTypeEdit'];
    //lastEmployeeId = response[0]['Id']
    var RecordId = response[0]['VisitorTypeId']
    var VisitorType = response[0]['VisitorType'];

    $("#VisitorTypeEntry").show();
    $("#AllVisitorTypeTable").hide();
    $("#VisitorType").val(VisitorType);
    $("#RecordId").val(RecordId);

}
function visitorTypeEdit(VisitorTypeId) {
//alert(EmployeeId);
    $.ajax({
        "async": true,
        url: baseUrl + "visitor-type-list-edit/" + VisitorTypeId,
        "method": "GET",
        "headers": {
            "Apikey": APIKEY,
            "cache-control": "no-cache"
        },
        success: function (response)
        {
            onConfirmWhenvisitorTypeEdit(response);
        }
    });
}
function visitorDelete(VisitorTypeId) {
    if (!confirm("Do you really want to delete this record?")) {
        return false;
    } else {
        $.ajax({
            "async": true,
            url: baseUrl + "visitor-type-delete/" + VisitorTypeId,
            "method": "GET",
            "headers": {
                "Apikey": APIKEY,
                "cache-control": "no-cache"
            },
            success: function (response)
            {
                if (response['error'] == false) {
                    var msg = "Visitor type has been deleted successfully";
                    $("#MessageShow").html(msg);
                    $('#myModal').modal('show');
                    getVisitorTypeList();
                } else {
                    var msg = "Sorry, Visitor type has not been deleted";
                    $("#MessageShow").html(msg);
                    $('#myModal').modal('show');
                }
            }
        });
    }
}

function removeErrorline() {
    $("#visitorTypeVal").html('');
    $("#VisitorType").removeClass('invalidval');
}
function onListPanel() {
    $('#AllVisitorTypeTable').show();
    $('#VisitorTypeEntry').hide();
    getVisitorTypeList();
}
/*---------------------- Ready function--------------------------*/
$(function () {
    getVisitorTypeList();

    $('#visitor_type_add_form').submit(function () {
        //onConfirmWhenVisitorTypeAdd();
        return false;
    });

    resetForm("visitor_type_add_form");
    $("#AddNewVisitorType").click(function () {
        removeErrorline();
        $("#AllVisitorTypeTable").hide();
        $("#VisitorTypeEntry").show();
        $("#VisitorType").val('');
        $("#RecordId").val('');
    });
    $("#AllVisitorType").click(function () {
        removeErrorline();
        resetForm("visitor_type_add_form");
        getVisitorTypeList();
        $("#AllVisitorTypeTable").show();
        $("#VisitorTypeEntry").hide();
    });
});
function getVisitorTypeListData(response) {
    response = response['visitor-type'];
    var trHTML = '';
    var VisitorTypeId = '';
    var CompanyName = '';
    var VisitorType = '';
    trHTML += '<div id="list-panel"><h3>Visitor Type List</h3><table id="AllHostInfo" class="table table-striped table-bordered display table-hover" cellspacing="0"><thead><tr><th style="text-align: left;">Visitor Type</th><th style="text-align: left;"></th></tr></thead><tbody>';
    $.each(response, function (key, value) {
        VisitorTypeId = value.VisitorTypeId;
        VisitorType = value.VisitorType;
        CompanyName = value.CompanyName;
        trHTML +=
                '<tr><td>' + VisitorType +
                '</td><td style="text-align: center;width:20%;"> <input type="submit" value="Edit" class="btn btn-primary btn-sm" onClick="visitorTypeEdit(' + VisitorTypeId + ')">' + '    ' + '<input type="submit" value="Delete" class="btn btn-danger btn-sm" onClick="visitorDelete(' + VisitorTypeId + ')">' +
                '</td></a></tr>';
    });
    trHTML += '</tbody></table></div>';
    $('#AllVisitorTypeTable').html(trHTML); //append
}
function getVisitorTypeList() {
    $.ajax({
        "async": true,
        url: baseUrl + "get-visitor-type/" + COMPANYID,
        "method": "GET",
        "headers": {
            "Apikey": APIKEY,
            "cache-control": "no-cache"
        },
        success: function (response)
        {
            getVisitorTypeListData(response);
        }
    });
}


