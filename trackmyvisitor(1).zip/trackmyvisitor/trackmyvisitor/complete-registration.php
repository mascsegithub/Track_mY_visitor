<!DOCTYPE html>
<html dir="ltr" lang="en-US">
    <head>
        <meta http-equiv="content-type" content="text/html; charset=utf-8" />
        <meta name="author" content="SemiColonWeb" />
        <!-- Stylesheets
        ============================================= -->
        <link href="http://fonts.googleapis.com/css?family=Lato:300,400,400italic,600,700|Raleway:300,400,500,600,700|Crete+Round:400italic" rel="stylesheet" type="text/css" />
        <link rel="stylesheet" href="css/bootstrap.css" type="text/css" />
        <link rel="stylesheet" href="style.css" type="text/css" />
        <link rel="stylesheet" href="css/dark.css" type="text/css" />
        <link rel="stylesheet" href="css/font-icons.css" type="text/css" />
        <link rel="stylesheet" href="css/animate.css" type="text/css" />
        <link rel="stylesheet" href="css/magnific-popup.css" type="text/css" />

        <link rel="stylesheet" href="css/responsive.css" type="text/css" />
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
		<link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon">
		<link rel="icon" href="images/favicon.ico" type="image/x-icon">
        <!--[if lt IE 9]>
            <script src="http://css3-mediaqueries-js.googlecode.com/svn/trunk/css3-mediaqueries.js"></script>
        <![endif]-->

        <!-- Document Title
        ============================================= -->
        <title>Track My Visitor - Complete Registration</title>
		<?php include('global_variables.php'); ?>
        <script>
			<?php include('baseurl.php'); ?>
			var baseUrl = '<?php echo $BaseUrl; ?>';
		</script>
    </head>

    <body class="stretched">

        <!-- Document Wrapper
        ============================================= -->
        <div id="wrapper" class="clearfix">
            <!-- Header
            ============================================= -->
            <?php include('header.php'); ?>
            <!-- #header end -->
            <!-- Content
            ============================================= -->
            <section id="content">
                <div class="content-wrap" id="registerform">
                    <div class="container clearfix">
                        <div class="accordion accordion-lg divcenter nobottommargin clearfix" style="max-width: 550px;">
                            <div class="acctitle"><i class="acc-closed icon-user4"></i><i class="acc-open icon-ok-sign"></i>Track My Visitor Account Registration</div>
                            <div class="acc_content clearfix">
								<label id="Errormessage"></label>
                                <form id="complete-register-form" name="register-form" class="nobottommargin" method="post">

                                    <div class="col_full">
                                        <label for="EmailAddress">Email:<spam class="invalid">*</spam></label>
                                        <input type="text" id="EmailAddress" name="EmailAddress" value="<?php echo $_REQUEST['email'];?>" class="form-control" readonly/>
										<em class="invalid" id="invalidEmail"></em>
									</div>

                                    <div class="col_full">
                                        <label for="Password">password:<spam class="invalid">*</spam></label>
                                        <input type="password" id="Password" name="Password" class="form-control" />
										<em class="invalid" id="invalidpassword"></em>
									</div>                                    
									
									<div class="col_full">
                                        <label for="ConfirmPassword">Confirm password:<spam class="invalid">*</spam></label>
                                        <input type="password" id="ConfirmPassword" name="ConfirmPassword" class="form-control" />
										<em class="invalid" id="invalidConfirmpassword"></em>
									</div>

                                    <div class="col_full nobottommargin">
										<input type="text" id="CompanyId" name="CompanyId" value="<?php echo $_REQUEST['companyid'];?>" style="display:none;" />
										<!--<input type="submit" value="Register" class="button button-3d button-black nomargin btn-form-register" onClick="onConfirmWhenRegister()">-->
										<button type="submit" class="button button-3d button-black nomargin" >Register</button>
                                    </div>
                                </form>
                            </div>

                        </div>


                    </div>

                </div>

                <div class="content-wrap" id="registerformsuccess" style="display:none;">
                    <div class="container clearfix">
						<div class="row"><div class="col-md-12"><center><img src="images/checkmark.png"><center></div></div>
						<div class="row">
							<div class="col-md-2"></div>
							<div class="col-md-8">
								<center><h2>Your registration completed successfully</h2>
								<a href="login.php">Back to login</a><center>
							</div>
							<div class="col-md-2"></div>
						</div>		
                    </div>
                </div>

            </section><!-- #content end -->			
			
            <!-- Footer
            ============================================= -->
            <?php include('footer.php'); ?>
            <!-- #footer end -->

        </div><!-- #wrapper end -->

        <!-- Go To Top
        ============================================= -->
        <div id="gotoTop" class="icon-angle-up"></div>

        <!-- Footer Scripts
        ============================================= -->
        <!-- External JavaScripts
        ============================================= -->
        <script type="text/javascript" src="js/jquery.js"></script>
        <script type="text/javascript" src="js/plugins.js"></script>
		
        <script type="text/javascript" src="js/functions.js"></script>
        <script type="text/javascript" src="complete-registration.js"></script>
    </body>
</html>