var $ = jQuery.noConflict();
var gSignOutNotSignOut = 'SignOut';
var gStartDate;
var gEndDate;
var VisitorsDataList;

//alert(TimeZoneName);

function onHostList() {
    $.ajax({
        "async": true,
        url: baseUrl + "HostComboLoadByCompanyId/" + COMPANYID,
        "method": "GET",
        "headers": {
            "Apikey": APIKEY,
            "cache-control": "no-cache"
        },
        success: function (response) {
            var HostList = response['HostList'];
            var html = '<option value="0" selected="true">All Host</option>';
            html = html + $.map(HostList, function (obj) {
                return '<option value=' + obj.HostId + '>' + obj.FullName + '</option>';
            }).join('');

            $('#HostList').html(html);
        }

    });
}

function onVisitorTypeListList() {
    $.ajax({
        "async": true,
        url: baseUrl + "VisitorTypeByCompanyId/" + COMPANYID,
        "method": "GET",
        "headers": {
            "Apikey": APIKEY,
            "cache-control": "no-cache"
        },
        success: function (response) {
            var VisitorTypeList = response['VisitorTypeList'];
            var html = '<option value="0" selected="true">All Visitor Type</option>';
            html = html + $.map(VisitorTypeList, function (obj) {
                return '<option value=' + obj.VisitorTypeId + '>' + obj.VisitorType + '</option>';
            }).join('');

            $('#VisitorTypeList').html(html);
        }

    });
}

function SignOut() {
    $('#SignOut').addClass('active');
    $('#NotSignOut').removeClass('active');
    gSignOutNotSignOut = 'SignOut';
    VisitorsDataList.fnDraw();
}

function NotSignOut() {
    $('#SignOut').removeClass('active');
    $('#NotSignOut').addClass('active');
    gSignOutNotSignOut = 'NotSignOut';
    VisitorsDataList.fnDraw();
}

/* function getVisitorsHistoryDataInfo() {
 $.ajax({
 "async": true,
 url: baseUrl + "visitor-list/" + COMPANYID + "/" + $('#HostList').val()+ "/" + $('#VisitorTypeList').val()+ "/" + gSignOutNotSignOut+ "/" + $("#StartDate").val()+ "/" + $("#EndDate").val(),
 "method": "GET",
 "headers": {
 "Apikey": APIKEY,
 "cache-control": "no-cache"
 },
 success: function (response){
 
 response = response['visitor'];
 var trHTML = '';
 $('#AllHostInfo').html('');
 trHTML ='<thead><tr>'+
 '<th style="width:7%; text-align: center;"></th>'+
 '<th style="width:15%; text-align: left;">Visitor</th>'+
 '<th style="width:19%; text-align: left;">Host</th>'+
 '<th style="width:19%; text-align: center;">Sign In</th>'+
 '<th style="width:19%; text-align: center;">Sign Out</th>'+
 '<th style="width:10%; text-align: center;">Duration</th>'+
 '<th style="width:10%; text-align: center;">Visitor Type</th>'+
 '</tr></thead>';
 
 $.each(response, function (key, value) {
 
 var HostId = value.HostId;
 var visitorSignOutTime = value.SignOutTime;
 var visitorSignInTime = value.SignInTime;
 if (value.MobileNo == null){
 var MobileNo = '';
 } else {
 var MobileNo = value.MobileNo;
 }
 
 if (value.EmailAddress == null){
 var EmailAddress = '';
 } else {
 var EmailAddress = value.EmailAddress;
 }
 
 if (value.EstDuration == null){
 var durationTime = '';
 } else {
 var durationTime = value.EstDuration;
 }        
 
 if (value.VisitorType == null){
 var VisitorType = '';
 } else {
 var VisitorType = value.VisitorType;
 }
 
 trHTML +='<tr><a href="#"><td class="chip"><img src=' + value.ImagePath + '  alt="Visitor Image" height="41" width="40"><b>' +
 '</td><td><b>' + value.VisitorName + '</b></br>' + value.VisitorCompany +
 '</td><td><a onClick="getHostInfoData('+HostId+')" href="javascript:void(0);" data-toggle="modal" data-target="#myModal"><b>' + value.FullName + '</b></a><br>' +MobileNo+
 '</td><td style="text-align: center;">' + visitorSignInTime +
 '</td><td style="text-align: center;">' + visitorSignOutTime +
 '</td><td style="text-align: center;">' + durationTime +
 '</td><td style="text-align: center;">' + VisitorType +
 '</td></tr>';
 
 });
 $('#AllHostInfo').append(trHTML);
 }
 });
 } */

function getHostInfoData(hostId) {

    $.ajax({
        "async": true,
        url: baseUrl + "hostinfo/" + hostId,
        "method": "GET",
        "headers": {
            "Apikey": APIKEY,
            "cache-control": "no-cache"
        },
        success: function (response) {
            var response = response['hostinfo'];
            var tabletrHTML = '';
            $.each(response, function (key, value) {
                tabletrHTML = '<tbody>' +
                        '<tr></td><td>Host</td><td>' + value.FullName + '</td></tr>' +
                        '<tr></td><td>Department</td><td>' + value.DivisionName + '</td></tr>' +
                        '<tr></td><td>Job Title</td><td>' + value.JobTitle + '</td></tr>' +
                        '<tr></td><td>Mobile No</td><td>' + value.MobileNo + '</td></tr>' +
                        '<tr></td><td>Desk Phone No</td><td>' + value.DeskPhoneNo + '</td></tr>' +
                        '<tr></td><td>Email Address</td><td>' + value.EmailAddress + '</td></tr>' +
                        '<tr></td><td>Company</td><td>' + value.CompanyName + '</td></tr>' +
                        '<tbody>';
            });
            $('#HostInfo').html(tabletrHTML);
        }
    });
}

$(function () {

    onHostList();
    onVisitorTypeListList();

    $('#HostList').change(function () {
        VisitorsDataList.fnDraw();
    });

    $('#VisitorTypeList').change(function () {
        VisitorsDataList.fnDraw();
    });

    $("#StartDate").datepicker({
        dateFormat: 'yy-mm-dd',
        onSelect: function (selectedDate) {
            //gStartDate = selectedDate;
            VisitorsDataList.fnDraw();
        }
    }).datepicker("setDate", new Date());

    $("#EndDate").datepicker({
        dateFormat: 'yy-mm-dd',
        onSelect: function (selectedDate) {
            //gEndDate = selectedDate;
            VisitorsDataList.fnDraw();
        }
    }).datepicker("setDate", new Date());


    $('body').animate({
        opacity: 1
    }, 500, function () {

        VisitorsDataList = $('#AllVisitorsDataList').dataTable({
            "bFilter": true,
            "bSort": true,
            "bInfo": true,
            "bPaginate": true,
            "bSortClasses": false,
            "bProcessing": true,
            "bServerSide": true,
            "aaSorting": [[4, 'DESC']],
            "sPaginationType": "full_numbers",
            "aLengthMenu": [[25, 50, 100], [25, 50, 100]],
            "iDisplayLength": 25,
            //"sScrollX" : "100%",
            "sAjaxSource": baseUrl + "visitors-datalist",
            "fnDrawCallback": function (oSettings) {

            },
            "fnServerData": function (sSource, aoData, fnCallback) {

                aoData.push({
                    "name": "CompanyId",
                    "value": COMPANYID
                });
                aoData.push({
                    "name": "TimeZoneName",
                    "value": TimeZoneName
                });
                aoData.push({
                    "name": "HostId",
                    "value": $('#HostList').val()
                });
                aoData.push({
                    "name": "VisitorTypeId",
                    "value": $('#VisitorTypeList').val()
                });
                aoData.push({
                    "name": "SignOutNotSignOut",
                    "value": gSignOutNotSignOut
                });
                aoData.push({
                    "name": "StartDate",
                    "value": $("#StartDate").val()
                });
                aoData.push({
                    "name": "EndDate",
                    "value": $("#EndDate").val()
                });

                $.ajax({
                    "dataType": 'json',
                    "type": "POST",
                    "url": sSource,
                    "headers": {"Apikey": APIKEY},
                    "data": aoData,
                    "success": fnCallback
                });
            },
            "aoColumns": [{
                    //EmployeeId	
                    "bVisible": false,
                    "bSortable": false
                }, {
                    //photo
                    "sClass": "text_Center",
                    "sWidth": "7%",
                    "bSortable": false
                }, {
                    //Visitor
                    "sClass": "text_Left",
                    "sWidth": "15%",
                    "bSortable": false
                }, {
                    //Host
                    "sClass": "text_Left",
                    "sWidth": "20%",
                    "bSortable": false
                }, {
                    //Sign In
                    "sClass": "text_Center",
                    "sWidth": "19%",
                    "bSortable": true
                }, {
                    //Sign Out
                    "sClass": "text_Center",
                    "sWidth": "19%",
                    "bSortable": false
                }, {
                    //Duration
                    "sClass": "text_Center",
                    "sWidth": "10%",
                    "bSortable": false
                }, {
                    //Visitor Type
                    "sClass": "text_Center",
                    "sWidth": "10%",
                    "bSortable": false
                }]
        });
    });

});



