		
<script type="text/javascript">
	if (APIKEY != '' && COMPANYID != '' && ISCOMPANYADMIN == 1) {
		document.write(
			'<div class="top_full_w"><div class="container clearfix"><ul class="TopList">'+
				'<li>'+COMPANYNAME+'</li>'+
				'<li><a data-mce-href="#" href="javascript:void(0);" onClick="onConfirmWhenLoginOut()">Log Out</a></li>'+
			'</ul></div></div>'
		);
	}else {
		document.write();
	}
</script>

<div class="clearfix"></div>
<header id="header" class="full-header">
	
    <div id="header-wrap">

        <div class="container clearfix">
            <div id="primary-menu-trigger"><i class="icon-reorder"></i></div>

            <!-- Logo
            ============================================= -->
            <div id="logo">
                <a href="index.php" class="standard-logo" data-dark-logo="images/logo.png"><img src="images/logo.png" alt="Logo"></a>
                <a href="index.php" class="retina-logo" data-dark-logo="images/logo@2x.png"><img src="images/logo@2x.png" alt="Logo"></a>
            </div><!-- #logo end -->

            <!-- Primary Navigation 
			============================================= -->
            <nav id="primary-menu">

                <ul>
                    <li><a href="index.php"><div>Home</div></a></li>                              
                    <script type="text/javascript">	
                        //master_language_setting.php
                        if (APIKEY != '' && COMPANYID != '' && ISCOMPANYADMIN == 1) {
                            document.write(
                                    '<li><a href="dashboard.php"><div>Dashboard</div></a></li>' +
                                    '<li><a href="#"><div>Manage</div></a>' +
                                    '<ul>' +
                                    '<li><a href="employee_list.php"><div>Host List</div></a></li>' +
                                    '<li><a href="authorize_visitor_list.php"><div>Authorize Visitor List</div></a></li>' +
                                    '<li><a href="visitor_type_entry.php"><div>Visitor Type List</div></a></li>' +
                                    '<li><a href="event_entry.php"><div>Event List</div></a></li>' +
                                    '<li><a href="site_entry.php"><div>Site List</div></a></li>' +
                                    '<li><a href="company_entry.php"><div>My Settings</div></a></li>' +
                                    '<li><a href="master_language_setting.php"><div>Master Language Settings</div></a></li>' +
                                    '</ul>' +
                                    '</li>' +
                                    '<li><a href="visitors_list.php"><div>Visitors</div></a></li>' +
                                    '<li><a href="features.php"><div>Features</div></a></li>' +
                                    '<li><a href="pricing.php"><div>Pricing</div></a></li> ' +
                                    '<li><a href="faq.php"><div>FAQ</div></a></li>'
                                    );
                        } else {
                            document.write(
                                    '<li><a href="features.php"><div>Features</div></a></li>' +
                                    '<li><a href="pricing.php"><div>Pricing</div></a></li> ' +
                                    '<li><a href="faq.php"><div>FAQ</div></a></li>' +
                                    '<li><a href="register.php"><div>Register</div></a></li>' +                                    
                                    '<li><a href="login.php"><div>Login</div></a></li>'
                                    );
                        }

                        function onConfirmWhenLoginOut() {
                            localStorage.clear();
                            window.location = "login.php";
                        }

                    </script>					


                </ul>


                <!-- Top Search
                ============================================= -->
                <div id="top-search">
                    <a href="#" id="top-search-trigger"><i class="icon-search3"></i><i class="icon-line-cross"></i></a>
                    <form action="search.html" method="get">
                        <input type="text" name="q" class="form-control" value="" placeholder="Type then hit enter to search...">
                    </form>
                </div><!-- #top-search end -->

            </nav><!-- #primary-menu end -->

        </div>

    </div>

</header>




