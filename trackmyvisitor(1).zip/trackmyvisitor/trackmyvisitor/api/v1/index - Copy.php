<?php

//including the required files
require_once '../include/DbOperation.php';
require '.././libs/Slim/Slim.php';

\Slim\Slim::registerAutoloader();

$app = new \Slim\Slim();

include('../../baseurl.php');

/* *
 * URL: http://localhost/trackmyvisitor/v1/create-company
 * Parameters: CompanyName
 * Method: POST
 * */
$app->post('/create-company', function () use ($app) {
    verifyRequiredParams(array('CompanyName'));
    $response = array();
    $CompanyName = $app->request->post('CompanyName');
    $db = new DbOperation();
    $res = $db->createCompany($CompanyName);
    if ($res == 0) {
        $response["error"] = false;
        $response["message"] = "New Company Added Successfully";
        echoResponse(201, $response);
    } else if ($res == 1) {
        $response["error"] = true;
        $response["message"] = "Oops! An error occur during database operation. Please try after some time";
        echoResponse(200, $response);
    } else if ($res == 2) {
        $response["error"] = true;
        $response["message"] = "Sorry, this company name already existed";
        echoResponse(200, $response);
    }
});


/* *
 * URL: http://localhost/trackmyvisitor/v1/company
 * Parameters: none
 * Apikey: Put API Key in Request Header
 * Method: GET
 * */
$app->get('/company', function() use ($app) {
    $db = new DbOperation();
    $result = $db->getAllCompany();
    $response = array();
    $response['error'] = false;
    $response['Company'] = array();

    while ($row = $result->fetch_assoc()) {
        $temp = array();
        $temp['CompanyId'] = $row['CompanyId'];
        $temp['CompanyName'] = $row['CompanyName'];
        //$temp['api_key'] = $row['api_key'];
        array_push($response['Company'], $temp);
    }

    echoResponse(200, $response);
});

/* *
 * URL: http://localhost/trackmyvisitor/v1/employee-registration
 * Parameters: Id, FirstName, LastName, EmailAddress, CompanyName
 * Method: POST
 * */
$app->post('/employee-registration', function () use ($app) {
    verifyRequiredParams(array('FirstName', 'LastName', 'EmailAddress', 'CompanyName'));
    global $SiteBaseUrl;
    $response = array();
    $FirstName = $app->request->post('FirstName');
    $LastName = $app->request->post('LastName');
    $EmailAddress = $app->request->post('EmailAddress');
    $CompanyName = $app->request->post('CompanyName');

    $db = new DbOperation();
    $res = $db->employeeRegistration($FirstName, $LastName, $EmailAddress, $CompanyName, $SiteBaseUrl);

    if ($res['retval'] == 0) {
        $response["error"] = false;
        $response["CompanyId"] = $res['CompanyId'];
        $response["apikey"] = $res['apikey'];
        $response["message"] = "Please check your email for further instruction. Your device will be provisioned as soon as you respond to the welcome email.";
        echoResponse(201, $response);
    } else if ($res['retval'] == 1) {
        $response["error"] = true;
        $response["message"] = "Oops! An error occur during database operation. Please try after some time";
        echoResponse(200, $response);
    } else if ($res['retval'] == 2) {
        $response["error"] = true;
        $response["message"] = "Sorry, this company name already existed";
        echoResponse(200, $response);
    } else if ($res['retval'] == 3) {
        $response["error"] = true;
        $response["message"] = "Sorry, this email address already existed";
        echoResponse(200, $response);
    }
});

/* *
 * URL: http://localhost/trackmyvisitor/api/v1/employee-registration-web
 * Parameters: Id, FirstName, LastName, EmailAddress, CompanyName
 * Method: POST
 * */
$app->post('/employee-registration-web', function () use ($app) {
    verifyRequiredParams(array('FirstName', 'LastName', 'EmailAddress', 'CompanyName'));
    global $SiteBaseUrl;
    $response = array();
    $FirstName = $app->request->post('FirstName');
    $LastName = $app->request->post('LastName');
    $EmailAddress = $app->request->post('EmailAddress');
    $CompanyName = $app->request->post('CompanyName');
    $MobileNo = $app->request->post('MobileNo');

    $db = new DbOperation();
    $res = $db->employeeRegistrationWeb($FirstName, $LastName, $EmailAddress, $CompanyName, $MobileNo, $SiteBaseUrl);

    if ($res['retval'] == 0) {
        $response["error"] = 0;
        //$response["apikey"] = $res['apikey'];
        $response["message"] = "Please check your email for further instruction. Your device will be provisioned as soon as you respond to the welcome email.";
        echoResponse(201, $response);
    } else if ($res['retval'] == 1) {
        $response["error"] = 1;
        $response["message"] = "Oops! An error occur during database operation. Please try after some time";
        echoResponse(200, $response);
    } else if ($res['retval'] == 2) {
        $response["error"] = 2;
        $response["message"] = "Sorry, this company name already existed";
        echoResponse(200, $response);
    } else if ($res['retval'] == 3) {
        $response["error"] = 3;
        $response["message"] = "Sorry, this email address already existed";
        echoResponse(200, $response);
    }
});

/* *
 * URL: http://localhost/trackmyvisitor/v1/complete-registration
 * Parameters: EmailAddress, Password
 * Method: POST
 * */
$app->post('/complete-registration', function () use ($app) {
    verifyRequiredParams(array('EmailAddress', 'CompanyId'));
    $response = array();
    $EmailAddress = $app->request->post('EmailAddress');
    $Password = $app->request->post('Password');
    $ConfirmPassword = $app->request->post('ConfirmPassword');
    $CompanyId = $app->request->post('CompanyId');
    $db = new DbOperation();
    $res = $db->createEmployeePassword($EmailAddress, $Password, $ConfirmPassword, $CompanyId);

    if ($res == 0) {
        $response["error"] = 0;
        $response["message"] = "You are registration completed successfully";
        echoResponse(201, $response);
    } else if ($res == 1) {
        $response["error"] = 1;
        $response["message"] = "Oops! An error occur during database operation. Please try after some time";
        echoResponse(200, $response);
    } else if ($res == 2) {
        $response["error"] = 2;
        $response["message"] = "Mitch match your email address. Please Try Again";
        echoResponse(200, $response);
    } else if ($res == 3) {
        $response["error"] = 3;
        $response["message"] = "Mitch match your password";
        echoResponse(200, $response);
    } else if ($res == 4) {
        $response["error"] = 4;
        $response["message"] = "Mitch match your company id and email address";
        echoResponse(200, $response);
    }
});

/* *
 * URL: http://localhost/trackmyvisitor/api/v1/forgot-password-send-mail
 * Parameters: EmailAddress
 * Method: POST
 * */
$app->post('/forgot-password-send-mail', function () use ($app) {
    global $SiteBaseUrl;
    verifyRequiredParams(array('EmailAddress'));
    $response = array();
    $EmailAddress = $app->request->post('EmailAddress');
    $db = new DbOperation();
    $res = $db->ForgotPasswordSendMail($EmailAddress, $SiteBaseUrl);

    if ($res['retval'] == 0) {
        $response["error"] = 0;
        $response["mailaddress"] = $res['mailaddress'];
        $response["message"] = "You are registration completed successfully";
        echoResponse(201, $response);
    } else if ($res['retval'] == 1) {
        $response["mailaddress"] = '';
        $response["error"] = 1;
        $response["message"] = "Mitch match your email address. Please Try Again";
        echoResponse(200, $response);
    }
});

/* *
 * URL: http://localhost/trackmyvisitor/api/v1/reset-password
 * Parameters: Password
 * Method: POST
 * */
$app->post('/reset-password', function () use ($app) {
    verifyRequiredParams(array('EmailAddress', 'CompanyId'));
    $response = array();
    $EmailAddress = $app->request->post('EmailAddress');
    $Password = $app->request->post('Password');
    $ConfirmPassword = $app->request->post('ConfirmPassword');
    $CompanyId = $app->request->post('CompanyId');
    $db = new DbOperation();
    $res = $db->ResetPassword($EmailAddress, $Password, $ConfirmPassword, $CompanyId);

    if ($res == 0) {
        $response["error"] = 0;
        $response["message"] = "Your password has been changed succesfull.";
        echoResponse(201, $response);
    } else if ($res == 1) {
        $response["error"] = 1;
        $response["message"] = "Oops! An error occur during database operation. Please try after some time";
        echoResponse(200, $response);
    } else if ($res == 2) {
        $response["error"] = 2;
        $response["message"] = "Mitch match your email address. Please Try Again";
        echoResponse(200, $response);
    } else if ($res == 3) {
        $response["error"] = 3;
        $response["message"] = "Mitch match your password";
        echoResponse(200, $response);
    } else if ($res == 4) {
        $response["error"] = 4;
        $response["message"] = "Mitch match your company id and email address";
        echoResponse(200, $response);
    }
});

/* *
 * URL: http://localhost/trackmyvisitor/v1/check-registration/<EmailAddress>
 * Parameters: EmailAddress
 * Method: GET
 * */
$app->get('/check-registration/:EmailAddress', 'authenticateCheckRegistration', function ($EmailAddress) use ($app) {
    $db = new DbOperation();
    $response = array();
    $res = $db->CheckLoginRegistration($EmailAddress);
    if ($res == 0) {
        $response["error"] = false;
        $response["bRegistered"] = true;
        $response["message"] = "You are registration completed successfully";
        echoResponse(201, $response);
    } else if ($res == 1) {
        $response["error"] = true;
        $response["bRegistered"] = false;
        $response["message"] = "Invalid Email Address. Please try after some time";
        echoResponse(200, $response);
    } else if ($res == 2) {
        $response["error"] = true;
        $response["bRegistered"] = false;
        $response["message"] = "Oops! An error occur during database operation. Please try after some time";
        echoResponse(200, $response);
    }
});

/* *
 * URL: http://localhost/trackmyvisitor/v1/employee-list/<CompanyId>
 * Parameters: none
 * Apikey: Put API Key in Request Header
 * Method: GET
 * */

$app->get('/employee-list/:CompanyId', 'authenticateEmployee', function($CompanyId) use ($app) {
    $db = new DbOperation();
    global $ImageBaseUrl;
    $result = $db->getAllEmployeeList($CompanyId);
    $response = array();
    $response['error'] = false;
    $response['employee'] = array();

    while ($row = $result->fetch_assoc()) {
        $temp = array();
        $temp['Id'] = $row['Id'];
        $temp['FullName'] = $row['FullName'];
        $temp['EmailAddress'] = $row['EmailAddress'];
        $temp['CompanyName'] = $row['CompanyName'];
        $temp['EmployeeImage'] = $ImageBaseUrl . 'employees/' . $row['EmployeeImage'];
        array_push($response['employee'], $temp);
    }

    echoResponse(200, $response);
});

/* *
 * URL: http://localhost/trackmyvisitor/v1/employee-by-id/<CompanyId>
 * Parameters: none
 * Apikey: Put API Key in Request Header
 * Method: GET
 * */

$app->get('/employee-by-id/:CompanyId', 'authenticateEmployee', function($CompanyId) use ($app) {
    $db = new DbOperation();
    global $ImageBaseUrl;
    $result = $db->getEmployeeByCompanyId($CompanyId);
    $response = array();
    $response['error'] = false;
    $response['employee'] = array();

    while ($row = $result->fetch_assoc()) {
        $temp = array();
        $temp['EmployeeId'] = $row['Id'];

        if ($row['EmployeeImage'] == null) {
            $temp['EmployeeImage'] = $ImageBaseUrl . 'em.jpg';
        } else {
            $temp['EmployeeImage'] = $ImageBaseUrl . 'employees/' . $row['EmployeeImage'];
        }
        //$temp['EmployeeImage'] = $ImageBaseUrl . 'employees/' . $row['EmployeeImage'];
        $temp['EmployeeName'] = $row['FullName'];
        $temp['Division'] = $row['DivisionName'];
        $temp['EmailAddress'] = $row['EmailAddress'];
        $temp['CompanyName'] = $row['CompanyName'];
        array_push($response['employee'], $temp);
    }

    echoResponse(200, $response);
});

/* *
 * URL: http://localhost/trackmyvisitor/v1/employee-login
 * Parameters: EmailAddress, password
 * Method: POST
 * */
$app->post('/employee-login', function () use ($app) {
    verifyRequiredParams(array('EmailAddress', 'Password'));
    $EmailAddress = $app->request->post('EmailAddress');
    $Password = $app->request->post('Password');
    $db = new DbOperation();
    $response = array();
    if ($db->EmployeeLogin($EmailAddress, $Password)) {
        $Employee = $db->getEmployee($EmailAddress);
        $response['error'] = false;
        $response['Id'] = $Employee['Id'];
        $response['FullName'] = $Employee['FullName'];
        $response['EmailAddress'] = $Employee['EmailAddress'];
        $response['CompanyName'] = $Employee['CompanyName'];
        $response['CompanyId'] = $Employee['CompanyId'];
        $response['apikey'] = $Employee['api_key'];
        $response['IsCompanyAdmin'] = $Employee['IsCompanyAdmin'];
    } else {
        $response['error'] = true;
        $response['message'] = "Invalid Email Address or password";
    }
    echoResponse(200, $response);
});


$app->post('/host-create', 'authenticateCompanyAPIKey', function () use ($app) {
    verifyRequiredParams(array('Activation', 'FirstName', 'LastName', 'EmailAddress', 'JobTitle', 'SiteId', 'CompanyId', 'DivisionId'));
    $response = array();

    $IsActive = $app->request->post('Activation');
    if ($IsActive == 'true' || $IsActive == 'on') {
        $Activation = 1;
    } else {
        $Activation = 0;
    }

    $IsSendEmail = $app->request->post('SendEmail');
    if ($IsSendEmail == 'true' || $IsSendEmail == 'on') {
        $SendEmail = 1;
    } else {
        $SendEmail = 0;
    }

    $is_Host = $app->request->post('IsHost');
    if ($is_Host == 'true' || $is_Host == 'on') {
        $IsHost = 1;
    } else {
        $IsHost = 0;
    }

    $FirstName = $app->request->post('FirstName');
    $LastName = $app->request->post('LastName');
    $EmailAddress = $app->request->post('EmailAddress');
    $JobTitle = $app->request->post('JobTitle');
    $MobileNo = $app->request->post('MobileNo');
    $DeskPhoneNo = $app->request->post('DeskPhoneNo');
    $SiteId = $app->request->post('SiteId');
    $CompanyId = $app->request->post('CompanyId');
    $DivisionId = $app->request->post('DivisionId');
    $RecordId = $app->request->post('RecordId');

    if ($RecordId == '') {

        $db = new DbOperation();
        $res = $db->HostCreate($Activation, $FirstName, $LastName, $EmailAddress, $JobTitle, $MobileNo, $DeskPhoneNo, $SiteId, $CompanyId, $DivisionId, $SendEmail, $IsHost);

        if ($res['retval'] == 0) {
            $response["error"] = false;
            $response["EmployeeId"] = $res['EmployeeId'];
            $response["message"] = "New host added successfully";
            echoResponse(201, $response);
        } else if ($res['retval'] == 1) {
            $response["error"] = true;
            $response["EmployeeId"] = '';
            $response["message"] = "Oops! An error occur during database operation. Please try after some time";
            echoResponse(200, $response);
        } else if ($res['retval'] == 2) {
            $response["error"] = true;
            $response["EmployeeId"] = '';
            $response["message"] = "Sorry, this email address already existed";
            echoResponse(200, $response);
        }
    } else {

        $db = new DbOperation();
        $res = $db->HostUpdate($Activation, $FirstName, $LastName, $EmailAddress, $JobTitle, $MobileNo, $DeskPhoneNo, $SiteId, $CompanyId, $DivisionId, $SendEmail, $IsHost, $RecordId);
        if ($res['retval'] == 0) {
            $response["message"] = "Host Info. Updated successfully";
            echoResponse(200, $response);
        }
    }
});

/* *
 * URL: http://localhost/trackmyvisitor/api/v1/host-image-add-web/<EmployeeId>
 * Parameters: none
 * Apikey: Put API Key in Request Header
 * Method: POST
 * */
$app->post('/host-image-add-web/:EmployeeId', 'authenticateCompanyAPIKey', function($EmployeeId) use ($app) {
    verifyRequiredParams(array('EmployeeImage'));
    $ImagePath = $app->request->post('EmployeeImage');
    $response = array();
    $db = new DbOperation();

    $result = $db->updateEmployeeImageAdd($EmployeeId, $ImagePath);
    if ($result) {
        $response['error'] = false;
        $response['message'] = "host Image Added Successfully";
    } else {
        $response['error'] = true;
        $response['message'] = "Oops! An error occur during database operation. Please try after some time";
    }
    echoResponse(200, $response);
});

/* *
 * URL: http://localhost/trackmyvisitor/api/v1/visitor-logout/<VisitorId>
 * Parameters: VisitorId
 * Method: get
 * */
$app->get('/visitor-logout/:VisitorId', 'authenticateCompanyAPIKey', function ($VisitorId) use ($app) {
    $db = new DbOperation();
    $response = array();

    $result = $db->VisitorLogout($VisitorId);

    if ($result == 0) {
        $response["error"] = false;
        $response["message"] = "Logout Successfully";
        echoResponse(201, $response);
    } else if ($result == 1) {
        $response["error"] = true;
        $response["message"] = "Oops! An error occur during database operation. Please try after some time";
        echoResponse(200, $response);
    }
});


/* *
 * URL: http://localhost/trackmyvisitor/api/v1/employee-image-add/<EmployeeId>
 * Parameters: none
 * Apikey: Put API Key in Request Header
 * Method: POST
 * */

$app->post('/employee-image-add/:EmployeeId', 'authenticateCompanyAPIKey', function($EmployeeId) use ($app) {
    $db = new DbOperation();

    $result = $db->getEmployeeById($EmployeeId);
    $row = $result->fetch_assoc();
    $EmployeeName = $row['FullName'];

    $EmployeeImgName = str_replace(" ", "-", strtolower($EmployeeName));
    $tempFile = $_FILES['EmployeeImage']['tmp_name'];
    $targetPath = '../../images/employees/';
    $ImagePath = $EmployeeId . '-' . $EmployeeImgName . '.jpg';
    $targetFile = $targetPath . $ImagePath;

    if (file_exists($targetFile)) {
        unlink($targetFile);
    }
    if (!move_uploaded_file($tempFile, $targetFile)) {
        die('Failed to Move');
    }

    $result = $db->updateEmployeeImageAdd($EmployeeId, $ImagePath);
    $response = array();
    if ($result) {
        $response['error'] = false;
        $response['message'] = "Employee Image Added Successfully";
    } else {
        $response['error'] = true;
        $response['message'] = "Oops! An error occur during database operation. Please try after some time";
    }
    echoResponse(200, $response);
});

/* *
 * URL: http://localhost/trackmyvisitor/v1/create-visitor
 * Parameters: VisitorName, VisitorCompany, EmployeeId, ImagePath
 * Method: POST
 * */
$app->post('/create-visitor', 'authenticateVisitor', function () use ($app) {
    global $ImageBaseUrl;
    verifyRequiredParams(array('VisitorName', 'VisitorCompany', 'VisitorTypeId', 'EmployeeId'));
    $response = array();

    date_default_timezone_set('Asia/Dhaka');
    $datetime = date("Y-m-d-H-i-s");

    $VisitorCompany = $app->request->post('VisitorCompany');
    $VisitorName = $app->request->post('VisitorName');
    $VisitorTypeId = $app->request->post('VisitorTypeId');
    $EmployeeId = $app->request->post('EmployeeId');

    $VisitorImgName = str_replace(" ", "-", strtolower($VisitorName));

    $tempFile = $_FILES['ImagePath']['tmp_name'];
    $targetPath = '../../images/visitors/';
    //$fileName = $datetime.'-'.$_FILES['ImagePath']['name'];
    //$ImagePath = $EmployeeId.'-'.$VisitorName.'-'.$datetime.'.jpg';
    $ImagePath = $EmployeeId . '-' . $VisitorImgName . '.jpg';
    $targetFile = $targetPath . $ImagePath;

    if (file_exists($targetFile)) {
        unlink($targetFile);
    }
    if (!move_uploaded_file($tempFile, $targetFile)) {
        die('Failed to Move');
    }

    $db = new DbOperation();
    $res = $db->createVisitor($VisitorName, $VisitorCompany, $VisitorTypeId, $EmployeeId, $ImagePath, $ImageBaseUrl);
    if ($res['retval'] == 0) {
        $response["error"] = false;
        $response["VisitorId"] = $res['VisitorId'];
        $response["message"] = "New Visitor Added Successfully";
        echoResponse(201, $response);
    } else if ($res['retval'] == 1) {
        $response["error"] = true;
        $response["VisitorId"] = '';
        $response["message"] = "Oops! An error occur during database operation. Please try after some time";
        echoResponse(200, $response);
    }
});

/* *
 * URL: http://localhost/trackmyvisitor/v1/visitor-list/<CompanyId>
 * Parameters: none
 * Apikey: Put API Key in Request Header
 * Method: GET
 * */

$app->get('/visitor-list/:CompanyId', 'authenticateVisitor', function($CompanyId) use ($app) {
    $db = new DbOperation();
    global $ImageBaseUrl;
    $result = $db->getAllVisitorList($CompanyId); //
    $response = array();
    $response['error'] = false;
    $response['visitor'] = array();

    while ($row = $result->fetch_assoc()) {
        $temp = array();
        $temp['ImagePath'] = $ImageBaseUrl . 'visitors/' . $row['ImagePath'];
        $temp['FullName'] = $row['FullName'];
        $temp['VisitorType'] = $row['VisitorType'];
        $temp['VisitorName'] = $row['VisitorName'];
        $temp['VisitorCompany'] = $row['VisitorCompany'];

        if ($row['SignOutTime']) {
            $dt = new DateTime($row['SignInTime'], new DateTimezone('Asia/Dhaka'));
            $temp['SignInTime'] = $dt->format('g:i a');
        } else {
            $temp['SignInTime'] = '';
        }
        //$temp['SignInTime'] =  $dt->format('F j, Y, g:i a');
        //$temp['SignOutTime'] = $row['SignOutTime'];  
        if ($row['SignOutTime'] != '0000-00-00 00:00:00') {
            $dtOut = new DateTime($row['SignOutTime'], new DateTimezone('Asia/Dhaka'));
            $temp['SignOutTime'] = $dtOut->format('g:i a');
        } else {
            $temp['SignOutTime'] = ' ';
        }

        $temp['Phone'] = $row['Phone'];
        $temp['EmailAddress'] = $row['EmailAddress'];
        $temp['EstDuration'] = convertToHoursMins(abs($row['EstDuration']), '%02d hours %02d minutes');

        array_push($response['visitor'], $temp);
    }

    echoResponse(200, $response);
});

/* *
 * URL: http://localhost/trackmyvisitor/v1/company-info/<CompanyId>
 * Parameters: none
 * Apikey: Put API Key in Request Header
 * Method: GET
 * */

$app->get('/company-info/:CompanyId', 'authenticateVisitor', function($CompanyId) use ($app) {
    $db = new DbOperation();
    global $ImageBaseUrl;
    $result = $db->getCompanyInformation($CompanyId);
    $response = array();
    $response['error'] = false;
    $response['company'] = array();
    $data = array();

    $tempCompany = '';
    while ($row = $result->fetch_assoc()) {
        $data[] = $row;
    }
    $temp = array();
    foreach ($data as $row) {
        $temp2 = array();
        $companyId = $row['CompanyId'];
        $CompanyImageUrl = $ImageBaseUrl . 'employees/thumbs/' . $row['CompanyImage'];
        $temp2['VisitorTypeId'] = $row['VisitorTypeId'];
        $temp2['VisitorType'] = $row['VisitorType'];
        $temp[] = $temp2;
    }
    $lastArray = array();
    $lastArray['CompanyImageUrl'] = $CompanyImageUrl;
    $lastArray['VisitorTypeList'] = $temp;
    array_push($response['company'], $lastArray);

    echoResponse(200, $response);
});

/* *
 * URL: http://localhost/trackmyvisitor/v1/daily-visitor/<CompanyId>
 * Parameters: none
 * Apikey: Put API Key in Request Header
 * Method: GET
 * */

$app->get('/daily-visitor/:CompanyId', 'authenticateVisitor', function($CompanyId) use ($app) {
    $db = new DbOperation();
    $result = $db->getDailyVisitor($CompanyId);
    $response = array();
    $response['error'] = false;
    $response['visitor-summary'] = array();

    while ($row = $result->fetch_assoc()) {
        $temp = array();
        $temp['TotalVisitor'] = $row['totalVisitor'];
        $temp['date'] = $row['date'];
        array_push($response['visitor-summary'], $temp);
    }

    echoResponse(200, $response);
});

/* *
 * URL: http://localhost/trackmyvisitor/api/v1/busiest-hosts/<CompanyId>
 * Parameters: none
 * Apikey: Put API Key in Request Header
 * Method: GET
 * */

$app->get('/busiest-hosts/:CompanyId', 'authenticateCompanyAPIKey', function($CompanyId) use ($app) {
    $db = new DbOperation();
    $result = $db->getBusiestHosts($CompanyId);
    $response = array();
    $response['error'] = false;
    $response['busiest-hosts'] = array();

    while ($row = $result->fetch_assoc()) {
        $temp = array();
        $temp['name'] = $row['FullName'];
        $temp['y'] = $row['totalVisitor'];
        array_push($response['busiest-hosts'], $temp);
    }

    echoResponse(200, $response);
});

/* *
 * URL: http://localhost/trackmyvisitor/api/v1/signed-in-visitors/<CompanyId>
 * Parameters: none
 * Apikey: Put API Key in Request Header
 * Method: GET
 * */

$app->get('/signed-in-visitors/:CompanyId', 'authenticateCompanyAPIKey', function($CompanyId) use ($app) {
    $db = new DbOperation();
    $result = $db->getSignedInVisitors($CompanyId);
    $response = array();
    $response['error'] = false;
    $response['visitor'] = array();

    while ($row = $result->fetch_assoc()) {
        $temp = array();
        if ($row['SignInTime']) {
            $dt = new DateTime($row['SignInTime'], new DateTimezone('Asia/Dhaka'));
            $temp['SignedIn'] = $dt->format('g:i a');
        } else {
            $temp['SignedIn'] = '';
        }
        //$temp['SignedIn'] = $row['SignInTime'];
        $temp['Visitor'] = $row['VisitorName'];
        $temp['Host'] = $row['FullName'] . ', ' . $row['CompanyName'];
        $temp['SiteName'] = $row['SiteName'];

        array_push($response['visitor'], $temp);
    }

    echoResponse(200, $response);
});


/* * division-combo-load
 * URL: http://localhost/trackmyvisitor/v1/getAllSiteByCompanyId/<CompanyId>
 * Parameters: none
 * Apikey: Put API Key in Request Header
 * Method: GET
 * salam
 * */
$app->get('/site-combo-load/:CompanyId', 'authenticateEmployee', function($CompanyId) use ($app) {
    $db = new DbOperation();
    $result = $db->getAllSiteByCompanyId($CompanyId);

    $response = array();
    $response['error'] = false;
    $response['siteList'] = array();

    while ($row = $result->fetch_assoc()) {
        $temp = array();
        $temp['siteId'] = $row['siteId'];
        $temp['siteName'] = $row['siteName'];
        array_push($response['siteList'], $temp);
    }

    echoResponse(200, $response);
});

/* *
 * URL: http://localhost/trackmyvisitor/v1/getAllSiteByCompanyId/<CompanyId>
 * Parameters: none
 * Apikey: Put API Key in Request Header
 * Method: GET
 * */
$app->get('/division-combo-load/:CompanyId', 'authenticateEmployee', function($CompanyId) use ($app) {
    $db = new DbOperation();

    $siId = $app->request->get('siId');
    $result = $db->getAllDivisionByCompanyId($CompanyId, $siId);
    $response = array();
    $response['error'] = false;
    $response['divisionList'] = array();

    while ($row = $result->fetch_assoc()) {
        $temp = array();
        $temp['DivisionId'] = $row['DivisionId'];
        $temp['DivisionName'] = $row['DivisionName'];
        array_push($response['divisionList'], $temp);
    }
    echoResponse(200, $response);
});

/* *
 * URL: http://localhost/trackmyvisitor/v1/employee-list/<CompanyId>
 * Parameters: none
 * Apikey: Put API Key in Request Header
 * Method: GET
 * */
$app->get('/host-list-edit/:EmployeeId', 'authenticateEmployee', function($EmployeeId) use ($app) {
    $db = new DbOperation();
    global $ImageBaseUrl;
    $result = $db->getAllHostListEdit($EmployeeId);
    $response = array();
    $response['error'] = false;
    $response['employeeEdit'] = array();

    while ($row = $result->fetch_assoc()) {
        $temp = array();
        $temp['Id'] = $row['Id'];
        $temp['FirstName'] = $row['FirstName'];
        $temp['LastName'] = $row['LastName'];
        $temp['EmailAddress'] = $row['EmailAddress'];
        $temp['JobTitle'] = $row['JobTitle'];
        $temp['DeskPhoneNo'] = $row['DeskPhoneNo'];
        $temp['MobileNo'] = $row['MobileNo'];
        $temp['CompanyId'] = $row['CompanyId'];
        $temp['IsHost'] = $row['IsHost'];
        $temp['SendEmail'] = $row['SendEmail'];
        $temp['EmployeeImage'] = $row['EmployeeImage'];

        $temp['SiteId'] = $row['SiteId'];
        $temp['DivisionId'] = $row['DivisionId'];

        array_push($response['employeeEdit'], $temp);
    }
    echoResponse(200, $response);
});


/* *
 * URL: http://localhost/trackmyvisitor/v1/authorize-visitor-list-by-companyid/<CompanyId>
 * Parameters: none
 * Apikey: Put API Key in Request Header
 * Method: GET
 * */

$app->get('/authorize-visitor-list-by-companyid/:CompanyId', 'authenticateEmployee', function($CompanyId) use ($app) {
    $db = new DbOperation();
    global $ImageBaseUrl;
    $result = $db->getAuthorizeVisitorByCompanyId($CompanyId);
    $response = array();
    $response['error'] = false;
    $response['authorize-visitor'] = array();

    while ($row = $result->fetch_assoc()) {
        $temp = array();
        $temp['SpecialVisitorId'] = $row['SpecialVisitorId'];
        $temp['SpecialVisitorName'] = $row['SpecialVisitorName'];
        $temp['SpecialVisitorCompany'] = $row['SpecialVisitorCompany'];
        $temp['VisitorType'] = $row['VisitorType'];
        $temp['EmailAddress'] = $row['EmailAddress'];
        $temp['Phone'] = $row['Phone'];
        $temp['AppointmentDate'] = $row['AppointmentDate'];
        $temp['QRAttachment'] = $ImageBaseUrl . 'barcodeimage/' . $row['QRAttachment'];
        if ($row['VisitorImage'] == null) {
            $temp['VisitorImage'] = $ImageBaseUrl . 'em.jpg';
        } else {
            $temp['VisitorImage'] = $ImageBaseUrl . 'visitors/' . $row['VisitorImage'];
        }
        $temp['FullName'] = $row['FullName'];
        $temp['EventName'] = $row['EventName'];
        array_push($response['authorize-visitor'], $temp);
    }

    echoResponse(200, $response);
});

/* *
 * URL: http://localhost/trackmyvisitor/v1/drop-down-event-list-by-companyid/<CompanyId>
 * Parameters: none
 * Apikey: Put API Key in Request Header
 * Method: GET
 * */

$app->get('/drop-down-event-list-by-companyid/:CompanyId', 'authenticateEmployee', function($CompanyId) use ($app) {
    $db = new DbOperation();
    global $ImageBaseUrl;
    $result = $db->getDropDownEventListByCompanyId($CompanyId);
    $response = array();
    $response['error'] = false;
    $response['event'] = array();

    while ($row = $result->fetch_assoc()) {
        $temp = array();
        $temp['EventId'] = $row['EventId'];
        $temp['EventName'] = $row['EventName'];
        array_push($response['event'], $temp);
    }

    echoResponse(200, $response);
});

/* *
 * URL: http://localhost/trackmyvisitor/v1/drop-down-employee-list-by-companyid/<CompanyId>
 * Parameters: none
 * Apikey: Put API Key in Request Header
 * Method: GET
 * */

$app->get('/drop-down-employee-list-by-companyid/:CompanyId', 'authenticateEmployee', function($CompanyId) use ($app) {
    $db = new DbOperation();
    global $ImageBaseUrl;
    $result = $db->getDropDownEmployeeListByCompanyId($CompanyId);
    $response = array();
    $response['error'] = false;
    $response['event'] = array();

    while ($row = $result->fetch_assoc()) {
        $temp = array();
        $temp['Id'] = $row['Id'];
        $temp['FullName'] = $row['FullName'];
        array_push($response['event'], $temp);
    }

    echoResponse(200, $response);
});

/* *
 * URL: http://localhost/trackmyvisitor/v1/drop-down-Visitor-Type-list-by-companyid/<CompanyId>
 * Parameters: none
 * Apikey: Put API Key in Request Header
 * Method: GET
 * */

$app->get('/drop-down-Visitor-Type-list-by-companyid/:CompanyId', 'authenticateEmployee', function($CompanyId) use ($app) {
    $db = new DbOperation();
    global $ImageBaseUrl;
    $result = $db->getDropDownVisitorTypeListByCompanyId($CompanyId);
    $response = array();
    $response['error'] = false;
    $response['visitor-type'] = array();

    while ($row = $result->fetch_assoc()) {
        $temp = array();
        $temp['VisitorTypeId'] = $row['VisitorTypeId'];
        $temp['VisitorType'] = $row['VisitorType'];
        array_push($response['visitor-type'], $temp);
    }

    echoResponse(200, $response);
});


/* *
 * URL: http://localhost/trackmyvisitor/api/v1/authorize-visitor-create
 * Parameters: $SpecialVisitorName, $SpecialVisitorCompany, $EmailAddress, $Phone, $EmployeeId, $AppointmentDate, $QRAttachment, $EventId
 * Method: POST 
 * */

$app->post('/authorize-visitor-create', 'authenticateCompanyAPIKey', function () use ($app) {
    global $ImageBaseUrl;
    verifyRequiredParams(array('SpecialVisitorName', 'SpecialVisitorCompany', 'EmailAddress', 'Phone', 'EmployeeId', 'AppointmentDate', 'EventId'));
    $response = array();

    $SpecialVisitorName = $app->request->post('SpecialVisitorName');
    $SpecialVisitorCompany = $app->request->post('SpecialVisitorCompany');
    $EmailAddress = $app->request->post('EmailAddress');
    $Phone = $app->request->post('Phone');
    $EmployeeId = $app->request->post('EmployeeId');
    $AppointmentDate = $app->request->post('AppointmentDate');
    $EventId = $app->request->post('EventId');
    $VisitorTypeId = $app->request->post('VisitorTypeId');
    $VisitorTypeName = $app->request->post('VisitorTypeName');
    $EventName = $app->request->post('EventName');
    $EmployeeName = $app->request->post('EmployeeName');
    $RecordId = $app->request->post('RecordId');

    $db = new DbOperation();
    $res = $db->AuthorizeVisitorCreate($RecordId, $SpecialVisitorName, $SpecialVisitorCompany, $EmailAddress, $Phone, $EmployeeId, $AppointmentDate, $EventId, $EventName, $EmployeeName, $ImageBaseUrl, $VisitorTypeId, $VisitorTypeName);

    if ($res['retval'] == 0) {
        $response["error"] = false;
        $response["SpecialVisitorId"] = $res['SpecialVisitorId'];
        $response["QRAttachment"] = $res['QRAttachment'];
        if ($RecordId != 0) {
            $response["message"] = "Authorize visitor edited successfully.";
        } else {
            $response["message"] = "New authorize visitor added successfully.";
        }
        echoResponse(201, $response);
    } else if ($res['retval'] == 1) {
        $response["error"] = true;
        $response["SpecialVisitorId"] = '';
        $response["QRAttachment"] = '';
        $response["message"] = "Oops! An error occur during database operation. Please try after some time.";
        echoResponse(200, $response);
    } else if ($res['retval'] == 2) {
        $response["error"] = true;
        $response["SpecialVisitorId"] = '';
        $response["QRAttachment"] = '';
        $response["message"] = "Sorry, this email address already existed.";
        echoResponse(200, $response);
    }
});


/* *
 * URL: http://localhost/trackmyvisitor/v1/authorize-visitor-list-edit/<EmployeeId>
 * Parameters: none
 * Apikey: Put API Key in Request Header
 * Method: GET
 * */

$app->get('/authorize-visitor-list-edit/:SpecialVisitorId', 'authenticateEmployee', function($SpecialVisitorId) use ($app) {
    $db = new DbOperation();
    global $ImageBaseUrl;
    $result = $db->getAuthorizeVisitorById($SpecialVisitorId);
    $response = array();
    $response['error'] = false;
    $response['visitorEdit'] = array();

    while ($row = $result->fetch_assoc()) {
        $temp = array();
        $temp['SpecialVisitorId'] = $row['SpecialVisitorId'];
        $temp['SpecialVisitorName'] = $row['SpecialVisitorName'];
        $temp['SpecialVisitorCompany'] = $row['SpecialVisitorCompany'];
        $temp['EmailAddress'] = $row['EmailAddress'];
        $temp['Phone'] = $row['Phone'];
        $temp['EmployeeId'] = $row['EmployeeId'];
        $temp['AppointmentDate'] = $row['AppointmentDate'];
        $temp['EventId'] = $row['EventId'];
        $temp['VisitorImage'] = $row['VisitorImage'];
        $temp['QRAttachment'] = $row['QRAttachment'];
        $temp['VisitorTypeId'] = $row['VisitorTypeId'];
        array_push($response['visitorEdit'], $temp);
    }

    echoResponse(200, $response);
});

/* *
 * URL: http://localhost/trackmyvisitor/api/v1/authorize-visitor-image-add/<EmployeeId>
 * Parameters: none
 * Apikey: Put API Key in Request Header
 * Method: POST
 * */
$app->post('/authorize-visitor-image-add/:EmployeeId', 'authenticateCompanyAPIKey', function($EmployeeId) use ($app) {
    verifyRequiredParams(array('VisitorImage'));
    $VisitorImage = $app->request->post('VisitorImage');
    $response = array();
    $db = new DbOperation();

    $result = $db->updateAuthorizeVisitorImageAdd($EmployeeId, $VisitorImage);
    if ($result) {
        $response['error'] = false;
        $response['message'] = "Authorize visitor photo added successfully";
    } else {
        $response['error'] = true;
        $response['message'] = "Oops! An error occur during database operation. Please try after some time";
    }
    echoResponse(200, $response);
});

$app->post('/visitor-type-create', 'authenticateCompanyAPIKey', function () use ($app) {
    verifyRequiredParams(array('VisitorType'));
    $response = array();

    $VisitorType = $app->request->post('VisitorType');
    $CompanyId = $app->request->post('CompanyId');
    $RecordId = $app->request->post('RecordId');

    if ($RecordId == '') {
        $db = new DbOperation();
        $res = $db->VisitorTypeCreate($VisitorType, $CompanyId);
        if ($res['retval'] == 0) {
            $response["error"] = false;
            $response["message"] = "New Visitor Type added successfully";
            echoResponse(201, $response);
        } else if ($res['retval'] == 1) {
            $response["error"] = true;
            $response["message"] = "Oops! An error occur during database operation. Please try after some time";
            echoResponse(200, $response);
        } else if ($res['retval'] == 2) {
            $response["error"] = true;
            $response["message"] = "Sorry, This visitor type already existed";
            echoResponse(200, $response);
        }
    } else {
        $db = new DbOperation();
        $res = $db->VisitorTypeUpdate($VisitorType, $CompanyId, $RecordId);
        if ($res['retval'] == 0) {
            $response["error"] = false;
            $response["message"] = "Visitor Type Updated successfully";
            echoResponse(201, $response);
        } else if ($res['retval'] == 1) {
            $response["error"] = true;
            $response["message"] = "Oops! An error occur during database operation. Please try after some time";
            echoResponse(200, $response);
        } else if ($res['retval'] == 2) {
            $response["error"] = true;
            $response["message"] = "Sorry, This visitor type already existed";
            echoResponse(200, $response);
        }
    }
});

$app->get('/get-visitor-type/:CompanyId', 'authenticateCompanyAPIKey', function($CompanyId) use ($app) {
    $db = new DbOperation();
    $result = $db->getVisitorsTypeList($CompanyId);
    $response = array();
    $response['error'] = false;
    $response['visitor-type'] = array();

    while ($row = $result->fetch_assoc()) {
        $temp = array();
        $temp['VisitorTypeId'] = $row['VisitorTypeId'];
        $temp['VisitorType'] = $row['VisitorType'];
        $temp['CompanyName'] = $row['CompanyName'];
        array_push($response['visitor-type'], $temp);
    }
    echoResponse(200, $response);
});
$app->get('/visitor-type-list-edit/:VisitorTypeId', 'authenticateEmployee', function($VisitorTypeId) use ($app) {
    $db = new DbOperation();
    $result = $db->getAllVisitorTypeListEdit($VisitorTypeId);
    $response = array();
    $response['error'] = false;
    $response['visitorTypeEdit'] = array();

    while ($row = $result->fetch_assoc()) {
        $temp = array();
        $temp['VisitorTypeId'] = $row['VisitorTypeId'];
        $temp['VisitorType'] = $row['VisitorType'];
        array_push($response['visitorTypeEdit'], $temp);
    }
    echoResponse(200, $response);
});
$app->post('/event-create', 'authenticateCompanyAPIKey', function () use ($app) {
    verifyRequiredParams(array('EventName'));
    $response = array();

    $EventName = $app->request->post('EventName');
    $CompanyId = $app->request->post('CompanyId');
    $RecordId = $app->request->post('RecordId');

    if ($RecordId == '') {
        $db = new DbOperation();
        $res = $db->EventCreate($EventName, $CompanyId);
        if ($res['retval'] == 0) {
            $response["error"] = false;
            $response["message"] = "New event added successfully";
            echoResponse(201, $response);
        } else if ($res['retval'] == 1) {
            $response["error"] = true;
            $response["message"] = "Oops! An error occur during database operation. Please try after some time";
            echoResponse(200, $response);
        } else if ($res['retval'] == 2) {
            $response["error"] = true;
            $response["message"] = "Sorry, This event already existed";
            echoResponse(200, $response);
        }
    } else {
        $db = new DbOperation();
        $res = $db->EventUpdate($EventName, $CompanyId, $RecordId);
        if ($res['retval'] == 0) {
            $response["error"] = false;
            $response["message"] = "Event Updated successfully";
            echoResponse(201, $response);
        } else if ($res['retval'] == 1) {
            $response["error"] = true;
            $response["message"] = "Oops! An error occur during database operation. Please try after some time";
            echoResponse(200, $response);
        } else if ($res['retval'] == 2) {
            $response["error"] = true;
            $response["message"] = "Sorry, This event already existed";
            echoResponse(200, $response);
        }
    }
});
$app->get('/get-visitor-type/:CompanyId', 'authenticateCompanyAPIKey', function($CompanyId) use ($app) {
    $db = new DbOperation();
    $result = $db->getVisitorsTypeList($CompanyId);
    $response = array();
    $response['error'] = false;
    $response['visitor-type'] = array();

    while ($row = $result->fetch_assoc()) {
        $temp = array();
        $temp['VisitorTypeId'] = $row['VisitorTypeId'];
        $temp['VisitorType'] = $row['VisitorType'];
        $temp['CompanyName'] = $row['CompanyName'];
        array_push($response['visitor-type'], $temp);
    }
    echoResponse(200, $response);
});

$app->get('/get-event/:CompanyId', 'authenticateCompanyAPIKey', function($CompanyId) use ($app) {
    $db = new DbOperation();
    $result = $db->getEventList($CompanyId);
    $response = array();
    $response['error'] = false;
    $response['event'] = array();

    while ($row = $result->fetch_assoc()) {
        $temp = array();
        $temp['EventId'] = $row['EventId'];
        $temp['EventName'] = $row['EventName'];
        $temp['CompanyName'] = $row['CompanyName'];
        array_push($response['event'], $temp);
    }
    echoResponse(200, $response);
});
$app->get('/event-list-edit/:VisitorTypeId', 'authenticateEmployee', function($EventId) use ($app) {
    $db = new DbOperation();
    $result = $db->getAllEventListEdit($EventId);
    $response = array();
    $response['error'] = false;
    $response['EventEdit'] = array();

    while ($row = $result->fetch_assoc()) {
        $temp = array();
        $temp['EventId'] = $row['EventId'];
        $temp['EventName'] = $row['EventName'];
        array_push($response['EventEdit'], $temp);
    }
    echoResponse(200, $response);
});
$app->get('/event-delete/:EventId', 'authenticateEmployee', function($EventId) use ($app) {
    $db = new DbOperation();
    $result = $db->eventDelete($EventId);
    $response = array();
    $response['error'] = false;
    $response['EventDelete'] = array();
    echoResponse(200, $response);
});
$app->get('/employee-delete/:EmployeeId', 'authenticateEmployee', function($EmployeeId) use ($app) {
    $db = new DbOperation();
    $result = $db->EmployeeDelete($EmployeeId);
    $response = array();
    $response['error'] = false;
    $response['EmployeeDelete'] = array();
    echoResponse(200, $response);
});

$app->get('/visitor-type-delete/:VisitorTypeId', 'authenticateEmployee', function($VisitorTypeId) use ($app) {
    $db = new DbOperation();
    $result = $db->visitorTypeDelete($VisitorTypeId);
    $response = array();
    $response['error'] = false;
    $response['EventDelete'] = array();

    echoResponse(200, $response);
});


//Site Entry ---Salam---
$app->post('/site-create', 'authenticateCompanyAPIKey', function () use ($app) {
    verifyRequiredParams(array('SiteName', 'EmergencyContact'));
    $response = array();
    $SiteName = $app->request->post('SiteName');
    $LangTitle = $app->request->post('LangTitle');
    $LangCode = $app->request->post('LangCode');
    $TimeZone = $app->request->post('TimeZone');
    $StreetAddress = $app->request->post('StreetAddress');
    $EmergencyContact = $app->request->post('EmergencyContact');
    $SystemAssistantContct = $app->request->post('SystemAssistantContct');
    $CompanyId = $app->request->post('CompanyId');
    $RecordId = $app->request->post('RecordId');

    if ($RecordId == '') {

        $db = new DbOperation();
        $res = $db->SiteCreate($SiteName, $LangTitle, $LangCode, $TimeZone, $StreetAddress, $EmergencyContact, $SystemAssistantContct, $CompanyId);

        if ($res['retval'] == 0) {
            $response["error"] = false;
            $response["message"] = "New site added successfully";
            echoResponse(201, $response);
        } else if ($res['retval'] == 1) {
            $response["error"] = true;
            $response["message"] = "Oops! An error occur during database operation. Please try after some time";
            echoResponse(200, $response);
        } else if ($res['retval'] == 2) {
            $response["error"] = true;
            $response["message"] = "Sorry, this site name already existed";
            echoResponse(200, $response);
        }
    } else {
        $db = new DbOperation();
        $res = $db->SiteUpdate($SiteName, $LangTitle, $LangCode, $TimeZone, $StreetAddress, $EmergencyContact, $SystemAssistantContct, $CompanyId, $RecordId);
        if ($res['retval'] == 0) {
            $response["error"] = false;
            $response["message"] = "Site Info. Updated successfully";
            echoResponse(201, $response);
        } else if ($res['retval'] == 1) {
            $response["error"] = true;
            $response["message"] = "Oops! An error occur during database operation. Please try after some time";
            echoResponse(200, $response);
        } else if ($res['retval'] == 2) {
            $response["error"] = true;
            $response["message"] = "Sorry, this site name already existed";
            echoResponse(200, $response);
        }
    }
});
//Get site-list---Salam--
$app->get('/get-site/:CompanyId', 'authenticateCompanyAPIKey', function($CompanyId) use ($app) {
    $db = new DbOperation();
    $result = $db->getSiteList($CompanyId);
    $response = array();
    $response['error'] = false;
    $response['site'] = array();

    while ($row = $result->fetch_assoc()) {
        $temp = array();
        $temp['SiteId'] = $row['SiteId'];
        $temp['SiteName'] = $row['SiteName'];
        $temp['StreetAddress'] = $row['StreetAddress'];
        $temp['EmergencyContact'] = $row['EmergencyContact'];
        $temp['SystemAssistantContct'] = $row['SystemAssistantContct'];
        $temp['CompanyName'] = $row['CompanyName'];
        array_push($response['site'], $temp);
    }
    echoResponse(200, $response);
});

//site-edit----salam
$app->get('/site-list-edit/:SiteId', 'authenticateEmployee', function($SiteId) use ($app) {
    $db = new DbOperation();
    $result = $db->getAllSiteListEdit($SiteId);
    $response = array();
    $response['error'] = false;
    $response['SiteEdit'] = array();

    while ($row = $result->fetch_assoc()) {
        $temp = array();
        $temp['SiteId'] = $row['SiteId'];
        $temp['SiteName'] = $row['SiteName'];
        $temp['LangCode'] = $row['LangCode'];
        $temp['LangTitle'] = $row['LangTitle'];
        $temp['TimeZone'] = $row['TimeZone'];
        $temp['StreetAddress'] = $row['StreetAddress'];
        $temp['EmergencyContact'] = $row['EmergencyContact'];
        $temp['SystemAssistantContct'] = $row['SystemAssistantContct'];
        array_push($response['SiteEdit'], $temp);
    }
    echoResponse(200, $response);
});


//Site delete-----------salam-------------
$app->get('/site-delete/:SiteId', 'authenticateEmployee', function($SiteId) use ($app) {
    $db = new DbOperation();
    $result = $db->siteDelete($SiteId);
    $response = array();
    $response['error'] = false;
    $response['SiteDelete'] = array();
    echoResponse(200, $response);
});

$app->post('/company-create', 'authenticateCompanyAPIKey', function () use ($app) {
    verifyRequiredParams(array('CompanyName'));
    $response = array();

    $CompanyName = $app->request->post('CompanyName');
    $LogoName = $app->request->post('LogoName');
    //$CompanyId = $app->request->post('CompanyId');
    $RecordId = $app->request->post('RecordId');

    if ($RecordId == '') {
        $db = new DbOperation();
        $res = $db->CompanyCreate($CompanyName, $LogoName);
        if ($res['retval'] == 0) {
            $response["error"] = false;
            $response["message"] = "New company added successfully";
            echoResponse(201, $response);
        } else if ($res['retval'] == 1) {
            $response["error"] = true;
            $response["message"] = "Oops! An error occur during database operation. Please try after some time";
            echoResponse(200, $response);
        } else if ($res['retval'] == 2) {
            $response["error"] = true;
            $response["message"] = "Sorry, This company already existed";
            echoResponse(200, $response);
        }
    } else {
        $db = new DbOperation();
        $res = $db->CompanyUpdate($CompanyName, $LogoName, $RecordId);
        if ($res['retval'] == 0) {
            $response["error"] = false;
            $response["message"] = "Company Info. Updated successfully";
            echoResponse(201, $response);
        } else if ($res['retval'] == 1) {
            $response["error"] = true;
            $response["message"] = "Oops! An error occur during database operation. Please try after some time";
            echoResponse(200, $response);
        } else if ($res['retval'] == 2) {
            $response["error"] = true;
            $response["message"] = "Sorry, This Company Info. already existed";
            echoResponse(200, $response);
        }
    }
});

$app->get('/get-company/:CompanyId', 'authenticateCompanyAPIKey', function($CompanyId) use ($app) {
    $db = new DbOperation();
    $result = $db->getCompanyList($CompanyId);
    $response = array();
    $response['error'] = false;
    $response['company'] = array();

    while ($row = $result->fetch_assoc()) {
        $temp = array();
        $temp['CompanyId'] = $row['CompanyId'];
        $temp['CompanyName'] = $row['CompanyName'];
        $temp['CompanyImage'] = $row['CompanyImage'];
        //$temp['IsSiteAdmin'] = $row['IsSiteAdmin'];
        array_push($response['company'], $temp);
    }
    echoResponse(200, $response);
});

//company edit-----salam-----
$app->get('/company-list-edit/:CompId', 'authenticateEmployee', function($CompId) use ($app) {
    $db = new DbOperation();
    $result = $db->getAllCompanyListEdit($CompId);
    $response = array();
    $response['error'] = false;
    $response['CompanyEdit'] = array();

    while ($row = $result->fetch_assoc()) {
        $temp = array();
        $temp['CompanyId'] = $row['CompanyId'];
        $temp['CompanyName'] = $row['CompanyName'];
        $temp['CompanyImage'] = $row['CompanyImage'];
        array_push($response['CompanyEdit'], $temp);
    }
    echoResponse(200, $response);
});

//company delete ----------salam
$app->get('/company-delete/:CompanyId', 'authenticateEmployee', function($CompanyId) use ($app) {
    $db = new DbOperation();
    $result = $db->CompanyDelete($CompanyId);
    $response = array();
    $response['error'] = false;
    $response['CompanyDelete'] = array();
    echoResponse(200, $response);
});

$app->get('/get-company/:CompanyId', 'authenticateCompanyAPIKey', function($CompanyId) use ($app) {
    $db = new DbOperation();
    $result = $db->getCompanyList();
    $response = array();
    $response['error'] = false;
    $response['company'] = array();

    while ($row = $result->fetch_assoc()) {
        $temp = array();
        $temp['CompanyId'] = $row['CompanyId'];
        $temp['CompanyName'] = $row['CompanyName'];
        $temp['CompanyImage'] = $row['CompanyImage'];
        array_push($response['company'], $temp);
    }
    echoResponse(200, $response);
});

function echoResponse($status_code, $response) {
    $app = \Slim\Slim::getInstance();
    $app->status($status_code);
    $app->contentType('application/json');
    echo json_encode($response);
}

function verifyRequiredParams($required_fields) {
    $error = false;
    $error_fields = "";
    $request_params = $_REQUEST;

    if ($_SERVER['REQUEST_METHOD'] == 'PUT') {
        $app = \Slim\Slim::getInstance();
        parse_str($app->request()->getBody(), $request_params);
    }

    foreach ($required_fields as $field) {
        if (!isset($request_params[$field]) || strlen(trim($request_params[$field])) <= 0) {
            $error = true;
            $error_fields .= $field . ', ';
        }
    }

    if ($error) {
        $response = array();
        $app = \Slim\Slim::getInstance();
        $response["error"] = true;
        $response["message"] = 'Required field(s) ' . substr($error_fields, 0, -2) . ' is missing or empty';
        echoResponse(400, $response);
        $app->stop();
    }
}

function authenticateEmployee(\Slim\Route $route) {
    $headers = apache_request_headers();
    $response = array();
    $app = \Slim\Slim::getInstance();
    if (isset($headers['Apikey'])) {
        $db = new DbOperation();
        $api_key = $headers['Apikey'];
        if (!$db->isValidEmployee($api_key)) {
            $response["error"] = true;
            $response["message"] = "Access Denied. Invalid Api key";
            echoResponse(401, $response);
            $app->stop();
        }
    } else {
        $response["error"] = true;
        $response["message"] = "Api key is misssing";
        echoResponse(400, $response);
        $app->stop();
    }
}

function authenticateCheckRegistration(\Slim\Route $route) {
    $headers = apache_request_headers();
    $response = array();
    $app = \Slim\Slim::getInstance();
    if (isset($headers['Apikey'])) {
        $db = new DbOperation();
        $api_key = $headers['Apikey'];
        if (!$db->isValidCheckRegistration($api_key)) {
            $response["error"] = true;
            $response["message"] = "Access Denied. Invalid Api key";
            echoResponse(401, $response);
            $app->stop();
        }
    } else {
        $response["error"] = true;
        $response["message"] = "Api key is misssing";
        echoResponse(400, $response);
        $app->stop();
    }
}

function authenticateVisitor(\Slim\Route $route) {
    $headers = apache_request_headers();
    $response = array();
    $app = \Slim\Slim::getInstance();
//    print_r($headers);
    if (isset($headers['Apikey'])) {
        $db = new DbOperation();
        $api_key = $headers['Apikey'];
        if (!$db->isValidVisitor($api_key)) {
            $response["error"] = true;
            $response["message"] = "Access Denied. Invalid Api key";
            echoResponse(401, $response);
            $app->stop();
        }
    } else {
        $response["error"] = true;
        $response["message"] = "Api key is misssing";
        echoResponse(400, $response);
        $app->stop();
    }
}

function authenticateCompanyAPIKey(\Slim\Route $route) {
    $headers = apache_request_headers();
    $response = array();
    $app = \Slim\Slim::getInstance();
    if (isset($headers['Apikey'])) {
        $db = new DbOperation();
        $api_key = $headers['Apikey'];
        if (!$db->isValidCompanyAPIKey($api_key)) {
            $response["error"] = true;
            $response["message"] = "Access Denied. Invalid Api key";
            echoResponse(401, $response);
            $app->stop();
        }
    } else {
        $response["error"] = true;
        $response["message"] = "Api key is misssing";
        echoResponse(400, $response);
        $app->stop();
    }
}

function convertToHoursMins($time, $format = '%d:%d') {
    settype($time, 'integer');
    if ($time < 1) {
        return;
    }
    $time = floor($time / 60); //Seconds to minutes
    $hours = floor($time / 60);
    $minutes = ($time % 60);
    return sprintf($format, $hours, $minutes);
}

$app->run();
