<?php
// Database1:
$DB_NAME = "trackmyv_visitor_db";
$DB_USER = "trackmyv_visitor";
$DB_PASSWORD = "A#ZGgZRQ5PHP";

// Database2:
// $DB_NAME = "softtest_trackmyvisitor_db";
// $DB_USER = "softtest_myvisit";
// $DB_PASSWORD = "haU8WmdAS1";

$mysqli = new mysqli("localhost", $DB_USER, $DB_PASSWORD, $DB_NAME); 

if($mysqli->connect_error)
{
    die("$mysqli->connect_errno: $mysqli->connect_error");
}
$CompanyId = 112;
$query = "SELECT CompanyId, CompanyName FROM t_company WHERE CompanyId=? ORDER BY CompanyName LIMIT 1";

$stmt = $mysqli->stmt_init();
if(!$stmt->prepare($query))
{
    print "Failed to prepare statement\n";
}
else
{
    $stmt->bind_param("i", $CompanyId);
	$stmt->execute();
	$result = $stmt->get_result();
	$row = $result->fetch_array(MYSQLI_NUM);		
	print_r($row);
}

$stmt->close();
$mysqli->close();
?>