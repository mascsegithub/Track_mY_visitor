<?php

class DbOperation {

    private $con;

    function __construct() {
        require_once dirname(__FILE__) . '/DbConnect.php';
        $db = new DbConnect();
        $this->con = $db->connect();
    }

    //Method to create a new Company Name
    public function createCompany($CompanyName) {
        if (!$this->isCompanyNameExists($CompanyName)) {
            $apikey = $this->generateApiKey();
            $stmt = $this->con->prepare("INSERT INTO t_company(CompanyName, api_key) values(?, ?)");
            $stmt->bind_param("ss", $CompanyName, $apikey);
            $result = $stmt->execute();
            $stmt->close();
            if ($result) {
                return 0;
            } else {
                return 1;
            }
        } else {
            return 2;
        }
    }

    //Method to fetch all company from database
    public function getAllCompany() {
        $stmt = $this->con->prepare("SELECT * FROM t_company");
        $stmt->execute();
        $company = $stmt->get_result();
        $stmt->close();
        return $company;
    }

    //Method to create a new Employee Company Site Name
    public function employeeRegistration($FirstName, $LastName, $EmailAddress, $CompanyName, $SiteBaseUrl) {

        require_once('phpmailer/class.phpmailer.php');
        $mail = new PHPMailer();

        if (!$this->isEmployeeEmailExists($EmailAddress)) {
            if (!$this->isCompanyNameExists($CompanyName)) {
                try {
                    $this->con->begin_transaction;

                    //Company
                    $apikey = $this->generateApiKey();
                    $stmt = $this->con->prepare("INSERT INTO t_company(CompanyName, api_key) values(?, ?)");
                    $stmt->bind_param("ss", $CompanyName, $apikey);
                    $result = $stmt->execute();
                    $lastCompanyId = $this->con->insert_id;

                    //site
                    $SiteName = 'Head Office';
                    $stmt = $this->con->prepare("INSERT INTO t_site(SiteName, CompanyId) values(?, ?)");
                    $stmt->bind_param("si", $SiteName, $lastCompanyId);
                    $result = $stmt->execute();
                    $lastSiteId = $this->con->insert_id;

                    //Division
                    $DivisionName = "Administration";
                    $stmt = $this->con->prepare("INSERT INTO t_division(DivisionName, SiteId) values(?, ?)");
                    $stmt->bind_param("si", $DivisionName, $lastSiteId);
                    $result = $stmt->execute();
                    $lastDivisionId = $this->con->insert_id;

                    //visitortype Visitor
                    $Visitor = "Visitor";
                    $stmt = $this->con->prepare("INSERT INTO t_visitortype(VisitorType, CompanyId) values(?, ?)");
                    $stmt->bind_param("si", $Visitor, $lastCompanyId);
                    $result = $stmt->execute();

                    //visitortype Contractor
                    $Contractor = "Contractor";
                    $stmt = $this->con->prepare("INSERT INTO t_visitortype(VisitorType, CompanyId) values(?, ?)");
                    $stmt->bind_param("si", $Contractor, $lastCompanyId);
                    $result = $stmt->execute();

                    //visitortype Delivery
                    $Delivery = "Delivery";
                    $stmt = $this->con->prepare("INSERT INTO t_visitortype(VisitorType, CompanyId) values(?, ?)");
                    $stmt->bind_param("si", $Delivery, $lastCompanyId);
                    $result = $stmt->execute();

                    $FullName = $FirstName . ' ' . $LastName;
                    //$Password = $this->generatePassword();
                    //$Pword = $this->generatePassword();
                    //$Password = md5($Pword);
                    $IsSiteAdmin = 1;
                    $IsCompanyAdmin = 1;
                    $stmt = $this->con->prepare("INSERT INTO t_employee(FirstName, LastName, UserName, FullName, EmailAddress, IsSiteAdmin, IsCompanyAdmin, CompanyId, SiteId, DivisionId) values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
                    $stmt->bind_param("sssssiiiii", $FirstName, $LastName, $FirstName, $FullName, $EmailAddress, $IsSiteAdmin, $IsCompanyAdmin, $lastCompanyId, $lastSiteId, $lastDivisionId);
                    $result = $stmt->execute();

                    $this->con->commit();
                    $stmt->close();
                    if ($result) {
                        //Mail Option
                        $name = 'Track My Visitor Admin';
                        $email = 'admin@trackmyvisitor.com';
                        $subject = 'Track My Visitor Account';
                        $toemail = $EmailAddress; // Your Email Address
                        $toname = ''; // Your Name
                        $mail->SetFrom($email, '');
                        $mail->AddAddress($toemail, '');
                        $mail->Subject = $subject;

                        $Step1 = '<h1>Welcome</h1><br><h4><b>Thank you for choosing Track My Visitor.</b></h4><br><p>Please click the link below to verify your email and complete registration for the Track My Visitor Management Portal.</p><br>';
                        $Step2 = '<a target="_blank" href="' . $SiteBaseUrl . 'complete-registration.php?first_name=' . $FirstName . '&last_name=' . $LastName . '&email=' . $EmailAddress . '&companyid=' . $lastCompanyId . '"><span style="padding:5px 10px; background:#00cc17; color:#FFFFFF; border-radius:5px;">VERIFY EMAIL</span></a><br><br><br>';
                        $Step3 = "If clicking the link above doesn't work, please copy and paste the following URL in a new browser window instead:<br><br>";

                        $referrer = '<a target="_blank" href="' . $SiteBaseUrl . 'complete-registration.php?first_name=' . $FirstName . '&last_name=' . $LastName . '&email=' . $EmailAddress . '&companyid=' . $lastCompanyId . '">' . $SiteBaseUrl . 'complete-registration.php?first_name=' . $FirstName . '&last_name=' . $LastName . '&email=' . $EmailAddress . '&companyid=' . $lastCompanyId . '</a>';

                        $body = "$Step1 $Step2 $Step3 $referrer";

                        $mail->MsgHTML($body);

                        $sendEmail = $mail->Send();

                        //return 0;
                        $retval['retval'] = 0;
                        $retval['CompanyId'] = $lastCompanyId;
                        $retval['apikey'] = $apikey;
                        return $retval;
                    } else {
                        //return 1;
                        $retval['retval'] = 1;
                        $retval['CompanyId'] = $lastCompanyId;
                        $retval['apikey'] = $apikey;
                        return $retval;
                    }
                } catch (Exception $e) {
                    $this->con->rollback();
                }
            } else {
                //return 2;
                $retval['retval'] = 2;
                $retval['CompanyId'] = $lastCompanyId;
                $retval['apikey'] = $apikey;
                return $retval;
            }
        } else {
            //return 3;
            $retval['retval'] = 3;
            $retval['CompanyId'] = $lastCompanyId;
            $retval['apikey'] = $apikey;
            return $retval;
        }
    }

    //Method to create a new Employee Company Site Name
    public function employeeRegistrationWeb($FirstName, $LastName, $EmailAddress, $CompanyName, $MobileNo, $SiteBaseUrl, $LanguageTitleId, $TimeZoneId, $LanTitleText) {

        require_once('phpmailer/class.phpmailer.php');
        $mail = new PHPMailer();

        if (!$this->isEmployeeEmailExists($EmailAddress)) {
            if (!$this->isCompanyNameExists($CompanyName)) {
                try {
                    $this->con->begin_transaction;

                    //Company
                    $apikey = $this->generateApiKey();
                    $stmt = $this->con->prepare("INSERT INTO t_company(CompanyName, api_key,LangCode,TimeZoneId) values(?, ?,?,?)");
                    $stmt->bind_param("ssss", $CompanyName, $apikey, $LanguageTitleId, $TimeZoneId);
                    $result = $stmt->execute();
                    $lastCompanyId = $this->con->insert_id;

                    //site
                    $SiteName = "Head Office";
                    $stmt = $this->con->prepare("INSERT INTO t_site(SiteName, CompanyId) values(?, ?)");
                    $stmt->bind_param("si", $SiteName, $lastCompanyId);
                    $result = $stmt->execute();
                    $lastSiteId = $this->con->insert_id;

                    //Division
                    $DivisionName = "Administration";
                    $stmt = $this->con->prepare("INSERT INTO t_division(DivisionName, SiteId) values(?, ?)");
                    $stmt->bind_param("si", $DivisionName, $lastSiteId);
                    $result = $stmt->execute();
                    $lastDivisionId = $this->con->insert_id;

                    //visitortype Visitor
                    $Visitor = "Visitor";
                    $stmt = $this->con->prepare("INSERT INTO t_visitortype(VisitorType, CompanyId) values(?, ?)");
                    $stmt->bind_param("si", $Visitor, $lastCompanyId);
                    $result = $stmt->execute();

                    //visitortype Contractor
                    $Contractor = "Contractor";
                    $stmt = $this->con->prepare("INSERT INTO t_visitortype(VisitorType, CompanyId) values(?, ?)");
                    $stmt->bind_param("si", $Contractor, $lastCompanyId);
                    $result = $stmt->execute();

                    //visitortype Delivery
                    $Delivery = "Delivery";
                    $stmt = $this->con->prepare("INSERT INTO t_visitortype(VisitorType, CompanyId) values(?, ?)");
                    $stmt->bind_param("si", $Delivery, $lastCompanyId);
                    $result = $stmt->execute();


                    $FullName = $FirstName . ' ' . $LastName;
                    $IsSiteAdmin = 1;
                    $IsCompanyAdmin = 1;
                    $stmt = $this->con->prepare("INSERT INTO t_employee(FirstName, LastName, UserName, FullName, EmailAddress, MobileNo, IsSiteAdmin, IsCompanyAdmin, CompanyId, SiteId, DivisionId) values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
                    $stmt->bind_param("ssssssiiiii", $FirstName, $LastName, $FirstName, $FullName, $EmailAddress, $MobileNo, $IsSiteAdmin, $IsCompanyAdmin, $lastCompanyId, $lastSiteId, $lastDivisionId);
                    $result = $stmt->execute();

                    //set language
                    $stmt = $this->con->prepare("INSERT INTO t_language_text(LangCode,LangTextName,LangText, CompanyId)
                            SELECT LangCode,`LangTextName`, `LangText`,$lastCompanyId FROM `t_setting_language_string` WHERE `LangCode` = ? ");
                    $stmt->bind_param("s", $LanguageTitleId);
                    $result = $stmt->execute();


                    $this->con->commit();
                    $stmt->close();
                    if ($result) {
                        //Mail Option
                        $name = 'Track My Visitor Admin';
                        $email = 'admin@trackmyvisitor.com';
                        $subject = 'Track My Visitor Account';
                        $toemail = $EmailAddress; // Your Email Address
                        $toname = ''; // Your Name
                        $mail->SetFrom($email, '');
                        $mail->AddAddress($toemail, '');
                        $mail->Subject = $subject;

                        $Step = '<p>To access your track my visitor trial, please 
						<a target="_blank" href="' . $SiteBaseUrl . 'complete-registration.php?first_name=' . $FirstName . '&last_name=' . $LastName . '&email=' . $EmailAddress . '&companyid=' . $lastCompanyId . '">register</a> and get started right away</p><br><br>';

                        $referrer = '-track my visitor Team';

                        $body = "$Step $referrer";

                        $mail->MsgHTML($body);

                        $sendEmail = $mail->Send();

                        //return 0;
                        $retval['retval'] = 0;
                        //$retval['apikey'] = '';
                        return $retval;
                    } else {
                        //return 1;
                        $retval['retval'] = 1;
                        //$retval['apikey'] = '';
                        return $retval;
                    }
                } catch (Exception $e) {
                    $this->con->rollback();
                }
            } else {
                //return 2;
                $retval['retval'] = 2;
                //$retval['apikey'] = '';
                return $retval;
            }
        } else {
            //return 3;
            $retval['retval'] = 3;
            //$retval['apikey'] = '';
            return $retval;
        }
    }

    //Method to create a new Web Host Entry
    public function HostCreate($Activation, $FirstName, $LastName, $EmailAddress, $JobTitle, $MobileNo, $DeskPhoneNo, $SiteId, $CompanyId, $DivisionId, $SendEmail, $IsHost) {

        require_once('phpmailer/class.phpmailer.php');
        $mail = new PHPMailer();

        if (!$this->isEmployeeEmailExists($EmailAddress)) {

            $FullName = $FirstName . ' ' . $LastName;

            $stmt = $this->con->prepare("INSERT INTO t_employee(FirstName, LastName, UserName, FullName, EmailAddress, JobTitle, MobileNo, DeskPhoneNo, SiteId, CompanyId, DivisionId, SendEmail, IsHost) values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->bind_param("ssssssssiiiii", $FirstName, $LastName, $FirstName, $FullName, $EmailAddress, $JobTitle, $MobileNo, $DeskPhoneNo, $SiteId, $CompanyId, $DivisionId, $SendEmail, $IsHost);
            $result = $stmt->execute();
            $lastEmployeeId = $this->con->insert_id;

            $stmt->close();
            if ($result) {
                if ($SendEmail == 1) {
                    //Mail Option
                    $name = 'Track My Visitor Admin';
                    $email = 'admin@trackmyvisitor.com';
                    $subject = 'Track My Visitor Account';
                    $toemail = $EmailAddress; // Your Email Address
                    $toname = ''; // Your Name
                    $mail->SetFrom($email, '');
                    $mail->AddAddress($toemail, '');
                    $mail->Subject = $subject;

                    $Step1 = $FullName . ',';

                    $Step2 = 'Welcome to Track my visitor!<br>';

                    $Step3 = "You are receiving this email because you have just been added as a new 'Host' to the Track my visitor system at Softworks.<br><br>";

                    $referrer = '';

                    $body = "$Step1 $Step2 $Step3 $referrer";

                    $mail->MsgHTML($body);

                    $sendEmail = $mail->Send();
                }

                //return 0;
                $retval['retval'] = 0;
                $retval['EmployeeId'] = $lastEmployeeId;
                return $retval;
            } else {
                //return 1;
                $retval['retval'] = 1;
                $retval['EmployeeId'] = $lastEmployeeId;
                return $retval;
            }
        } else {
            //return 2;
            $retval['retval'] = 2;
            $retval['EmployeeId'] = '';
            return $retval;
        }
    }

    //Method to create a new create Employee Password
    public function createEmployeePassword($EmailAddress, $Password, $ConfirmPassword, $CompanyId) {

        if ($this->isEmployeeEmailExists($EmailAddress)) {
            if ($Password == $ConfirmPassword) {
                if ($this->isCompanyIdEmailAddressExists($EmailAddress, $CompanyId)) {
                    $Pword = md5($Password);
                    $stmt = $this->con->prepare("UPDATE t_employee SET Password = ? WHERE EmailAddress=? AND CompanyId=?");
                    $stmt->bind_param("ssi", $Pword, $EmailAddress, $CompanyId);
                    $result = $stmt->execute();

                    $stmt->close();
                    if ($result) {
                        return 0;
                    } else {
                        return 1;
                    }
                } else {
                    return 4;
                }
            } else {
                return 3;
            }
        } else {
            return 2;
        }
    }

    //Method to create a new create Employee Password
    public function ForgotPasswordSendMail($EmailAddress, $SiteBaseUrl) {
        require_once('phpmailer/class.phpmailer.php');
        $mail = new PHPMailer();

        if ($this->isEmployeeEmailExists($EmailAddress)) {

            $stmt = $this->con->prepare("SELECT Id, CompanyId, EmailAddress FROM t_employee WHERE EmailAddress=?");
            $stmt->bind_param("s", $EmailAddress);
            $stmt->execute();
            $result = $stmt->get_result()->fetch_assoc();
            $CompanyId = $result['CompanyId'];

            //Mail Option
            $name = 'Track My Visitor Admin';
            $email = 'admin@trackmyvisitor.com';
            $subject = 'Track My Visitor Account';
            $toemail = $EmailAddress; // Your Email Address
            $toname = ''; // Your Name
            $mail->SetFrom($email, '');
            $mail->AddAddress($toemail, '');
            $mail->Subject = $subject;

            $Step1 = 'Please click the following link to set new password for track my visitor account:<br><br>';

            //$Step2 = '<a target="_blank" href="'.$SiteBaseUrl.'forgot-password.php?mail='.crypt($EmailAddress,'st').'">'.$SiteBaseUrl.'forgot-password.php?emid='.mail($EmailAddress,'st').'</a><br><br>';
            $Step2 = '<a target="_blank" href="' . $SiteBaseUrl . 'forgot-password.php?cid=' . $CompanyId . '&mail=' . $EmailAddress . '">' . $SiteBaseUrl . 'forgot-password.php?cid=' . $CompanyId . '&mail=' . $EmailAddress . '</a><br><br>';

            $Step3 = "If you've received this mail in error, it's likely that another user entered your email address by mistake while trying to reset a password.<br><br>";

            $referrer = 'Best regards,<br>The track my visitor Support Team';

            $body = "$Step1 $Step2 $Step3 $referrer";

            $mail->MsgHTML($body);

            $sendEmail = $mail->Send();

            $retval['retval'] = 0;
            $retval['mailaddress'] = $EmailAddress;
            return $retval;
        } else {
            $retval['retval'] = 1;
            $retval['mailaddress'] = $EmailAddress;
            return $retval;
        }
    }

    //Method to create a Reset Password
    public function ResetPassword($EmailAddress, $Password, $ConfirmPassword, $CompanyId) {

        if ($this->isEmployeeEmailExists($EmailAddress)) {
            if ($Password == $ConfirmPassword) {
                if ($this->isCompanyIdEmailAddressExists($EmailAddress, $CompanyId)) {
                    $Pword = md5($Password);
                    $stmt = $this->con->prepare("UPDATE t_employee SET Password = ? WHERE EmailAddress=? AND CompanyId=?");
                    $stmt->bind_param("ssi", $Pword, $EmailAddress, $CompanyId);
                    $result = $stmt->execute();
                    $stmt->close();
                    if ($result > 0) {
                        return 0;
                    } else {
                        return 1;
                    }
                } else {
                    return 4;
                }
            } else {
                return 3;
            }
        } else {
            return 2;
        }
    }

    //Method to fetch all employee from database
    public function getAllEmployeeList($CompanyId) {
        $stmt = $this->con->prepare("SELECT t_employee.Id, t_employee.FullName, t_employee.EmailAddress, t_employee.EmployeeImage, t_company.CompanyName, t_site.SiteName, t_division.DivisionName
		FROM t_employee
		INNER JOIN t_company ON (t_employee.CompanyId = t_company.CompanyId)
		INNER JOIN t_site ON (t_site.CompanyId = t_company.CompanyId)
		INNER JOIN t_division ON (t_division.SiteId = t_site.SiteId AND t_division.DivisionId = t_employee.DivisionId)		
		WHERE t_employee.CompanyId=?
		ORDER BY t_employee.FullName");
        $stmt->bind_param("i", $CompanyId);
        $stmt->execute();
        $employee = $stmt->get_result();
        $stmt->close();
        return $employee;
    }

    //Method to fetch all employee from database
    public function getEmployeeByCompanyId($CompanyId) {
        $stmt = $this->con->prepare("SELECT t_employee.Id, t_employee.FullName, t_employee.EmailAddress, t_company.CompanyName, t_division.DivisionName, t_employee.EmployeeImage
		FROM t_employee
		INNER JOIN t_company ON (t_employee.CompanyId = t_company.CompanyId)
		INNER JOIN t_division ON (t_employee.DivisionId = t_division.DivisionId)
		WHERE t_employee.CompanyId=?");
        $stmt->bind_param("i", $CompanyId);
        $stmt->execute();
        $employee = $stmt->get_result();
        $stmt->close();
        return $employee;
    }

    //Method to let a Employee log in
    public function EmployeeLogin($EmailAddress, $Password) {
        $Pword = md5($Password);
        //$Pword = $Password;
        $stmt = $this->con->prepare("SELECT * FROM t_employee WHERE EmailAddress=? and Password=?");
        $stmt->bind_param("ss", $EmailAddress, $Pword);
        $stmt->execute();
        $stmt->store_result();
        $num_rows = $stmt->num_rows;
        $stmt->close();
        return $num_rows > 0;
    }

    //Method to get Employee details
    public function getEmployee($EmailAddress) {
        //        $stmt = $this->con->prepare("SELECT t_employee.Id, t_employee.FullName, t_employee.EmailAddress, t_company.CompanyName, t_employee.CompanyId, t_company.api_key, t_employee.IsCompanyAdmin
//		FROM t_employee
//			INNER JOIN t_company  ON (t_employee.CompanyId = t_company.CompanyId)
//			WHERE EmailAddress=?");
        $stmt = $this->con->prepare("SELECT t_employee.Id, t_employee.FullName, t_employee.EmailAddress, t_company.CompanyName, t_employee.CompanyId, t_company.api_key, t_employee.IsCompanyAdmin,`t_company`.`TimeZoneId`,`t_company`.`LangCode`
		FROM t_employee
			INNER JOIN t_company  ON (t_employee.CompanyId = t_company.CompanyId)
			WHERE EmailAddress=?");
        $stmt->bind_param("s", $EmailAddress);
        $stmt->execute();
        $EmailAddress = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        return $EmailAddress;
    }

    //Method to let a Visitor Log Out in
    public function VisitorLogout($VisitorId) {

        $stmt = $this->con->prepare("SELECT SignInTime FROM t_visitor WHERE VisitorId=?");
        $stmt->bind_param("s", $VisitorId);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_assoc();

        $SignInTime = $result['SignInTime'];
        $SignOutTime = $this->Currentdatetime();

        $stmt = $this->con->prepare("UPDATE t_visitor SET SignOutTime=?, EstDuration=TIMESTAMPDIFF(SECOND,'" . $SignInTime . "','" . $SignOutTime . "') WHERE VisitorId=?");
        $stmt->bind_param("si", $SignOutTime, $VisitorId);
        $result = $stmt->execute();

        //session_start();
        //session_destroy();
        //header("location: login.php");

        $stmt->close();
        if ($result) {
            return 0;
        } else {
            return 1;
        }
    }

    //Method to fetch Employee By Id from database
    public function getEmployeeById($EmployeeId) {
        $stmt = $this->con->prepare("SELECT Id, FullName FROM t_employee WHERE Id=?");
        $stmt->bind_param("i", $EmployeeId);
        $stmt->execute();
        $employee = $stmt->get_result();
        $stmt->close();
        return $employee;
    }

    //Method to update assignment status
    public function updateEmployeeImageAdd($EmployeeId, $ImagePath) {
        $stmt = $this->con->prepare("UPDATE t_employee SET EmployeeImage = ? WHERE Id=?");
        $stmt->bind_param("si", $ImagePath, $EmployeeId);
        $result = $stmt->execute();
        $stmt->close();
        if ($result) {
            return true;
        }
        return false;
    }

    //Method to Check Login Password
    public function CheckLoginRegistration($EmailAddress) {
        $stmt = $this->con->prepare("SELECT EmailAddress, Password FROM t_employee WHERE EmailAddress=?");
        $stmt->bind_param("s", $EmailAddress);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        if (!$result['Password'] == '') {
            return 0;
        } else if ($result['EmailAddress'] == '') {
            return 1;
        } else {
            return 2;
        }
    }

    //Method to create a new Visitor
    public function createVisitor($VisitorName, $VisitorCompany, $VisitorTypeId, $EmployeeId, $ImagePath, $ImageBaseUrl) {
        require_once('phpmailer/class.phpmailer.php');
        
        $mail = new PHPMailer();

        $SignInTime = $this->Currentdatetime();
        $date = $this->Currentdate();        
        $stmt = $this->con->prepare("INSERT INTO t_visitor(VisitorName, VisitorCompany, VisitorTypeId, EmployeeId, SignInTime, date, ImagePath) values(?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssiisss", $VisitorName, $VisitorCompany, $VisitorTypeId, $EmployeeId, $SignInTime, $date, $ImagePath);
        $result = $stmt->execute();
        $lastVisitorId = $this->con->insert_id;
        $stmt->close();
        $SendEmail = 1;

        $stmt2 = $this->con->prepare("SELECT t_employee.FullName, t_employee.EmailAddress, t_employee.MobileNo, t_site.SiteName FROM t_employee INNER JOIN t_site ON t_employee.SiteId = t_site.SiteId WHERE t_employee.Id=?");
        $stmt2->bind_param("i", $EmployeeId);
        $stmt2->execute();
        $result2 = $stmt2->get_result()->fetch_assoc();
        $stmt2->close();
        $EmailAddress = $result2['EmailAddress'];
        $FullName = $result2['FullName'];
        $SiteName = $result2['SiteName'];
        $MobileNo = "88" . $result2['MobileNo'];

        $stmt3 = $this->con->prepare("SELECT VisitorType FROM t_visitortype WHERE VisitorTypeId=?");
        $stmt3->bind_param("i", $VisitorTypeId);
        $stmt3->execute();
        $result3 = $stmt3->get_result()->fetch_assoc();
        $stmt3->close();
        $VisitorType = $result3['VisitorType'];

        if ($result) {            
            if ($SendEmail == 1) {
                //Mail Option
                $subject = 'Track My Visitor - You have a visitor';
                $email = 'admin@trackmyvisitor.com';
                $toemail = $EmailAddress; // Your Email Address
                $toname = ''; // Your Name
                $mail->SetFrom($email, '');
                $mail->AddAddress($toemail, '');
                $mail->Subject = $subject;

                $dataTable = "<b>Name: " . $VisitorName . "</b><br>"
                        . "<b>Comapny: " . $VisitorCompany . "</b><br>"
                        . "<b>Visitor Type: " . $VisitorType . "</b>";

                $message = $VisitorName . " from " . $VisitorCompany . " is waiting for you at reception. TrackMyVisitor";

                $body = '<table width=50%><tr><td colspan="2">A visitor is waiting for you at the reception - </td></tr><tr><td><img src="' . $ImageBaseUrl . 'visitors/' . $ImagePath . '" width="200" height="200" /></td><td>' . $dataTable . '</td></tr></table><br><br>';

                $body = "$body";

                $mail->MsgHTML($body);

				$USERNAME = "soft_works";
				$PASSWORD = "86<8Q23n";
				$STAKEHOLDER = "SoftWorks";

				/* $curl = curl_init();				
				curl_setopt_array($curl, array(CURLOPT_RETURNTRANSFER => 1, CURLOPT_URL =>
				"http://sms.sslwireless.com/pushapi/dynamic/server.php?user=$USERNAME&pass=$PASSWORD&sid=$STAKEHOLDER&sms=" . urlencode($message) . "&msisdn=$MobileNo&csmsid=123456789", CURLOPT_USERAGENT => 'Sample cURL Request'));				
				$resp = curl_exec($curl);
				curl_close($curl);
                
				$sendEmail = $mail->Send(); */
            }

            $retval['retval'] = 0;
            $retval['VisitorId'] = $lastVisitorId;
            return $retval;
        } else {           
            $retval['retval'] = 1;
            $retval['VisitorId'] = '';
            return $retval;
        }       
    }

    //Method to fetch all Visitor from database
    public function getAllVisitorList($CompanyId, $HostId, $VisitorTypeId, $SignOutNotSignOut, $StartDate, $EndDate) {
        if ($SignOutNotSignOut == 'SignOut') {
            $SignOut_NotSignOut = "AND t_visitor.SignOutTime > '0000-00-00 00:00:00'";
        } else {
            $SignOut_NotSignOut = "AND t_visitor.SignOutTime='0000-00-00 00:00:00'";
        }
        $stmt = $this->con->prepare("SELECT t_visitor.VisitorId,t_visitor.VisitorName, 
		t_visitor.VisitorCompany, t_employee.CompanyId,t_employee.FullName, t_visitor.SignInTime, 
		t_visitor.SignOutTime, t_employee.MobileNo, t_visitor.EmailAddress, t_visitor.EstDuration, 
		t_visitor.ImagePath,t_visitortype.VisitorType,t_visitor.EmployeeId
  FROM t_visitor 
    INNER JOIN t_employee ON (t_visitor.EmployeeId = t_employee.Id) 
    INNER JOIN t_visitortype ON (t_visitor.VisitorTypeId = t_visitortype.VisitorTypeId) 
    WHERE t_employee.CompanyId=? 
	AND (t_visitor.EmployeeId = ? OR ? = 0)
	AND (t_visitor.VisitorTypeId = ? OR ? = 0)
	AND (t_visitor.`date` BETWEEN ? AND ?)
	$SignOut_NotSignOut
	ORDER BY t_visitor.SignInTime DESC");
        $stmt->bind_param("iiiiiss", $CompanyId, $HostId, $HostId, $VisitorTypeId, $VisitorTypeId, $StartDate, $EndDate);
        $stmt->execute();
        $employee = $stmt->get_result();
        $stmt->close();
        return $employee;
    }
	
	//Method to fetch all Visitor test from database
    public function getAllVisitorTest($CompanyId) {
        $stmt = $this->con->prepare("SELECT t_visitor.VisitorId,t_visitor.VisitorName, 
		t_visitor.VisitorCompany, t_employee.CompanyId,t_employee.FullName, t_visitor.SignInTime, 
		t_visitor.SignOutTime, t_employee.MobileNo, t_visitor.EmailAddress, t_visitor.EstDuration, 
		t_visitor.ImagePath,t_visitortype.VisitorType,t_visitor.EmployeeId
  FROM t_visitor 
    INNER JOIN t_employee ON (t_visitor.EmployeeId = t_employee.Id) 
    INNER JOIN t_visitortype ON (t_visitor.VisitorTypeId = t_visitortype.VisitorTypeId) 
    WHERE t_employee.CompanyId=?
	ORDER BY t_visitor.SignInTime DESC");
        $stmt->bind_param("i", $CompanyId);
        $stmt->execute();
        $employee = $stmt->get_result();
        $stmt->close();
        return $employee;
    }

//Method to fetch all Visitor from database
    public function gethostinfoList($hostId) {
        $stmt = $this->con->prepare("SELECT Id,
		  a.FullName,
		  a.EmailAddress,
		  a.JobTitle,
		  a.MobileNo,
		  a.DeskPhoneNo,
		  b.DivisionName,
		  c.CompanyName
		FROM t_employee a
		  INNER JOIN t_division b ON (a.DivisionId = b.DivisionId)
		  INNER JOIN t_company c ON (a.CompanyId = c.CompanyId) WHERE Id=?");
        $stmt->bind_param("i", $hostId);
        $stmt->execute();
        $result = $stmt->get_result();
        $stmt->close();
        return $result;
    }

    //Method to fetch all Visitor from database
    public function getCompanyInformation($CompanyId) {
        $stmt = $this->con->prepare("SELECT t_company.CompanyImage, t_company.CompanyId, t_company.CompanyName
                        FROM t_company                           
                        WHERE t_company.CompanyId = ?");
        $stmt->bind_param("i", $CompanyId);
        $stmt->execute();
        $employee = $stmt->get_result();
        $stmt->close();
        return $employee;
    }

    //Method to fetch Signed In Visitor from database
    public function getSignedInVisitors($CompanyId, $SearchDate) {
        $stmt = $this->con->prepare("SELECT t_visitor.VisitorId, t_visitor.VisitorName, t_employee.CompanyId, t_visitor.SignInTime, t_employee.FullName,t_site.SiteName, t_visitor.VisitorCompany, `date`
		FROM t_visitor 
		  INNER JOIN t_employee ON (t_visitor.EmployeeId = t_employee.Id) 
		  INNER JOIN t_site ON (t_employee.SiteId = t_site.SiteId)
		  INNER JOIN t_company ON (t_employee.CompanyId = t_company.CompanyId)
		  WHERE t_employee.CompanyId=? AND t_visitor.date = ? ORDER BY t_visitor.SignInTime DESC");
        $stmt->bind_param("is", $CompanyId, $SearchDate);
        $stmt->execute();
        $employee = $stmt->get_result();
        $stmt->close();
        return $employee;
    }

    //Method to count Signed In Visitor from database
    public function countSignedInVisitors($CompanyId, $SearchDate) {
        //$date = $this->Currentdatefun("Y-m-d");
        $stmt = $this->con->prepare("SELECT count(t_visitor.VisitorId) as NumOfSignedInVisitors FROM t_visitor 
		  INNER JOIN t_employee ON (t_visitor.EmployeeId = t_employee.Id) 
		  INNER JOIN t_site ON (t_employee.SiteId = t_site.SiteId)
		  INNER JOIN t_company ON (t_employee.CompanyId = t_company.CompanyId)
		  WHERE t_employee.CompanyId=? AND t_visitor.date = ?");
        //var_dump($stmt);
        //exit;
        $stmt->bind_param("is", $CompanyId, $SearchDate);
        $stmt->execute();
        $employee = $stmt->get_result();
        $stmt->close();
        return $employee;
    }

    //Method to count Signed Out Visitor from database
    public function countSignedOutVisitors($CompanyId, $SearchDate) {
        //$date = $this->Currentdatefun("Y-m-d");
        $stmt = $this->con->prepare("SELECT t_visitor.SignOutTime  FROM t_visitor 
		  INNER JOIN t_employee ON (t_visitor.EmployeeId = t_employee.Id) 
		  INNER JOIN t_site ON (t_employee.SiteId = t_site.SiteId)
		  INNER JOIN t_company ON (t_employee.CompanyId = t_company.CompanyId)
		  WHERE t_employee.CompanyId=? AND t_visitor.date = ? ");
        //var_dump($stmt);
        //exit;
        $stmt->bind_param("is", $CompanyId, $SearchDate);
        $stmt->execute();
        $employee = $stmt->get_result();
        $stmt->close();
        return $employee;
    }

    //Method to fetch Daily Visitor from database
    public function getDailyVisitor($CompanyId, $SelectDays) {
        $endDate = $this->Currentdate();
        $end_date = date_create($endDate);

        if ($SelectDays == 30) {
            date_sub($end_date, date_interval_create_from_date_string("30 days"));
            $startDate = date_format($end_date, "Y-m-d");
        } else if ($SelectDays == 7) {
            date_sub($end_date, date_interval_create_from_date_string("7 days"));
            $startDate = date_format($end_date, "Y-m-d");
        } else {
            date_sub($end_date, date_interval_create_from_date_string("90 days"));
            $startDate = date_format($end_date, "Y-m-d");
        }

        $stmt = $this->con->prepare("SELECT COUNT(t_visitor.VisitorId) totalVisitor, t_visitor.`date`
		FROM t_visitor 
		  INNER JOIN t_employee ON (t_visitor.EmployeeId = t_employee.Id) 
		  WHERE t_employee.CompanyId=? AND (t_visitor.`date` BETWEEN ? AND ?)
		  GROUP BY t_employee.CompanyId, t_visitor.`date`");
        // var_dump($stmt);
        //exit();
        $stmt->bind_param("iss", $CompanyId, $startDate, $endDate);
        $stmt->execute();
        $employee = $stmt->get_result();
        $stmt->close();
        return $employee;
    }

    //Method to fetch Busiest Hosts from database
    public function getBusiestHosts($CompanyId, $SelectDays) {
        $endDate = $this->Currentdate();
        $end_date = date_create($endDate);
//        date_sub($end_date, date_interval_create_from_date_string("90 days"));
//        $startDate = date_format($end_date, "Y-m-d");

        if ($SelectDays == 30) {
            date_sub($end_date, date_interval_create_from_date_string("30 days"));
            $startDate = date_format($end_date, "Y-m-d");
        } else if ($SelectDays == 7) {
            date_sub($end_date, date_interval_create_from_date_string("7 days"));
            $startDate = date_format($end_date, "Y-m-d");
        } else {
            date_sub($end_date, date_interval_create_from_date_string("90 days"));
            $startDate = date_format($end_date, "Y-m-d");
        }

        $stmt = $this->con->prepare("SELECT COUNT(t_visitor.VisitorId) totalVisitor, t_visitor.`date`, t_visitor.EmployeeId, t_employee.FullName
		FROM t_visitor 
		  INNER JOIN t_employee ON (t_visitor.EmployeeId = t_employee.Id) 
		  WHERE t_employee.CompanyId=? AND (t_visitor.`date` BETWEEN ? AND ?)
		  GROUP BY t_visitor.EmployeeId ORDER BY totalVisitor DESC LIMIT 5");
        $stmt->bind_param("iss", $CompanyId, $startDate, $endDate);

        $stmt->execute();
        $employee = $stmt->get_result();
        $stmt->close();
        return $employee;
    }

    //Method to create a Host Update salam
    public function HostUpdate($Activation, $FirstName, $LastName, $EmailAddress, $JobTitle, $MobileNo, $DeskPhoneNo, $SiteId, $CompanyId, $DivisionId, $SendEmail, $IsHost, $RecordId) {
        $FullName = $FirstName . ' ' . $LastName;
        $Id = $RecordId;
        $stmt = $this->con->prepare("UPDATE t_employee SET Activation = ?,FirstName =?,LastName=?,FullName=?,EmailAddress=?,JobTitle =?,MobileNo=?,DeskPhoneNo =?,SiteId =?,CompanyId=?,DivisionId =?,SendEmail=?,IsHost=? WHERE Id=?");
        $stmt->bind_param("isssssssiiiiii", $Activation, $FirstName, $LastName, $FullName, $EmailAddress, $JobTitle, $MobileNo, $DeskPhoneNo, $SiteId, $CompanyId, $DivisionId, $SendEmail, $IsHost, $Id);
        $result = $stmt->execute();

        $stmt->close();
        if ($result) {
            $retval['retval'] = 0;
        } else {
            $retval['retval'] = 1;
        }
    }

    //Method to create a Site salam	
    public function getAllSiteByCompanyId($CompanyId) {
        $stmt = $this->con->prepare("SELECT t_site.siteId, t_site.siteName	
		FROM t_site
		INNER JOIN t_company ON (t_site.CompanyId = t_company.CompanyId)
		WHERE t_site.CompanyId=?");
        $stmt->bind_param("i", $CompanyId);
        $stmt->execute();
        $siteList = $stmt->get_result();
        $stmt->close();
        return $siteList;
    }

    //get Host Combo Load By CompanyId
    public function getHostComboLoadByCompanyId($CompanyId) {
        $stmt = $this->con->prepare("SELECT Id, FullName, CompanyId FROM t_employee
		WHERE CompanyId=? ORDER BY FullName");
        $stmt->bind_param("i", $CompanyId);
        $stmt->execute();
        $siteList = $stmt->get_result();
        $stmt->close();
        return $siteList;
    }

    //get Visitor Type Combo Load By CompanyId
    public function getVisitorTypeByCompanyIdByCompanyId($CompanyId) {
        $stmt = $this->con->prepare("SELECT VisitorTypeId,VisitorType FROM t_visitortype 
		WHERE CompanyId=? ORDER BY VisitorType");
        $stmt->bind_param("i", $CompanyId);
        $stmt->execute();
        $siteList = $stmt->get_result();
        $stmt->close();
        return $siteList;
    }

    //Method to create a Language salam
    public function getAllTimeZone() {

        $BActive = 1;
        $stmt = $this->con->prepare("SELECT `t_timezone`.`TimeZoneId`, `t_timezone`.`TimeZoneName`	
		FROM `t_timezone` where BActive =? ORDER BY `t_timezone`.`TimeZoneId`");
        $stmt->bind_param("i", $BActive);
        $stmt->execute();
        $TimeZoneList = $stmt->get_result();
        $stmt->close();
        return $TimeZoneList;
    }

    //Method to create a Language salam
    public function getAllLanguage() {


        $BActive = 1;
        $stmt = $this->con->prepare("SELECT t_language.LangCode, t_language.LangTitle	
		FROM t_language where BActive =? order by t_language.LangTitle");
        $stmt->bind_param("i", $BActive);
        $stmt->execute();
        $LanguageList = $stmt->get_result();
        $stmt->close();
        return $LanguageList;
    }

    //Method to create a Division salam
    public function getAllDivisionByCompanyId($CompanyId, $siId) {

        $stmt = $this->con->prepare("SELECT t_division.DivisionId, t_division.DivisionName	
		FROM t_division
		INNER JOIN t_site ON (t_division.SiteId = t_site.SiteId)
		WHERE t_site.CompanyId=? AND t_site.SiteId =?");
        $stmt->bind_param("ii", $CompanyId, $siId);
        $stmt->execute();
        $divisionList = $stmt->get_result();
        $stmt->close();
        return $divisionList;
    }

    //Method to create a Host salam
    public function getAllHostListEdit($EmployeeId) {
        $stmt = $this->con->prepare("SELECT t_employee.Id, t_employee.FirstName,t_employee.LastName, t_employee.EmailAddress, t_employee.EmployeeImage, t_employee.CompanyId, t_employee.JobTitle,t_employee.DeskPhoneNo,t_employee.MobileNo,t_employee.IsHost,t_employee.SendEmail,t_employee.SiteId,t_employee.DivisionId,t_employee.EmployeeImage 	
		FROM t_employee
		WHERE t_employee.Id=?");
        $stmt->bind_param("i", $EmployeeId);
        $stmt->execute();
        $employeeEdit = $stmt->get_result();
        $stmt->close();
        return $employeeEdit;
    }

    //Method to check the Company Name already exist or not
    private function isCompanyNameExists($CompanyName) {
        $stmt = $this->con->prepare("SELECT CompanyId from t_company WHERE CompanyName = ?");
        $stmt->bind_param("s", $CompanyName);
        $stmt->execute();
        $stmt->store_result();
        $num_rows = $stmt->num_rows;
        $stmt->close();
        return $num_rows > 0;
    }

    //Method to check the Email Address already exist or not
    private function isEmployeeEmailExists($EmailAddress) {
        $stmt = $this->con->prepare("SELECT Id from t_employee WHERE EmailAddress = ?");
        $stmt->bind_param("s", $EmailAddress);
        $stmt->execute();
        $stmt->store_result();
        $num_rows = $stmt->num_rows;
        $stmt->close();
        return $num_rows > 0;
    }

    //Method to check the Email Address already exist or not
    private function isCompanyIdEmailAddressExists($EmailAddress, $CompanyId) {
        $stmt = $this->con->prepare("SELECT Id from t_employee WHERE EmailAddress = ? AND CompanyId=?");
        $stmt->bind_param("si", $EmailAddress, $CompanyId);
        $stmt->execute();
        $stmt->store_result();
        $num_rows = $stmt->num_rows;
        $stmt->close();
        return $num_rows > 0;
    }

    //Method to fetch all authorize visitor from database getSpecialVisitorById
    public function getAuthorizeVisitorByCompanyId($CompanyId) {
        $stmt = $this->con->prepare("SELECT t_authorise_visitor.SpecialVisitorId, t_authorise_visitor.SpecialVisitorName, t_authorise_visitor.SpecialVisitorCompany, t_authorise_visitor.EmailAddress, t_authorise_visitor.Phone, t_authorise_visitor.AppointmentDate, t_authorise_visitor.QRAttachment, 
                t_authorise_visitor.VisitorImage, t_employee.FullName, t_employee.FullName,t_employee.Id, CONCAT(t_event.EventName,'-',t_event.`EventDate`) AS EventName, t_visitortype.VisitorType
		FROM t_authorise_visitor
		INNER JOIN t_event ON (t_authorise_visitor.EventId = t_event.EventId)
		INNER JOIN t_company ON (t_event.CompanyId = t_company.CompanyId)
		INNER JOIN t_employee ON (t_authorise_visitor.EmployeeId = t_employee.Id)
		INNER JOIN t_visitortype ON (t_authorise_visitor.VisitorTypeId = t_visitortype.VisitorTypeId)
		WHERE t_event.CompanyId=? ORDER BY `t_authorise_visitor`.`AppointmentDate` DESC");
        $stmt->bind_param("i", $CompanyId);
        $stmt->execute();
        $employee = $stmt->get_result();
        $stmt->close();
        return $employee;
    }

    public function authorizeVisitorDelete($SVisitorId) {
        $stmt = $this->con->prepare("delete FROM t_authorise_visitor WHERE t_authorise_visitor.SpecialVisitorId=?");
        $stmt->bind_param("i", $SVisitorId);
        $stmt->execute();
        $SVisitorDelete = $stmt->get_result();
        $stmt->close();
        return $SVisitorDelete;
    }

    //Method to fetch all authorize special visitor from database getSpecialVisitorById

    public function getSpecialVisitorById($VisitorId) {
        $stmt = $this->con->prepare("SELECT t_authorise_visitor.SpecialVisitorId, t_authorise_visitor.SpecialVisitorName, t_authorise_visitor.SpecialVisitorCompany, t_authorise_visitor.EmailAddress, t_authorise_visitor.Phone, t_authorise_visitor.AppointmentDate, t_authorise_visitor.QRAttachment, 
                t_authorise_visitor.VisitorImage, t_employee.FullName,t_event.EventName, t_visitortype.VisitorType
		FROM t_authorise_visitor
		INNER JOIN t_event ON (t_authorise_visitor.EventId = t_event.EventId)
		INNER JOIN t_company ON (t_event.CompanyId = t_company.CompanyId)
		INNER JOIN t_employee ON (t_authorise_visitor.EmployeeId = t_employee.Id)
		INNER JOIN t_visitortype ON (t_authorise_visitor.VisitorTypeId = t_visitortype.VisitorTypeId)
		WHERE t_authorise_visitor.SpecialVisitorId=?");
        $stmt->bind_param("i", $VisitorId);
        $stmt->execute();
        $employee = $stmt->get_result();
        $stmt->close();
        return $employee;
    }

    //Method to fetch all event from database
    public function getDropDownEventListByCompanyId($CompanyId) {
        $stmt = $this->con->prepare("SELECT t_event.EventId, CONCAT(t_event.EventName,' ', '-' ,' ',t_event.`EventDate`) AS EventName
		FROM t_event
		WHERE t_event.CompanyId=? ORDER BY  t_event.EventId DESC");
        $stmt->bind_param("i", $CompanyId);
        $stmt->execute();
        $employee = $stmt->get_result();
        $stmt->close();
        return $employee;
    }

    //Method to fetch all employee from database
    public function getDropDownEmployeeListByCompanyId($CompanyId) {
        $stmt = $this->con->prepare("SELECT t_employee.Id, t_employee.FullName
		FROM t_employee
		WHERE t_employee.CompanyId=? ");
        $stmt->bind_param("i", $CompanyId);
        $stmt->execute();
        $employee = $stmt->get_result();
        $stmt->close();
        return $employee;
    }

    //Method to fetch all visitor type from database
    public function getDropDownVisitorTypeListByCompanyId($CompanyId) {
        $stmt = $this->con->prepare("SELECT t_visitortype.VisitorTypeId, t_visitortype.VisitorType
		FROM t_visitortype
		WHERE t_visitortype.CompanyId=? ");
        $stmt->bind_param("i", $CompanyId);
        $stmt->execute();
        $employee = $stmt->get_result();
        $stmt->close();
        return $employee;
    }

    //Method to create a new authorize visitor 
    public function AuthorizeVisitorCreate($RecordId, $SpecialVisitorName, $SpecialVisitorCompany, $EmailAddress, $Phone, $EmployeeId, $AppointmentDate, $EventId, $EventName, $EmployeeName, $ImageBaseUrl, $VisitorTypeId, $VisitorTypeName) {

        require_once('phpmailer/class.phpmailer.php');
        $mail = new PHPMailer();

        $stmt2 = $this->con->prepare("SELECT t_company.CompanyName FROM t_employee INNER JOIN t_company ON t_employee.CompanyId= t_company.CompanyId WHERE t_employee.Id=?");
        $stmt2->bind_param("s", $EmployeeId);
        $stmt2->execute();
        $result2 = $stmt2->get_result()->fetch_assoc();
        $HostCompany = $result2['CompanyName'];

        if ($RecordId == 0) {
            if (!$this->isAuthoriseVisitorEmailExists($EmailAddress)) {

                $stmt = $this->con->prepare("INSERT INTO t_authorise_visitor(SpecialVisitorName, SpecialVisitorCompany, EmailAddress, Phone, EmployeeId, AppointmentDate, EventId, VisitorTypeId) values(?, ?, ?, ?, ?, ?, ?, ?)");
                $stmt->bind_param("ssssisii", $SpecialVisitorName, $SpecialVisitorCompany, $EmailAddress, $Phone, $EmployeeId, $AppointmentDate, $EventId, $VisitorTypeId);
                $result = $stmt->execute();
                $lastAuthId = $this->con->insert_id;


                $data = "Visitor ID: " . $lastAuthId . "\n" .
                        "Visitor Name: " . $SpecialVisitorName . "\n" .
                        "Visitor Company: " . $SpecialVisitorCompany . "\n" .
                        "Visitor Type ID: " . $VisitorTypeId . "\n" .
                        "Visitor Type: " . $VisitorTypeName . "\n" .
                        "Email: " . $EmailAddress . "\n" .
                        "Phone: " . $Phone . "\n" .
                        "Event ID: " . $EventId . "\n" .
                        "Event Name: " . $EventName . "\n" .
                        "Host ID: " . $EmployeeId . "\n" .
                        "Host Name: " . $EmployeeName . "\n" .
                        "Host Company: " . $HostCompany . "\n" .
                        "Appointment Date: " . $AppointmentDate;

                $dataTable = "Visitor ID: " . $lastAuthId . "<br>" .
                        "Visitor Name: " . $SpecialVisitorName . "<br>" .
                        "Visitor Company: " . $SpecialVisitorCompany . "<br>" .
                        "Visitor Type: " . $VisitorTypeName . "<br>" .
                        "Email: " . $EmailAddress . "<br>" .
                        "Phone: " . $Phone . "<br>" .
                        "Event Name: " . $EventName . "<br>" .
                        "Host Name: " . $EmployeeName . "<br>" .
                        "Host Company: " . $HostCompany . "<br>" .
                        "Appointment Date: " . date("F j, Y", strtotime($AppointmentDate));

                $PNG_TEMP_DIR = '../../images/barcodeimage/';
//        $PNG_TEMP_DIR = dirname(__FILE__) . DIRECTORY_SEPARATOR . 'barcodeimage' . DIRECTORY_SEPARATOR;
                $PNG_WEB_DIR = '../../images/barcodeimage/';
                include ("../../qr_code_generate/qrlib.php");

                //ofcourse we need rights to create temp dir
                if (!file_exists($PNG_TEMP_DIR))
                    mkdir($PNG_TEMP_DIR);

                //processing form input
                //remember to sanitize user input in real-life solution !!!
                $errorCorrectionLevel = 'L';

                $matrixPointSize = 10;
                if (trim($data) == '')
                    die('data cannot be empty! <a href="?">back</a>');
                $currentTime = time();

                $filename = $PNG_TEMP_DIR . $lastAuthId . "_" . $EmployeeId . "_" . $currentTime . '.png';
                QRcode::png($data, $filename, $errorCorrectionLevel, $matrixPointSize, 2);
                $QRAttachment = $lastAuthId . "_" . $EmployeeId . "_" . $currentTime . '.png';

                $this->updateQrAttachment($lastAuthId, $QRAttachment);

                $SendEmail = 1;
                $stmt->close();
                if ($result) {
                    if ($SendEmail == 1) {
                        //Mail Option
                        $name = 'Track My Visitor Admin';
                        $email = 'admin@trackmyvisitor.com';
                        $subject = 'Preauthorization for ' . $SpecialVisitorName . ' on ' . date("F j, Y", strtotime($AppointmentDate));
                        $toemail = $EmailAddress; // Your Email Address
                        $toname = ''; // Your Name
                        $mail->SetFrom($email, '');
                        $mail->AddAddress($toemail, '');
                        $mail->Subject = $subject;

                        $Step1 = "Dear " . $SpecialVisitorName . ',<br><br>';

                        $Step2 = 'Your preauthorization information is provided below:<br><br>';

                        $body = '<table width=100%><tr><td>' . $dataTable . '</td><td><img src="' . $ImageBaseUrl . 'barcodeimage/' . $QRAttachment . '" width="200" height="200" /></td></tr></table><br><br>';

                        $Step3 = "You would need to scan the above barcode during sign-in at the reception<br><br>";

                        $referrer = '';

                        $body = "$Step1 $Step2 $body $Step3 $referrer";

                        $mail->AddAttachment($ImageBaseUrl . 'barcodeimage/' . $QRAttachment, $QRAttachment);
                        $mail->MsgHTML($body);

                        $sendEmail = $mail->Send();
                    }

                    //return 0;
                    $retval['retval'] = 0;
                    $retval['SpecialVisitorId'] = $lastAuthId;
                    $retval['QRAttachment'] = $QRAttachment;
                    return $retval;
                } else {
                    //return 1;
                    $retval['retval'] = 1;
                    return $retval;
                }
            } else {
                //return 2;
                $retval['retval'] = 2;
                return $retval;
            }
        } else {
            $stmt2 = $this->con->prepare("SELECT t_authorise_visitor.QRAttachment FROM t_authorise_visitor WHERE t_authorise_visitor.SpecialVisitorId=?");
            $stmt2->bind_param("s", $RecordId);
            $stmt2->execute();
            $result2 = $stmt2->get_result()->fetch_assoc();
            $QRAttachment = $result2['QRAttachment'];
            $filepath = '../../images/barcodeimage/' . $QRAttachment;
            if (is_file($filepath)) {
                unlink($filepath);
            }

            $data = "Visitor ID: " . $RecordId . "\n" .
                    "Visitor Name: " . $SpecialVisitorName . "\n" .
                    "Visitor Company: " . $SpecialVisitorCompany . "\n" .
                    "Visitor Type ID: " . $VisitorTypeId . "\n" .
                    "Visitor Type: " . $VisitorTypeName . "\n" .
                    "Email: " . $EmailAddress . "\n" .
                    "Phone: " . $Phone . "\n" .
                    "Event ID: " . $EventId . "\n" .
                    "Event Name: " . $EventName . "\n" .
                    "Host ID: " . $EmployeeId . "\n" .
                    "Host Name: " . $EmployeeName . "\n" .
                    "Host Company: " . $HostCompany . "\n" .
                    "Appointment Date: " . $AppointmentDate;

            $dataTable = "Visitor ID: " . $RecordId . "<br>" .
                    "Visitor Name: " . $SpecialVisitorName . "<br>" .
                    "Visitor Company: " . $SpecialVisitorCompany . "<br>" .
                    "Visitor Type: " . $VisitorTypeName . "<br>" .
                    "Email: " . $EmailAddress . "<br>" .
                    "Phone: " . $Phone . "<br>" .
                    "Event Name: " . $EventName . "<br>" .
                    "Host Name: " . $EmployeeName . "<br>" .
                    "Host Company: " . $HostCompany . "<br>" .
                    "Appointment Date: " . date("F j, Y", strtotime($AppointmentDate));

            $PNG_TEMP_DIR = '../../images/barcodeimage/';
//        $PNG_TEMP_DIR = dirname(__FILE__) . DIRECTORY_SEPARATOR . 'barcodeimage' . DIRECTORY_SEPARATOR;
            $PNG_WEB_DIR = '../../images/barcodeimage/';
            include ("../../qr_code_generate/qrlib.php");

            //ofcourse we need rights to create temp dir
            if (!file_exists($PNG_TEMP_DIR))
                mkdir($PNG_TEMP_DIR);

            //processing form input
            //remember to sanitize user input in real-life solution !!!
            $errorCorrectionLevel = 'L';

            $matrixPointSize = 10;
            if (trim($data) == '')
                die('data cannot be empty! <a href="?">back</a>');
            $currentTime = time();

            $filename = $PNG_TEMP_DIR . $RecordId . "_" . $EmployeeId . "_" . $currentTime . '.png';
            QRcode::png($data, $filename, $errorCorrectionLevel, $matrixPointSize, 2);
            $QRAttachment = $RecordId . "_" . $EmployeeId . "_" . $currentTime . '.png';

            $stmt = $this->con->prepare("UPDATE t_authorise_visitor SET SpecialVisitorName = ?, SpecialVisitorCompany = ?, EmailAddress = ?, Phone = ?, EmployeeId = ?, AppointmentDate = ?, QRAttachment = ?, EventId = ?, VisitorTypeId = ? WHERE SpecialVisitorId = ?");
            $stmt->bind_param("ssssissiii", $SpecialVisitorName, $SpecialVisitorCompany, $EmailAddress, $Phone, $EmployeeId, $AppointmentDate, $QRAttachment, $EventId, $VisitorTypeId, $RecordId);
            $result = $stmt->execute();
            $SendEmail = 1;
            $stmt->close();
            if ($result) {
                if ($SendEmail == 1) {
                    //Mail Option
                    $name = 'Track My Visitor Admin';
                    $email = 'admin@trackmyvisitor.com';
                    $subject = 'Preauthorization for ' . $SpecialVisitorName . ' on ' . date("F j, Y", strtotime($AppointmentDate));
                    $toemail = $EmailAddress; // Your Email Address
                    $toname = ''; // Your Name
                    $mail->SetFrom($email, '');
                    $mail->AddAddress($toemail, '');
                    $mail->Subject = $subject;

                    $Step1 = "Dear " . $SpecialVisitorName . ',<br><br>';

                    $Step2 = 'Your preauthorization information is provided below:<br><br>';

                    $body = '<table width=100%><tr><td>' . $dataTable . '</td><td><img src="' . $ImageBaseUrl . 'barcodeimage/' . $QRAttachment . '" width="200" height="200" /></td></tr></table><br><br>';

                    $Step3 = "You would need to scan the above barcode during sign-in at the reception<br><br>";

                    $referrer = '';

                    $body = "$Step1 $Step2 $body $Step3 $referrer";

                    $mail->AddAttachment($ImageBaseUrl . 'barcodeimage/' . $QRAttachment, $QRAttachment);
                    $mail->MsgHTML($body);

                    $sendEmail = $mail->Send();
                }

                //return 0;
                $retval['retval'] = 0;
                $retval['SpecialVisitorId'] = $RecordId;
                $retval['QRAttachment'] = $QRAttachment;
                return $retval;
            } else {
                //return 1;
                $retval['retval'] = 1;
                return $retval;
            }
        }
    }

    public function getAuthorizeVisitorById($EmployeeId) {
        $stmt = $this->con->prepare("SELECT t_authorise_visitor.SpecialVisitorId, t_authorise_visitor.SpecialVisitorName,t_authorise_visitor.SpecialVisitorCompany, t_authorise_visitor.EmailAddress, t_authorise_visitor.Phone, t_authorise_visitor.EmployeeId, t_authorise_visitor.AppointmentDate, t_authorise_visitor.EventId, t_authorise_visitor.VisitorImage, t_authorise_visitor.QRAttachment, t_authorise_visitor.VisitorTypeId 	
		FROM t_authorise_visitor
		WHERE t_authorise_visitor.SpecialVisitorId=?");
        $stmt->bind_param("i", $EmployeeId);
        $stmt->execute();
        $employeeEdit = $stmt->get_result();
        $stmt->close();
        return $employeeEdit;
    }

    //Method to update assignment status
    public function updateAuthorizeVisitorImageAdd($EmployeeId, $VisitorImage) {
        $stmt = $this->con->prepare("UPDATE t_authorise_visitor SET VisitorImage = ? WHERE SpecialVisitorId=?");
        $stmt->bind_param("si", $VisitorImage, $EmployeeId);
        $result = $stmt->execute();
        $stmt->close();
        if ($result) {
            return true;
        }
        return false;
    }

    //Method to check the Email Address already exist or not
    private function isAuthoriseVisitorEmailExists($EmailAddress) {
        $stmt = $this->con->prepare("SELECT SpecialVisitorId from t_authorise_visitor WHERE EmailAddress = ?");
        $stmt->bind_param("s", $EmailAddress);
        $stmt->execute();
        $stmt->store_result();
        $num_rows = $stmt->num_rows;
        $stmt->close();
        return $num_rows > 0;
    }

    //Method to update QRAttachment status
    public function updateQrAttachment($SpecialVisitorId, $QRAttachment) {
        $stmt = $this->con->prepare("UPDATE t_authorise_visitor SET t_authorise_visitor.QRAttachment = ? WHERE t_authorise_visitor.SpecialVisitorId=?");
        $stmt->bind_param("si", $QRAttachment, $SpecialVisitorId);
        $result = $stmt->execute();
        $stmt->close();

        if ($result) {
            return true;
        }
        return false;
    }

    public function VisitorTypeCreate($VisitorType, $CompanyId) {

        $countVisitorType = $this->isVisitorTypeExist($VisitorType, $CompanyId);
        if ($countVisitorType == 0) {
            //echo '========================'.$CompanyId;
            $stmt = $this->con->prepare("INSERT INTO t_visitortype(VisitorType, CompanyId) values(?, ?)");
            $stmt->bind_param("si", $VisitorType, $CompanyId);
            $result = $stmt->execute();
            //$lastEmployeeId = $this->con->insert_id;
            $stmt->close();
            if ($result) {
                $retval['retval'] = 0;
                //$retval['EmployeeId'] = $lastEmployeeId;
                return $retval;
            } else {
                $retval['retval'] = 1;
                //$retval['EmployeeId'] = $lastEmployeeId;
                return $retval;
            }
        } else {
            $retval['retval'] = 2;
            return $retval;
        }
    }

    public function getVisitorsTypeList($CompanyId) {
        $stmt = $this->con->prepare("SELECT t_visitortype.VisitorTypeId, t_visitortype.VisitorType,t_company.CompanyName 
		FROM t_visitortype
		INNER JOIN t_company ON (t_visitortype.CompanyId = t_company.CompanyId)
		WHERE t_visitortype.CompanyId=?");
        $stmt->bind_param("i", $CompanyId);
        $stmt->execute();
        $VisitorType = $stmt->get_result();
        $stmt->close();
        return $VisitorType;
    }

    public function getAllVisitorTypeListEdit($VisitorTypeId) {
        $stmt = $this->con->prepare("SELECT t_visitortype.VisitorTypeId, t_visitortype.VisitorType,t_visitortype.CompanyId	
		FROM t_visitortype
		WHERE t_visitortype.VisitorTypeId=?");
        $stmt->bind_param("i", $VisitorTypeId);
        $stmt->execute();
        $VisitorTypeEdit = $stmt->get_result();
        $stmt->close();
        return $VisitorTypeEdit;
    }

    public function VisitorTypeUpdate($VisitorType, $CompanyId, $RecordId) {

        $VisitorTypeId = $RecordId;
        $countVisitorType = $this->isVisitorTypeExist($VisitorType, $CompanyId);
        if ($countVisitorType == 0) {
            $stmt = $this->con->prepare("UPDATE t_visitortype SET VisitorType = ? WHERE VisitorTypeId=?");
            $stmt->bind_param("si", $VisitorType, $VisitorTypeId);
            $result = $stmt->execute();
            $stmt->close();
            if ($result) {
                $retval['retval'] = 0;
            } else {
                $retval['retval'] = 1;
            }
        } else {
            $retval['retval'] = 2;
            return $retval;
        }
    }

    public function isVisitorTypeExist($VisitorType, $CompanyId) {
        $stmt = $this->con->prepare("SELECT VisitorTypeId from t_visitortype WHERE VisitorType = ? AND CompanyId=?");
        $stmt->bind_param("si", $VisitorType, $CompanyId);
        $stmt->execute();
        $stmt->store_result();
        $num_rows = $stmt->num_rows;
        $stmt->close();
        if ($num_rows > 0) {
            return 1;
        } else {
            return 0;
        }
    }

    /* public function VisitorTypeCreate($VisitorType, $CompanyId) {

      $countVisitorType = $this->isVisitorTypeExist($VisitorType, $CompanyId);
      if ($countVisitorType == 0) {
      $stmt = $this->con->prepare("INSERT INTO t_visitortype(VisitorType, CompanyId) values(?, ?)");
      $stmt->bind_param("si", $VisitorType, $CompanyId);
      $result = $stmt->execute();
      $stmt->close();
      if ($result) {
      $retval['retval'] = 0;
      return $retval;
      } else {
      $retval['retval'] = 1;
      return $retval;
      }
      } else {
      $retval['retval'] = 2;
      return $retval;
      }
      } */

    public function EventCreate($EventName, $EventDate, $CompanyId) {

        $countEventType = $this->isEventExist($EventName, $EventDate, $CompanyId);
        if ($countEventType == 0) {
            $stmt = $this->con->prepare("INSERT INTO t_event(EventName,EventDate,CompanyId) values(?, ?,?)");
            $stmt->bind_param("ssi", $EventName, $EventDate, $CompanyId);
            $result = $stmt->execute();
            $stmt->close();
            if ($result) {
                $retval['retval'] = 0;
                return $retval;
            } else {
                $retval['retval'] = 1;
                return $retval;
            }
        } else {
            $retval['retval'] = 2;
            return $retval;
        }
    }

    public function getEventList($CompanyId) {
        $stmt = $this->con->prepare("SELECT t_event.EventId, t_event.EventName,t_event.EventDate,t_company.CompanyName 
		FROM t_event
		INNER JOIN t_company ON (t_event.CompanyId = t_company.CompanyId)
		WHERE t_event.CompanyId=?");
        $stmt->bind_param("i", $CompanyId);
        $stmt->execute();
        $event = $stmt->get_result();
        $stmt->close();
        return $event;
    }

    public function getAllEventListEdit($EventId) {
        $stmt = $this->con->prepare("SELECT t_event.EventId, t_event.EventName,t_event.EventDate,t_event.CompanyId	
		FROM t_event
		WHERE t_event.EventId=?");
        $stmt->bind_param("i", $EventId);
        $stmt->execute();
        $EventEdit = $stmt->get_result();
        $stmt->close();
        return $EventEdit;
    }

    public function EventUpdate($EventName, $EventDate, $CompanyId, $RecordId) {

        $EventId = $RecordId;
        $CountEvent = $this->isEventExist($EventName, $EventDate, $CompanyId);
        if ($CountEvent == 0) {
            $stmt = $this->con->prepare("UPDATE t_event SET EventName = ?,EventDate = ? WHERE EventId=?");
            $stmt->bind_param("ssi", $EventName, $EventDate, $EventId);
            $result = $stmt->execute();
            $stmt->close();
            if ($result) {
                $retval['retval'] = 0;
            } else {
                $retval['retval'] = 1;
            }
        } else {
            $retval['retval'] = 2;
            return $retval;
        }
    }

    public function eventDelete($EventId) {
        $stmt = $this->con->prepare("delete FROM t_event WHERE t_event.EventId=?");
        $stmt->bind_param("i", $EventId);
        $stmt->execute();
        $EventDelete = $stmt->get_result();
        $stmt->close();
        return $EventDelete;
    }

    public function visitorTypeDelete($VisitorTypeId) {
        $stmt = $this->con->prepare("delete FROM t_visitortype WHERE t_visitortype.VisitorTypeId=?");
        $stmt->bind_param("i", $VisitorTypeId);
        $stmt->execute();
        $VisitorTypeDelete = $stmt->get_result();
        $stmt->close();
        return $VisitorTypeDelete;
    }

    //Method to create a new Sitet Entry --salam---
    public function SiteCreate($SiteName, $LangTitle, $LangCode, $TimeZone, $StreetAddress, $EmergencyContact, $SystemAssistantContct, $CompanyId) {

        if (!$this->isSiteExists($SiteName)) {
            $stmt = $this->con->prepare("INSERT INTO t_site(SiteName,StreetAddress, EmergencyContact, SystemAssistantContct,CompanyId) values(?, ?, ?, ?, ?, ?,?,?)");
            $stmt->bind_param("ssssi", $SiteName, $StreetAddress, $EmergencyContact, $SystemAssistantContct, $CompanyId);
            $result = $stmt->execute();
            $stmt->close();
            if ($result) {
                $retval['retval'] = 0;
                return $retval;
            } else {
                $retval['retval'] = 1;
                return $retval;
            }
        } else {
            $retval['retval'] = 2;
            return $retval;
        }
    }

    //Site name existence check ---salam--
    private function isSiteExists($SiteName) {
        $stmt = $this->con->prepare("SELECT SiteId from t_site WHERE SiteName = ?");
        $stmt->bind_param("s", $SiteName);
        $stmt->execute();
        $stmt->store_result();
        $num_rows = $stmt->num_rows;
        $stmt->close();
        return $num_rows > 0;
    }

    //Get site list db---salam--
    public function getSiteList($CompanyId) {
        $stmt = $this->con->prepare("SELECT t_site.SiteId,t_site.SiteName,t_site.StreetAddress,t_site.EmergencyContact,t_site.SystemAssistantContct,t_company.CompanyName 
		FROM t_site
		INNER JOIN t_company ON (t_site.CompanyId = t_company.CompanyId)
		WHERE t_site.CompanyId=?");
        $stmt->bind_param("i", $CompanyId);
        $stmt->execute();
        $site = $stmt->get_result();
        $stmt->close();
        return $site;
    }

    //site update-------------salam--------
    public function SiteUpdate($SiteName, $StreetAddress, $EmergencyContact, $SystemAssistantContct, $CompanyId, $RecordId) {

        $SiteId = $RecordId;
        $stmt = $this->con->prepare("UPDATE t_site SET SiteName = ?,LangTitle = ?,LangCode = ?,TimeZone = ?,StreetAddress = ?,EmergencyContact = ?,SystemAssistantContct = ? WHERE SiteId= ?");
        $stmt->bind_param("ssssi", $SiteName, $StreetAddress, $EmergencyContact, $SystemAssistantContct, $SiteId);
        $result = $stmt->execute();
        $stmt->close();
        if ($result) {
            $retval['retval'] = 0;
        } else {
            $retval['retval'] = 1;
        }
    }

    //Site delete db-----------salam-------------
    public function siteDelete($SiteId) {
        $stmt = $this->con->prepare("delete FROM t_site WHERE t_site.SiteId=?");
        $stmt->bind_param("i", $SiteId);
        $stmt->execute();
        $SiteDelete = $stmt->get_result();
        $stmt->close();
        return $SiteDelete;
    }

    public function InsertLanguageText($LangCode, $CompanyId) {

        $stmt = $this->con->prepare("SELECT * FROM `t_setting_language_string` WHERE  `LangCode` = ? ");
        $stmt->bind_param("s", $LangCode);
        $result1 = $stmt->execute();
        $stmt->store_result();
        $num_rows = $stmt->num_rows;
        $stmt->close();
        if ($num_rows > 0) {
            $stmt = $this->con->prepare("INSERT INTO t_language_text(LangCode,LangTextName,LangText, CompanyId)
                            SELECT LangCode,`LangTextName`, `LangText`,$CompanyId FROM `t_setting_language_string` WHERE `LangCode` = ? ");
            $stmt->bind_param("s", $LangCode);
            $result = $stmt->execute();
            $stmt->close();
            if ($result) {
                $retval['retval'] = 0;
                return $retval;
            } else {
                $retval['retval'] = 1;
                return $retval;
            }
        } else {
            $retval['retval'] = 1;
            return $retval;
        }
    }

    //language text existence check ------------salam----------
    public function CheckLanguageTextExistence($LangCode, $CompanyId) {
        $stmt = $this->con->prepare("SELECT `LangCode` FROM `t_language_text` WHERE `LangCode` =?  AND `CompanyId` = ?");
        $stmt->bind_param("si", $LangCode, $CompanyId);
        $stmt->execute();
        $stmt->store_result();
        $num_rows = $stmt->num_rows;
        $stmt->close();
        if ($num_rows > 0) {
            return 1;
        } else
            return 0;
    }

    public function CompanyCreate($CompanyName, $LogoName) {

        $countCompany = $this->isCompanyExist($CompanyName);
        if ($countCompany == 0) {
            $stmt = $this->con->prepare("INSERT INTO t_company(CompanyName,CompanyImage) values(?,?)");
            $stmt->bind_param("ss", $CompanyName, $LogoName);
            $result = $stmt->execute();
            $stmt->close();
            if ($result) {
                $retval['retval'] = 0;
                return $retval;
            } else {
                $retval['retval'] = 1;
                return $retval;
            }
        } else {
            $retval['retval'] = 2;
            return $retval;
        }
    }

    //company existence check ------------salam----------
    public function isCompanyExist($CompanyName) {
        $stmt = $this->con->prepare("SELECT CompanyId from t_company WHERE CompanyName = ?");
        $stmt->bind_param("s", $CompanyName);
        $stmt->execute();
        $stmt->store_result();
        $num_rows = $stmt->num_rows;
        $stmt->close();
        if ($num_rows > 0) {
            return 1;
        } else
            return 0;
    }

    //Get company  list----salam  AND t_employee.CompanyId =79
    public function getCompanyList($CompanyId) {
        $stmt = $this->con->prepare("SELECT t_company.CompanyId, t_company.CompanyName, t_company.CompanyImage
FROM t_company
WHERE t_company.CompanyId =?");
        $stmt->bind_param("i", $CompanyId);
        $stmt->execute();
        $event = $stmt->get_result();
        $stmt->close();
        return $event;
    }

    //Get Language  Text----salam   
    public function getInterFacingStringListforCompany($CompanyId) {
        $stmt = $this->con->prepare("SELECT LangCode, `t_language_text`.`LangTextName`, `t_language_text`.`LangText`
          FROM `t_language_text` WHERE `t_language_text`.CompanyId = ? ORDER BY LangCode");
        $stmt->bind_param("i", $CompanyId);
        $stmt->execute();
        $lan = $stmt->get_result();
        $stmt->close();
        return $lan;
    }

    public function getInterFacingStringListByLanguage($gLanguageId) {

        $stmt = $this->con->prepare("SELECT `t_setting_language_string`.`LangTextName`, `t_setting_language_string`.`LangText`
          FROM t_setting_language_string WHERE `t_setting_language_string`.LangCode =?");
        $stmt->bind_param("s", $gLanguageId);
        $stmt->execute();
        $event = $stmt->get_result();
        $stmt->close();
        return $event;
    }

    //get company for  ---- update salam
    public function getAllCompanyListEdit($CompanyId, $EmpId) {
        $stmt = $this->con->prepare("SELECT DISTINCT t_company.CompanyId, t_company.CompanyName,t_company.CompanyImage,t_company.LangCode,t_language.`LangTitle`,t_timezone.`TimeZoneName`,`t_timezone`.`TimeZoneId`, t_employee.`MobileNo`,t_employee.`EmailAddress`, LanguageAdded       
  FROM t_company
  INNER JOIN t_language ON (t_company.`LangCode` = t_language.`LangCode`)
  INNER JOIN t_timezone ON (t_company.TimeZoneId = t_timezone.TimeZoneId)
  INNER JOIN t_employee ON (t_company.`CompanyId` = t_employee.CompanyId)
  WHERE t_employee.`Id`=? AND  t_company.CompanyId=?");

        $stmt->bind_param("ii", $EmpId, $CompanyId);
        $stmt->execute();
        $CompanyEdit = $stmt->get_result();
        $stmt->close();
        return $CompanyEdit;
    }

    //compy update   public function EventUpdate($EventName, $CompanyId, $RecordId) {
    public function CompanyUpdate($CompanyName, $LogoName, $RecordId, $LanguageId, $TimeZone, $EmployeeId, $Phone, $Email, $LanCode, $LangAdded) {

        //$LangAdded = json_encode($LangAdded);

        $stmt = $this->con->prepare("SELECT * FROM `t_setting_language_string` WHERE  t_setting_language_string.`LangCode`= ? ");
        $stmt->bind_param("s", $LanCode);
        $result1 = $stmt->execute();
        $stmt->store_result();
        $num_rows = $stmt->num_rows;
        $stmt->close();
        
        if ($num_rows > 0) {

            $CompanyId = $RecordId;
            $stmt = $this->con->prepare("UPDATE t_company SET CompanyName = ?,CompanyImage = ?,LangCode = ?,TimeZoneId = ?, LanguageAdded = ? WHERE CompanyId=?");
            $stmt->bind_param("sssssi", $CompanyName, $LogoName, $LanCode, $TimeZone, $LangAdded, $RecordId);
            $result = $stmt->execute();            
            $stmt->close();

            $stmt = $this->con->prepare("UPDATE t_employee SET MobileNo = ?,EmailAddress = ? WHERE Id=?");
            $stmt->bind_param("ssi", $Phone, $Email, $EmployeeId);
            $result2 = $stmt->execute();
            $stmt->close();

            if ($result && $result2) {
                $retval['retval'] = 0;
            } else {
                $retval['retval'] = 1;
            }
        } else {            
            $retval['retval'] = 1;
        }
        return $retval;
    }

    //lang Text update   public function EventUpdate($EventName, $CompanyId, $RecordId) {
    public function UpdateLanguageText($CompanyId, $LanFixedText, $LanText, $gLangCode) {
        $stmt = $this->con->prepare("UPDATE t_language_text SET LangText = ? WHERE CompanyId=? AND LangTextName = ? AND LangCode =?");
        $stmt->bind_param("siss", $LanText, $CompanyId, $LanFixedText, $gLangCode);
        $result = $stmt->execute();
        $stmt->close();
        if ($result) {
            $retval['retval'] = 0;
        } else {
            $retval['retval'] = 1;
        }
        return $retval;
    }

    //Master lang Text update   public function EventUpdate($EventName, $CompanyId, $RecordId) {
    public function UpdateMasterLanguageText($gLanguageId, $LanFixedText, $LanText) {
        $stmt = $this->con->prepare("UPDATE t_setting_language_string SET LangText = ? WHERE LangCode=? AND LangTextName = ?");
        $stmt->bind_param("sss", $LanText, $gLanguageId, $LanFixedText);
        $result = $stmt->execute();
        $stmt->close();
        if ($result) {
            $retval['retval'] = 0;
        } else {
            $retval['retval'] = 1;
        }
        return $retval;
    }

    public function InsertMultipleLanguage($LangCode, $CompanyId) {
        $stmt = $this->con->prepare("UPDATE t_company SET `LanguageAdded` = ? WHERE `CompanyId`=? ");
        $stmt->bind_param("si", $LangCode, $CompanyId);
        $result = $stmt->execute();
        $stmt->close();
        if ($result) {
            $retval['retval'] = 0;
        } else {
            $retval['retval'] = 1;
        }
        return $retval;
    }

    public function getDefaultLanguage($CompanyId) {
        $stmt = $this->con->prepare("SELECT `LanguageAdded` FROM `t_company` WHERE `CompanyId` = ?");
        $stmt->bind_param("i", $CompanyId);
        $stmt->execute();
        $LanguageList = $stmt->get_result();
        $stmt->close();
        return $LanguageList;
    }

    function SetDefaultLanguage($LangCode) {

        $lancode = explode(',', $LangCode);
        $lancode = implode("','", $lancode);
        $lancode = "'" . $lancode . "'";

        $stmt = $this->con->prepare("SELECT `LangCode`,`LangTitle` FROM `t_language` WHERE `LangCode` IN ({$lancode})");
        $stmt->execute();
        $LanguageList = $stmt->get_result();
        $stmt->close();
        return $LanguageList;
    }


    //Company delete db-----------salam-------------
    public function CompanyDelete($CompanyId) {
        $stmt = $this->con->prepare("delete FROM t_company WHERE t_company.CompanyId=?");
        $stmt->bind_param("i", $CompanyId);
        $stmt->execute();
        $CompanyDelete = $stmt->get_result();
        $stmt->close();
        return $CompanyDelete;
    }

    public function isEventExist($EventName, $EventDate, $CompanyId) {
        $stmt = $this->con->prepare("SELECT EventId from t_event WHERE EventName = ? AND EventDate =?  AND CompanyId=?");
        $stmt->bind_param("ssi", $EventName, $EventDate, $CompanyId);
        $stmt->execute();
        $stmt->store_result();
        $num_rows = $stmt->num_rows;
        $stmt->close();
        if ($num_rows > 0) {
            return 1;
        } else
            return 0;
    }

    //site-list edit db---salam
    public function getAllSiteListEdit($SiteId) {
        $stmt = $this->con->prepare("SELECT t_site.SiteId, t_site.SiteName,t_site.StreetAddress,t_site.EmergencyContact,
            t_site.SystemAssistantContct	
		FROM t_site
		WHERE t_site.SiteId=?");
        $stmt->bind_param("i", $SiteId);
        $stmt->execute();
        $EventEdit = $stmt->get_result();
        $stmt->close();
        return $EventEdit;
    }

    public function EmployeeDelete($EmployeeId) {
        $stmt = $this->con->prepare("delete FROM t_employee WHERE t_employee.Id=?");
        $stmt->bind_param("i", $EmployeeId);
        $stmt->execute();
        $CompanyDelete = $stmt->get_result();
        $stmt->close();
        return $CompanyDelete;
    }

    //Method to unique password generate
    private function generatePassword() {
        $seed = str_split('abcdefghijklmnopqrstuvwxyz' . 'ABCDEFGHIJKLMNOPQRSTUVWXYZ' . '0123456789!@#$%^&*()'); // and any other characters
        shuffle($seed); // probably optional since array_is randomized; this may be redundant
        $rand = '';
        foreach (array_rand($seed, 10) as $k)
            $rand .= $seed[$k];
        return $rand;
    }

    //Checking the Employee is valid or not by api key
    public function isValidEmployee($api_key) {
        $stmt = $this->con->prepare("SELECT CompanyId from t_company WHERE api_key=?");
        $stmt->bind_param("s", $api_key);
        $stmt->execute();
        $stmt->store_result();
        $num_rows = $stmt->num_rows;
        $stmt->close();
        return $num_rows > 0;
    }

    //Checking is valid or not by api key
    public function isValidCheckRegistration($api_key) {
        $stmt = $this->con->prepare("SELECT CompanyId from t_company WHERE api_key=?");
        $stmt->bind_param("s", $api_key);
        $stmt->execute();
        $stmt->store_result();
        $num_rows = $stmt->num_rows;
        $stmt->close();
        return $num_rows > 0;
    }

    //Checking the Visitor is valid or not by api key
    public function isValidVisitor($api_key) {
        $stmt = $this->con->prepare("SELECT CompanyId from t_company WHERE api_key=?");
        $stmt->bind_param("s", $api_key);
        $stmt->execute();
        $stmt->store_result();
        $num_rows = $stmt->num_rows;
        $stmt->close();
        return $num_rows > 0;
    }

    //Checking the Company is valid or not by api key
    public function isValidCompanyAPIKey($api_key) {
        $stmt = $this->con->prepare("SELECT CompanyId from t_company WHERE api_key=?");
        $stmt->bind_param("s", $api_key);
        $stmt->execute();
        $stmt->store_result();
        $num_rows = $stmt->num_rows;
        $stmt->close();
        return $num_rows > 0;
    }

    //Method to fetch all Visitor from database
    public function getVisitorsDatalist($CompanyId, $HostId, $VisitorTypeId, $SignOutNotSignOut, $StartDate, $EndDate, $sSearch, $sOrder, $iDisplayStart, $iDisplayLength) {
		
		//$OrderBy = mysqli_real_escape_string($this->con, $sOrder);
		
        $sWhere = "";
        if ($sSearch != "") {
            $sWhere = " AND (t_visitor.VisitorName LIKE '%" . mysqli_real_escape_string($this->con, $sSearch) . "%' 
		   OR " . " t_employee.CompanyId LIKE '%" . mysqli_real_escape_string($this->con,$sSearch) . "%'			
		   OR " . " t_visitor.EmployeeId LIKE '%" . mysqli_real_escape_string($this->con,$sSearch) . "%'			
		   OR " . " t_visitor.VisitorCompany LIKE '%" . mysqli_real_escape_string($this->con,$sSearch) . "%'			
		   OR " . " t_employee.FullName LIKE '%" . mysqli_real_escape_string($this->con,$sSearch) . "%'			
		   OR " . " t_employee.MobileNo LIKE '%" . mysqli_real_escape_string($this->con,$sSearch) . "%'		
		   OR " . " t_visitortype.VisitorType LIKE '%" . mysqli_real_escape_string($this->con,$sSearch) . "%') ";
        }

        $sLimit = "";
        if (isset($iDisplayStart)) {
            $sLimit = " LIMIT " . $iDisplayStart . ", " . $iDisplayLength;
        }

        if ($SignOutNotSignOut == 'SignOut') {
            $SignOut_NotSignOut = "AND t_visitor.SignOutTime > '0000-00-00 00:00:00'";
        } else {
            $SignOut_NotSignOut = "AND t_visitor.SignOutTime='0000-00-00 00:00:00'";
        }
        $stmt = $this->con->prepare("SELECT SQL_CALC_FOUND_ROWS t_visitor.VisitorId,t_visitor.VisitorName, 
			t_visitor.VisitorCompany, t_employee.CompanyId,t_employee.FullName, t_visitor.SignInTime, 
			t_visitor.SignOutTime, t_employee.MobileNo, t_visitor.EmailAddress, t_visitor.EstDuration, 
			t_visitor.ImagePath,t_visitortype.VisitorType,t_visitor.EmployeeId
	  FROM t_visitor 
		INNER JOIN t_employee ON (t_visitor.EmployeeId = t_employee.Id) 
		INNER JOIN t_visitortype ON (t_visitor.VisitorTypeId = t_visitortype.VisitorTypeId) 
		WHERE t_employee.CompanyId=? 
		AND (t_visitor.EmployeeId = ? OR ? = 0)
		AND (t_visitor.VisitorTypeId = ? OR ? = 0)
		AND (t_visitor.`date` BETWEEN ? AND ?)
		$SignOut_NotSignOut $sWhere $sOrder $sLimit");
        $stmt->bind_param("iiiiiss", $CompanyId, $HostId, $HostId, $VisitorTypeId, $VisitorTypeId, $StartDate, $EndDate);
        $stmt->execute();
        $TotalRowa = $stmt->get_result();
        $stmt->close();

        $sQuery = "SELECT FOUND_ROWS()";
        $rResultFilterTotal = $this->con->prepare($sQuery);
        $rResultFilterTotal->execute();
        $aResultFilterTotal = mysqli_fetch_array($rResultFilterTotal->get_result());
        $iFilteredTotal = $aResultFilterTotal[0];
        $rResultFilterTotal->close();

        $resultArr[] = $iFilteredTotal;
        $resultArr[] = $TotalRowa;
        return $resultArr;
    }

    //Method to fetch all Visitor for dashboard
    public function getVisitorListForDashBoard($CompanyId, $CurrentDate, $sSearch, $sOrder, $iDisplayStart, $iDisplayLength) {

        $sWhere = "";
        if ($sSearch != "") {
            $sWhere = " AND (t_visitor.VisitorName LIKE '%" . mysqli_real_escape_string($this->con, $sSearch) . "%' 
		   OR " . " t_employee.CompanyId LIKE '%" . mysqli_real_escape_string($this->con, $sSearch) . "%'			
		   OR " . " t_visitor.EmployeeId LIKE '%" . mysqli_real_escape_string($this->con, $sSearch) . "%'			
		   OR " . " t_visitor.VisitorCompany LIKE '%" . mysqli_real_escape_string($this->con, $sSearch) . "%'			
		   OR " . " t_employee.FullName LIKE '%" . mysqli_real_escape_string($this->con, $sSearch) . "%'			
		   OR " . " t_employee.MobileNo LIKE '%" . mysqli_real_escape_string($this->con, $sSearch) . "%'		
		   OR " . " t_visitortype.VisitorType LIKE '%" . mysqli_real_escape_string($this->con, $sSearch) . "%') ";
        }

        $sLimit = "";
        if (isset($iDisplayStart)) {
            $sLimit = " LIMIT " . $iDisplayStart . ", " . $iDisplayLength;
        }

        $stmt = $this->con->prepare("SELECT SQL_CALC_FOUND_ROWS t_visitor.VisitorId,t_visitor.VisitorName, 
			t_visitor.VisitorCompany, t_employee.CompanyId,t_employee.FullName, t_visitor.SignInTime, 
			t_visitor.SignOutTime, t_employee.MobileNo, t_visitor.EmailAddress, t_visitor.EstDuration, 
			t_visitor.ImagePath,t_visitortype.VisitorType,t_visitor.EmployeeId
		  FROM t_visitor 
			INNER JOIN t_employee ON (t_visitor.EmployeeId = t_employee.Id) 
			INNER JOIN t_visitortype ON (t_visitor.VisitorTypeId = t_visitortype.VisitorTypeId) 
			WHERE t_employee.CompanyId=? 
			AND (t_visitor.`date` = ?)
			$sWhere $sOrder $sLimit");
        $stmt->bind_param("is", $CompanyId, $CurrentDate);
        $stmt->execute();
        $TotalRowa = $stmt->get_result();
        $stmt->close();

        $sQuery = "SELECT FOUND_ROWS()";
        $rResultFilterTotal = $this->con->prepare($sQuery);
        $rResultFilterTotal->execute();
        $aResultFilterTotal = mysqli_fetch_array($rResultFilterTotal->get_result());
        $iFilteredTotal = $aResultFilterTotal[0];
        $rResultFilterTotal->close();

        $resultArr[] = $iFilteredTotal;
        $resultArr[] = $TotalRowa;
        return $resultArr;
    }

    //Current date time
    private function Currentdatetime() {
        date_default_timezone_set('Asia/Dhaka');
        //date_default_timezone_set('UTC');
        return date("Y-m-d H:i:s");
    }

    //Current date
    private function Currentdate() {
        date_default_timezone_set('Asia/Dhaka');
        //date_default_timezone_set('UTC');
        return date("Y-m-d");
    }

    //Current date
    private function Currentdatefun($Getdate) {
        date_default_timezone_set('Asia/Dhaka');
        //date_default_timezone_set('UTC');
        //$Currentdate = date("Y-m-d");
        $Currentdate = date($Getdate);
        return $Currentdate;
    }

    //Method to generate a unique api key every time
    private function generateApiKey() {
        return md5(uniqid(rand(), true));
    }

    //Method to fetch not signout visitors
    public function getNotSignOutVisitors($CompanyId) {
        $currentdate = date("Y-m-d");
        $stmt = $this->con->prepare("SELECT t_visitor.VisitorId,t_visitor.VisitorName,
				t_visitor.VisitorCompany, t_visitor.ImagePath
				FROM t_visitor 
				INNER JOIN t_employee ON (t_visitor.EmployeeId = t_employee.Id) 			
				WHERE t_employee.CompanyId = ?									
				AND t_visitor.SignOutTime = '0000-00-00 00:00:00'
				AND `t_visitor`.`date`=?
				ORDER BY t_visitor.VisitorName;");

        $stmt->bind_param("is", $CompanyId, $currentdate);
        $stmt->execute();
        $employee = $stmt->get_result();
        $stmt->close();
        return $employee;
    }

}
