<?php
//Constants to connect with the database
define('DB_USERNAME', 'root');
define('DB_PASSWORD', '');
define('DB_HOST', '192.168.0.53');
//define('DB_HOST', 'localhost');
define('DB_NAME', 'trackmyvisitor_db');