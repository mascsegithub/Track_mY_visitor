 
<script type="text/javascript">
var APIKEY = localStorage.getItem('APIKEY');
var FULLNAME = localStorage.getItem('FULLNAME');
var EMAILADDRESS = localStorage.getItem('EMAILADDRESS');
var COMPANYNAME = localStorage.getItem('COMPANYNAME');
var COMPANYID = localStorage.getItem('COMPANYID');
var ISCOMPANYADMIN = localStorage.getItem('ISCOMPANYADMIN');
var EMPLOYEEID = localStorage.getItem('EMPLOYEEID');
var TimeZoneName = localStorage.getItem('TimeZoneName');
var LangCode = localStorage.getItem('LangCode');
</script>