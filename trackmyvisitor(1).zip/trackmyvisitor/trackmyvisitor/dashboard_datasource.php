<?php

include ("define.inc");
$conn = mysql_connect(HOSTNAME, DBUSER, DBPWD) or die('Could not connect: ' . mysql_error());
mysql_select_db(DBNAME, $conn) or die('Could not connect: ' . mysql_error());
mysql_query('SET CHARACTER SET utf8');


include('function_lib.php');
include('languages/lang_en.php');
include('languages/lang_fr.php');
include('languages/lang_switcher_report.php');

$gTEXT = $TEXT;
$task = '';
if (isset($_POST['action'])) {
    $task = $_POST['action'];
} else if (isset($_GET['action'])) {
    $task = $_GET['action'];
}

switch ($task) {

    case 'insertUpdateRegionData':
        insertUpdateRegionData($conn);
        break;
    case "getVisitorsNumber" :
        getVisitorsInfo($conn);
        break;
    case "deleteRegion" :
        deleteRegion($conn);
        break;
    default :
        echo "{failure:true}";
        break;
}

//*********************************************Data Element Frequency****************



function getVisitorsInfo($conn) {

    global $gTEXT;

    $data = array();

    $sLimit = "";
    if (isset($_POST['iDisplayStart'])) {
        $sLimit = " LIMIT " . mysql_real_escape_string($_POST['iDisplayStart']) . ", " . mysql_real_escape_string($_POST['iDisplayLength']);
    }

    $sOrder = "";
    if (isset($_POST['iSortCol_0'])) {
        $sOrder = " ORDER BY  ";
        for ($i = 0; $i < mysql_real_escape_string($_POST['iSortingCols']); $i++) {
            $sOrder .= fnColumnToField_RegionName(mysql_real_escape_string($_POST['iSortCol_' . $i])) . "
								" . mysql_real_escape_string($_POST['sSortDir_' . $i]) . ", ";
        }
        $sOrder = substr_replace($sOrder, "", -2);
    }

    $sWhere = "";
    if ($_POST['sSearch'] != "") {
        $sWhere = " WHERE  (RegionName LIKE '%" . mysql_real_escape_string($_POST['sSearch']) . "%') ";
    }

    $sql = "SELECT SQL_CALC_FOUND_ROWS RegionId,RegionName
				FROM t_whoregion
				$sWhere $sOrder $sLimit ";
//echo $sql;
    $result = mysql_query($sql, $conn);
    $total = mysql_num_rows($result);
    $sQuery = "SELECT FOUND_ROWS()";
    $rResultFilterTotal = mysql_query($sQuery);
    $aResultFilterTotal = mysql_fetch_array($rResultFilterTotal);
    $iFilteredTotal = $aResultFilterTotal[0];

    $sOutput = '{';
    $sOutput .= '"sEcho": ' . intval($_POST['sEcho']) . ', ';
    $sOutput .= '"iTotalRecords": ' . $iFilteredTotal . ', ';
    $sOutput .= '"iTotalDisplayRecords": ' . $iFilteredTotal . ', ';
    $sOutput .= '"aaData": [ ';
    $serial = $_POST['iDisplayStart'] + 1;

    $y = "<a class='edit_button itmEdit' href='javascript:void(0);'><span class='task-del'>" . $gTEXT['Edit'] . "</span></a>";
    $z = "<a class='delete_button itmDrop' href='javascript:void(0);'><span class='task-del'>" . $gTEXT['Delete'] . "</span></a>";

    $f = 0;
    while ($aRow = mysql_fetch_array($result)) {
        $RegionName = $aRow['RegionName'];

        if ($f++)
            $sOutput .= ',';

        $sOutput .= "[";
        $sOutput .= '"' . $aRow['RegionId'] . '",';
        $sOutput .= '"' . $serial++ . '",';
        $sOutput .= '"' . $RegionName . '",';
        $sOutput .= '"' . $y . $z . '"';
        $sOutput .= "]";
    }
    $sOutput .= '] }';
    echo $sOutput;
}

function fnColumnToField_RegionName($i) {
    if ($i == 2)
        return "RegionName";
}

function insertUpdateRegionData($conn) {
    $jUserId = $_REQUEST['jUserId'];
    $language = $_REQUEST['language'];
    $RecordId = str_replace("'", "''", $_POST['RecordId']);  //$_POST['RecordId'];
    $RegionName = $_POST['RegionName'];  //$_POST['YearName'];

    if ($RecordId == '') {

        $sql = "INSERT INTO t_whoregion(RegionName)
                 VALUES ('" . $RegionName . "')";
        $aQuery1 = array('command' => 'INSERT', 'query' => $sql, 'sTable' => 't_whoregion', 'pks' => array('RegionId'), 'pk_values' => array(), 'bUseInsetId' => TRUE);
        $aQuerys = array($aQuery1);
    } else {

        $sql = "UPDATE 
                 t_whoregion SET 
                 RegionName = '" . $RegionName . "'
                 WHERE RegionId = " . $RecordId;
        $aQuery1 = array('command' => 'UPDATE', 'query' => $sql, 'sTable' => 't_whoregion', 'pks' => array('RegionId'), 'pk_values' => array($RecordId), 'bUseInsetId' => FALSE);
        $aQuerys = array($aQuery1);
    }

    echo json_encode(exec_query($aQuerys, $jUserId, $language));
}

function deleteRegion($conn) {
    $jUserId = $_REQUEST['jUserId'];
    $language = $_REQUEST['language'];
    $RecordId = $_POST['RecordId'];
    if ($RecordId != '') {

        $sql = " DELETE FROM t_whoregion WHERE RegionId = " . $RecordId . " ";
        $aQuery1 = array('command' => 'DELETE', 'query' => $sql, 'sTable' => 't_whoregion', 'pks' => array('RegionId'), 'pk_values' => array($RecordId), 'bUseInsetId' => FALSE);
        $aQuerys = array($aQuery1);
    }
    echo json_encode(exec_query($aQuerys, $jUserId, $language));
}
