function resetForm(id) {
    $('#' + id).each(function () {
        this.reset();
    });
}

function onListPanel() {
    $('#list-panel, .btn-form').show();
    $('#form-panel, .btn-list').hide();
    getSiteList();
}

function onFormPanel() {
    //resetForm("t_year_form");
    //RecordId = '';
    $('#list-panel, .btn-form').hide();
    $('#form-panel, .btn-list').show();
}

function onEditPanel() {
    $('#list-panel, .btn-form').hide();
    $('#form-panel, .btn-list').show();
}

function onConfirmWhenSiteAdd() {
    var error = 0;
    var SiteName = $("#SiteName").val();
    // var SiteTitle = $("#SiteTitle").val();
    var EmergencyContact = $("#EmergencyContact").val();
    if (SiteName == '') {
        $("#SiteNameVal").html('Please enter site  name');
        $("#SiteName").addClass('invalidval');
        error = 1;
    }
    else {
        $("#SiteNameVal").html('');
        $("#SiteName").removeClass('invalidval');
    }

    if (EmergencyContact == '') {
        $("#EmergencyContactVal").html('Please enter emergency contact');
        $("#EmergencyContact").addClass('invalidval');
        error = 1;
    }
    else {
        $("#EmergencyContactVal").html('');
        $("#EmergencyContact").removeClass('invalidval');
    }
    if (error == 1) {
        return false;
    }
    else {
        $.ajax({
            "async": true,
            url: baseUrl + "site-create",
            "method": "POST",
            "data": $('#site_add_form').serialize() + '&CompanyId=' + COMPANYID,
            "headers": {
                "Apikey": APIKEY,
                "cache-control": "no-cache"
            },
            success: function (response) {
                //$("#AllSiteTable").hide();
                //$("#SiteEntry").show();
                if (response['error'] == false) {
                    $("#MessageShow").html(response['message']);
                    $('#myModal').modal('show');
                    //return false;
                }
                else {
                    $("#MessageShow").html(response['message']);
                    $('#myModal').modal('show');
                }

            }
        });
    }
}

function onConfirmWhenSiteEdit(response) {

    response = response['SiteEdit'];
    //lastEmployeeId = response[0]['Id']
    var RecordId = response[0]['SiteId']
    var SiteName = response[0]['SiteName'];
    var StreetAddress = response[0]['StreetAddress'];
    var EmergencyContact = response[0]['EmergencyContact']
    var SystemAssistantContct = response[0]['SystemAssistantContct'];

    //$("#SiteEntry").show();
    //$("#AllSiteTable").hide();


    $("#SiteName").val(SiteName);
    $("#RecordId").val(RecordId);
    $("#StreetAddress").val(StreetAddress);
    $("#EmergencyContact").val(EmergencyContact);
    $("#SystemAssistantContct").val(SystemAssistantContct);


}
function SiteEdit(SiteId) {
//alert(EmployeeId);
    $.ajax({
        "async": true,
        url: baseUrl + "site-list-edit/" + SiteId,
        "method": "GET",
        "headers": {
            "Apikey": APIKEY,
            "cache-control": "no-cache"
        },
        success: function (response)
        {
            onConfirmWhenSiteEdit(response);
            onEditPanel();
        }
    });
}
function siteDelete(SiteId) {
    if (!confirm("Do you really want to delete this record?")) {
        return false;
    } else {
        $.ajax({
            "async": true,
            url: baseUrl + "site-delete/" + SiteId,
            "method": "GET",
            "headers": {
                "Apikey": APIKEY,
                "cache-control": "no-cache"
            },
            success: function (response)
            {
                if (response['error'] == false) {
                    var msg = "Site name has been deleted successfully";
                    $("#MessageShow").html(msg);
                    $('#myModal').modal('show');
                    getSiteList();
                } else {
                    var msg = "Sorry, Site name has not been deleted";
                    $("#MessageShow").html(msg);
                    $('#myModal').modal('show');
                }
            }
        });
    }
}
function removeErrorline() {
    $("#SiteNameVal").html('');
    $("#SiteName").removeClass('invalidval');
    $("#EmergencyContactVal").html('');
    $("#EmergencyContact").removeClass('invalidval');

}

$(function () {
    onListPanel();

    //getSiteList();

    $('#site_add_form').submit(function () {
        //onConfirmWhenEventAdd();
        return false;
    });

    resetForm("event_add_form");
    $("#AddNewSite").click(function () {
        removeErrorline();
        //$("#AllSiteTable").hide();
        //$("#SiteEntry").show();
        $("#SiteName").val('');
        $("#RecordId").val('');
        $("#StreetAddress").val('');
        $("#EmergencyContact").val('');
        $("#SystemAssistantContct").val('');
        resetForm("site_add_form");
    });
    $("#AllSite").click(function () {
        removeErrorline();
        resetForm("site_add_form");
        getSiteList();
        //$("#AllSiteTable").show();
        //$("#SiteEntry").hide();
    });
});
function getSiteListData(response) {
    response = response['site'];
    var trHTML = '';
    var SiteId = '';
    var SiteName = '';
    var StreetAddress = '';
    var EmergencyContact = '';
    var SystemAssistantContct = '';
    var CompanyName = '';
    trHTML += '<div id="list-panel"><h3>Site List</h3><table  id="" class="table table-striped table-bordered display table-hover" cellspacing="0"><thead><tr><th style="text-align: left;">Site Name</th><th style="text-align: left;">Street Address</th><th style="text-align: left;">Emergency Contact</th><th style="text-align: left;">System Assistant Contact</th><th style="text-align: left;">Company</th><th style="text-align: left;">  </th></tr></thead><tbody>';
    $.each(response, function (key, value) {
        SiteId = value.SiteId;
        SiteName = value.SiteName;
        StreetAddress = value.StreetAddress;
        // alert(StreetAddress);
        if (StreetAddress == null) {
            StreetAddress = '';
        }
        EmergencyContact = value.EmergencyContact;
//                EmergencyContact = value.EmergencyContact;
        if (EmergencyContact == null) {
            EmergencyContact = '';
        }
        SystemAssistantContct = value.SystemAssistantContct;
        if (SystemAssistantContct == null) {
            SystemAssistantContct = '';
        }
        CompanyName = value.CompanyName;
        trHTML +=
                '<tr><td>' + SiteName +
                '</td><td>' + StreetAddress +
                '</td><td>' + EmergencyContact +
                '</td><td>' + SystemAssistantContct +
                '</td><td>' + CompanyName +
                '</td><td style="text-align: center;width:15%;"> <input type="submit"  value="Edit" class="btn btn-primary btn-sm" onClick="SiteEdit(' + SiteId + ')">' + '    ' + '<input style="display:none;" type="submit" value="Delete" class="btn btn-danger btn-sm" onClick="siteDelete(' + SiteId + ')">' +
                '</td></a></tr>';
    });
    trHTML += '</tbody></table></div>';
    $('#AllSiteTable').html(trHTML); //append
}
function getSiteList() {
    $.ajax({
        "async": true,
        url: baseUrl + "get-site/" + COMPANYID,
        "method": "GET",
        "headers": {
            "Apikey": APIKEY,
            "cache-control": "no-cache"
        },
        success: function (response)
        {
            getSiteListData(response);
        }
    });
}


