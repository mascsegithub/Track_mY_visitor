
var $ = jQuery.noConflict();

function resetForm(id) {
	$('#' + id).each(function() {
		this.reset();
	});
}

function validateEmail(email) {
    var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return re.test(email);
}


function onConfirmWhenRegister() {

    var Password = $("#Password").val();
    var ConfirmPass = $("#ConfirmPassword").val();
    var error = 0;

    if (Password == '') {
        $("#invalidpassword").html('Please enter password');
        error = 1;
    }else {
        $("#invalidpassword").html('');
    }

	
    if (error == 1) {
        return false;
    }
    else {
    $.ajax({
        "async": true,
        url: baseUrl + "reset-password",
        "method": "POST",
        "data": $('#complete-register-form').serialize(),
        success: function (response){
			if(response['error'] == 0){
				resetForm("complete-register-form");
				$("#registerformsuccess").show();
				$("#registerform").hide();				
			}else if(response['error'] == 2){				
				$("#registerform").show();
				$("#registerformsuccess").hide();
				$("#invalidEmail").html(response['message']);
				
			}else if(response['error'] == 3){				
				$("#registerform").show();
				$("#registerformsuccess").hide();
				$("#invalidConfirmpassword").html(response['message']);

			}else{				
				$("#registerform").show();
				$("#registerformsuccess").hide();
				$("#Errormessage").html(response['message']);
			}
        }
    });
   }
}

$(function () {
    $('#complete-register-form').submit(function () {
        onConfirmWhenRegister();
        return false;
    });

});
