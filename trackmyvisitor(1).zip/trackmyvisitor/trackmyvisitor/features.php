<!DOCTYPE html>
<html dir="ltr" lang="en-US">
    <head>

        <meta http-equiv="content-type" content="text/html; charset=utf-8" />
        <meta name="author" content="SemiColonWeb" />
        <!-- Stylesheets
        ============================================= -->
        <link href="http://fonts.googleapis.com/css?family=Lato:300,400,400italic,600,700|Raleway:300,400,500,600,700|Crete+Round:400italic" rel="stylesheet" type="text/css" />
        <link rel="stylesheet" href="css/bootstrap.css" type="text/css" />
        <link rel="stylesheet" href="style.css" type="text/css" />
        <link rel="stylesheet" href="css/dark.css" type="text/css" />
        <link rel="stylesheet" href="css/font-icons.css" type="text/css" />
        <link rel="stylesheet" href="css/animate.css" type="text/css" />
        <link rel="stylesheet" href="css/magnific-popup.css" type="text/css" />
        <link rel="stylesheet" href="css/responsive.css" type="text/css" />
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />

        <link rel="stylesheet" type="text/css" href="css/settings.css" media="screen" />
        <link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon">
        <link rel="icon" href="images/favicon.ico" type="image/x-icon">
        <!--[if lt IE 9]>
            <script src="http://css3-mediaqueries-js.googlecode.com/svn/trunk/css3-mediaqueries.js"></script>
        <![endif]-->
        <!-- Document Title
        ============================================= -->
        <title>Features - Track My Visitor</title>
        <?php include('global_variables.php'); ?>

    </head>

    <body class="stretched">
        <!-- Document Wrapper
        ============================================= -->
        <div id="wrapper" class="clearfix">
            <!-- Header
            ============================================= -->
            <?php include('header.php'); ?>
            <!-- #header end -->
            <!-- Content
            ============================================= -->
            <section id="content">

                <!--                 <div class="content-wrap">-->
                <div class="">

                    <div class="container clearfix">
                        <div class="pricing bottommargin">
                            <div class="promo  promo-center">
                                <h3>Just the right amount of functionality</h3>
                                <span>Increase efficiency, optimize out-dated processes and improve security at the same time.</span>                             
                            </div>

                            <div class="col-sm-4">
                                &nbsp;&nbsp;
                                <div class="feature-box fbox-center fbox-effect">
                                    <div class="fbox-icon">
                                        <a href="#"><i class="icon-bell"></i></a>
                                    </div>
                                    <h3>Host Notifications</h3>
                                    <p>My Visitor sends automatic visitor notifications to the host via SMS, email and voice alerting them of their guest as well as their guest's pick-up location.</p>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                &nbsp;&nbsp;
                                <div class="feature-box fbox-center fbox-effect">
                                    <div class="fbox-icon">
                                        <a href="#"><i class="icon-large icon-file"></i></a>
                                    </div>
                                    <h3>Legal & Compliance</h3>
                                    <p>My Visitor makes it easy for guests to complete and submit legal documents digitally and for them to be available for efficient future look-ups.</p>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                &nbsp;&nbsp;
                                <div class="feature-box fbox-center fbox-effect">
                                    <div class="fbox-icon">
                                        <a href="#"><i class="icon-bullhorn2"></i></a>
                                    </div>
                                    <h3>Evacuation Mode</h3>
                                    <p>My Visitor assists during emergency evacuations by dispatching notifications to all employees letting them know that there is an evacuation in effect.</p>
                                </div>
                            </div>
                        </div>
                        <div class="pricing bottommargin">
                            <div class="col-sm-4">
                                &nbsp;&nbsp;
                                <div class="feature-box fbox-center fbox-effect">
                                    <div class="fbox-icon">
                                        <a href="#"><i class="icon-large icon-vcard"></i></a>
                                    </div>
                                    <h3>Visitor Badges</h3>
                                    <p>My Visitor prints custom visitor badges that help employees easily recognize visitors as well as their credentials, clearance levels and access durations.</p>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                &nbsp;&nbsp;
                                <div class="feature-box fbox-center fbox-effect">
                                    <div class="fbox-icon">
                                        <a href="#"><i class="icon-large icon-qrcode"></i></a>
                                    </div>
                                    <h3>QR Codes</h3>
                                    <p>Automatically-assigned QR codes let visitors re-use their previously-issued badge for a much quicker registration process on subsequent visits.</p>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                &nbsp;&nbsp;
                                <div class="feature-box fbox-center fbox-effect">
                                    <div class="fbox-icon">
                                        <a href="#"><i class="icon-large icon-camera"></i></a>
                                    </div>
                                    <h3>Visitor Image Capture</h3>
                                    <p>For security reasons, My Visitor automatically captures an image of every visitor to your facility and stores it within your customer portal for easy retrieval.</p>
                                </div>
                            </div>
                        </div>
                        <div class="pricing bottommargin">
                            <div class="col-sm-4">
                                &nbsp;&nbsp;
                                <div class="feature-box fbox-center fbox-effect">
                                    <div class="fbox-icon">
                                        <a href="#"><i class="icon-tasks"></i></a>
                                    </div>
                                    <h3>End-of-day Reports</h3>
                                    <p>My Visitor can quickly and automatically generate daily, weekly or monthly visitation reports using custom data points and with multiple export options.</p>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                &nbsp;&nbsp;
                                <div class="feature-box fbox-center fbox-effect">
                                    <div class="fbox-icon">
                                        <a href="#"><i class="icon-credit"></i></a>
                                    </div>
                                    <h3>Smart Pre-registrations</h3>
                                    <p>Hosts can generate pre-registrations to be automatically sent to their visitors including location and meeting details as well as a QR code for easy sign in.</p>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                &nbsp;&nbsp;
                                <div class="feature-box fbox-center fbox-effect">
                                    <div class="fbox-icon">
                                        <a href="#"><i class="icon-large icon-dribbble"></i></a>
                                    </div>
                                    <h3>Multilingual Ready </h3>
                                    <p>My Visitor can be translated into any language as well as offer multiple language options to visitors based on geographic location or visitor type.</p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div>
                        <div class="promo promo-center bottommargin">
                            <h3>More awesome features</h3>
                            <span>Easy to digest plans with room for customization in between</span>
                        </div>
                    </div>
                    <!--                    <div class="col-md-12">
                    
                                            <table class="table table-bordered">
                                                <thead>
                                                    <tr>
                                                        <th class="thBorder"></th>
                                                        <th style="text-align:center; background-color:#576363;color:#ffffff; height:50px;">Free</th>
                                                        <th style="text-align:center; background-color:#576363;color:#ffffff;">Corporate</th>
                                                        <th style="text-align:center; background-color:#576363;color:#ffffff;">Enterprise</th>                                    
                                                    </tr>
                                                    <tr>
                                                        <th style="text-align:center; background-color:#a6a6a6;color:#ffffff;" colspan="4">My Visitor Features</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr>
                                                        <td class="rowBackColor">B / W Badge Printing</td>
                                                        <td></td>
                                                        <td style="text-align:center;"><img src="images/tik.png"></td>
                                                        <td style="text-align:center;"><img src="images/tik.png"></td>
                                                    </tr>
                                                    <tr>
                                                        <td class="rowBackColor">Colour Badge Printing</td>
                                                        <td></td>
                                                        <td></td>
                                                        <td style="text-align:center;"><img src="images/tik.png"></td>
                                                    </tr>
                                                    <tr>
                    
                                                        <td class="rowBackColor">Email Notifications</td>
                                                        <td style="text-align:center;"><img src="images/tik.png"></td>
                                                        <td style="text-align:center;"><img src="images/tik.png"></td>
                                                        <td style="text-align:center;"><img src="images/tik.png"></td>
                                                    </tr>
                                                    <tr>
                                                        <td class="rowBackColor">SMS Notifications</td>
                                                        <td></td>
                                                        <td style="text-align:center;"><img src="images/tik.png"></td>
                                                        <td style="text-align:center;"><img src="images/tik.png"></td>
                                                    </tr>
                                                    <tr>
                                                        <td class="rowBackColor">Voice Notification</td>
                                                        <td></td>
                                                        <td style="text-align:center;"><img src="images/tik.png"></td>
                                                        <td style="text-align:center;"><img src="images/tik.png"></td>
                                                    </tr>
                                                    <tr>
                                                        <td class="rowBackColor">Emergency / Evacuation Notifications</td>
                                                        <td></td>
                                                        <td style="text-align:center;"><img src="images/tik.png"></td>
                                                        <td style="text-align:center;"><img src="images/tik.png"></td>
                                                    </tr>
                                                    <tr>
                                                        <td class="rowBackColor">Unlimited Hosts</td>
                                                        <td></td>
                                                        <td style="text-align:center;"><img src="images/tik.png"></td>
                                                        <td style="text-align:center;"><img src="images/tik.png"></td>
                                                    </tr>
                                                    <tr>
                                                        <td class="rowBackColor">Unlimited Visitors</td>
                                                        <td style="text-align:center;"><img src="images/tik.png"></td>
                                                        <td style="text-align:center;"><img src="images/tik.png"></td>
                                                        <td style="text-align:center;"><img src="images/tik.png"></td>
                                                    </tr>
                                                    <tr>
                                                        <td class="rowBackColor">Visitor pre-registration emails with QR and Map</td>
                                                        <td></td>
                                                        <td style="text-align:center;"><img src="images/tik.png"></td>
                                                        <td style="text-align:center;"><img src="images/tik.png"></td>
                                                    </tr>
                                                    <tr>
                                                        <td class="rowBackColor">Returning visitor processing</td>
                                                        <td></td>
                                                        <td></td>
                                                        <td style="text-align:center;"><img src="images/tik.png"></td>
                                                    </tr>
                                                    <tr>
                                                        <td class="rowBackColor">Searchable Visitor reports</td>
                                                        <td></td>
                                                        <td style="text-align:center;"><img src="images/tik.png"></td>
                                                        <td style="text-align:center;"><img src="images/tik.png"></td>
                                                    </tr>
                                                    <tr>
                                                        <td class="rowBackColor">Active visitor dashboard</td>
                                                        <td style="text-align:center;"><img src="images/tik.png"></td>
                                                        <td style="text-align:center;"><img src="images/tik.png"></td>
                                                        <td style="text-align:center;"><img src="images/tik.png"></td>
                                                    </tr>
                                                    <tr>
                                                        <td class="rowBackColor">Visitor sign-out reminders</td>
                                                        <td></td>
                                                        <td style="text-align:center;"><img src="images/tik.png"></td>
                                                        <td style="text-align:center;"><img src="images/tik.png"></td>
                                                    </tr>
                                                    <tr>
                                                        <td class="rowBackColor">Multiple Sites and Devices</td>
                                                        <td></td>
                                                        <td style="text-align:center;"><img src="images/tik.png"></td>
                                                        <td style="text-align:center;"><img src="images/tik.png"></td>
                                                    </tr>
                                                    <tr>
                                                        <td class="rowBackColor">Support for additional languages</td>
                                                        <td></td>
                                                        <td style="text-align:center;"><img src="images/tik.png"></td>
                                                        <td style="text-align:center;"><img src="images/tik.png"></td>
                                                    </tr>
                                                    <tr>
                                                        <td class="rowBackColor">Legal Documents</td>
                                                        <td></td>
                                                        <td style="text-align:center;"><img src="images/tik.png"></td>
                                                        <td style="text-align:center;"><img src="images/tik.png"></td>
                                                    </tr>
                                                    <tr>
                                                        <td class="rowBackColor">Visitor Pictures</td>
                                                        <td></td>
                                                        <td style="text-align:center;"><img src="images/tik.png"></td>
                                                        <td style="text-align:center;"><img src="images/tik.png"></td>
                                                    </tr>
                                                    <tr>
                                                        <td class="rowBackColor">Custom logos and branding</td>
                                                        <td></td>
                                                        <td style="text-align:center;"><img src="images/tik.png"></td>
                                                        <td style="text-align:center;"><img src="images/tik.png"></td>
                                                    </tr> 
                                                    <tr>
                                                        <td class="rowBackColor">Custom cycling backgrounds</td>
                                                        <td></td>
                                                        <td style="text-align:center;"><img src="images/tik.png"></td>
                                                        <td style="text-align:center;"><img src="images/tik.png"></td>
                                                    </tr> 
                                                    <tr>
                                                        <td class="rowBackColor">Management Portal</td>
                                                        <td style="text-align:center;"><img src="images/tik.png"></td>
                                                        <td style="text-align:center;"><img src="images/tik.png"></td>
                                                        <td style="text-align:center;"><img src="images/tik.png"></td>
                                                    </tr>
                                                    <tr>
                                                        <th style="text-align:center; background-color:#a6a6a6;color:#ffffff;" colspan="4">Hardware Choices</th>
                                                    </tr>
                                                    <tr>
                                                        <td class="rowBackColor">iPad Support</td>
                                                        <td style="text-align:center;"><img src="images/tik.png"></td>
                                                        <td style="text-align:center;"><img src="images/tik.png"></td>
                                                        <td style="text-align:center;"><img src="images/tik.png"></td>
                                                    </tr>   <tr>
                                                        <td class="rowBackColor">Android Support</td>
                                                        <td></td>
                                                        <td style="text-align:center;"><img src="images/tik.png"></td>
                                                        <td style="text-align:center;"><img src="images/tik.png"></td>
                                                    </tr>
                                                    <tr>
                                                        <td class="rowBackColor">Custom Screen Size</td>
                                                        <td></td>
                                                        <td></td>
                                                        <td style="text-align:center;"><img src="images/tik.png"></td>
                                                    </tr>
                                                    <tr>
                                                        <td class="rowBackColor">Turn-key Solution (Device, Stand, Cellular Connection, Printer...)</td>
                                                        <td></td>
                                                        <td style="text-align:center;"><img src="images/tik.png"></td>
                                                        <td style="text-align:center;"><img src="images/tik.png"></td>
                                                    </tr>
                                                    <tr>
                                                        <th style="text-align:center; background-color:#a6a6a6;color:#ffffff;" colspan="4">Special Features</th>
                                                    </tr>
                                                    <tr>
                                                        <td class="rowBackColor">API access</td>
                                                        <td></td>
                                                        <td></td>
                                                        <td style="text-align:center;"><img src="images/tik.png"></td>
                                                    </tr>
                                                    <tr>
                                                        <td class="rowBackColor">Active Directory Integration</td>
                                                        <td></td>
                                                        <td></td>
                                                        <td style="text-align:center;"><img src="images/tik.png"></td>
                                                    </tr>
                                                    <tr>
                                                        <td class="rowBackColor">Access control integration</td>
                                                        <td></td>
                                                        <td></td>
                                                        <td style="text-align:center;"><img src="images/tik.png"></td>
                                                    </tr>
                                                    <tr>
                                                        <td class="rowBackColor">My Visitor door lock/unlock module</td>
                                                        <td></td>
                                                        <td></td>
                                                        <td style="text-align:center;"><img src="images/tik.png"></td>
                                                    </tr> 
                                                    <tr>
                                                        <td class="rowBackColor">Custom workflows</td>
                                                        <td></td>
                                                        <td></td>
                                                        <td style="text-align:center;"><img src="images/tik.png"></td>
                                                    </tr>  
                                                    <tr>
                                                        <td class="rowBackColor">Global notification system</td>
                                                        <td></td>
                                                        <td></td>
                                                        <td style="text-align:center;"><img src="images/tik.png"></td>
                                                    </tr> 
                                                    <tr>
                                                        <td class="rowBackColor">Split notifications (Assistant notifications)</td>
                                                        <td></td>
                                                        <td></td>
                                                        <td style="text-align:center;"><img src="images/tik.png"></td>
                                                    </tr> 
                                                    <tr>
                                                        <td class="rowBackColor">Assistance during auditing</td>
                                                        <td></td>
                                                        <td></td>
                                                        <td style="text-align:center;"><img src="images/tik.png"></td>
                                                    </tr>  
                                                    <tr>
                                                        <td class="rowBackColor">Cellular Connection</td>
                                                        <td></td>
                                                        <td></td>
                                                        <td style="text-align:center;"><img src="images/tik.png"></td>
                                                    </tr>
                    
                    
                    
                    
                    
                                                </tbody>
                                            </table>
                                        </div>-->
                </div>
            </section><!-- #content end -->
            <div style="" class="promo promo-dark promo-flat promo-full">
                <div class="container clearfix">
                    <h3>Learn how myVisitor can help you make your business safer and more efficient.</h3>
                    <a href="/register.php" class="button button-xlarge button-rounded">Get Started</a>
                </div>
            </div>
            <!-- Footer
            ============================================= -->
            <?php include('footer.php'); ?>

        </div><!-- #wrapper end -->

        <!-- Go To Top
        ============================================= -->
        <div id="gotoTop" class="icon-angle-up"></div>

        <!-- Footer Scripts
        ============================================= -->
        <script type="text/javascript" src="js/jquery.js"></script>
        <script type="text/javascript" src="js/plugins.js"></script>	
        <script type="text/javascript" src="js/functions.js"></script>

        <script type="text/javascript">
            $("#widget-subscribe-form").validate({
                submitHandler: function (form) {
                    $(form).find('.input-group-addon').find('.icon-email2').removeClass('icon-email2').addClass('icon-line-loader icon-spin');
                    $(form).ajaxSubmit({
                        target: '#widget-subscribe-form-result',
                        success: function () {
                            $(form).find('.input-group-addon').find('.icon-line-loader').removeClass('icon-line-loader icon-spin').addClass('icon-email2');
                            $('#widget-subscribe-form').find('.form-control').val('');
                            $('#widget-subscribe-form-result').attr('data-notify-msg', $('#widget-subscribe-form-result').html()).html('');
                            SEMICOLON.widget.notifications($('#widget-subscribe-form-result'));
                        }
                    });
                }
            });
        </script>
        <style>
            .rowBackColor{
                width:25%;
                background-color:#f2f2f2;
                text-align: right;
            }
            table th .thBorder{
                border: none !important;
            }
            .feature-box.fbox-center {
                padding: 0 10px;
            }
        </style>>

    </body>
</html>