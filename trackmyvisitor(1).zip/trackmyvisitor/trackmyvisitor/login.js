
var $ = jQuery.noConflict();

function validateEmail(email) {
    var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return re.test(email);
}

function onConfirmWhenLogin() {
    var Email = $("#login-form-email").val();
    var password = $("#login-form-password").val();
    var error = 0;
    if (Email == '') {
        $("#invalidEmail").html('Please enter your email address');
        $("#login-form-email").addClass('invalidval');
        error = 1;
    }
    else if (!validateEmail(Email)) {
        $("#invalidEmail").html('Please enter valid email address');
        $("#login-form-email").addClass('invalidval');
        error = 1;
    }
    else {
        $("#invalidEmail").html('');
        $("#login-form-email").removeClass('invalidval');
    }

    if (password == '') {
        $("#invalidpassword").html('Please enter your password');
        $("#login-form-password").addClass('invalidval');
        error = 1;
    }
    else {
        $("#invalidpassword").html('');
        $("#login-form-password").removeClass('invalidval');

    }
    if (error == 1) {
        return false;
    }
    else {
        $.ajax({
            "async": true,
            url: baseUrl + "employee-login",
            "method": "POST",
            "data": $('#login-form').serialize(),
            "headers": {
                "cache-control": "no-cache"
            },
            success: function (response)
            {
                if (response['error'] == false) {

                    APIKEY = response['apikey'];
                    FULLNAME = response['FullName'];
                    EMAILADDRESS = response['EmailAddress'];
                    COMPANYNAME = response['CompanyName'];
                    COMPANYID = response['CompanyId'];
                    ISCOMPANYADMIN = response['IsCompanyAdmin'];
                    EMPLOYEEID = response['Id'];
                    TimeZoneName = response['TimeZoneName'];
                    LangCode = response['LangCode'];

                    // alert(LangCode);

//                    sessionStorage.APIKEY = APIKEY;
//                    sessionStorage.FULLNAME = FULLNAME;
//                    sessionStorage.EMAILADDRESS = EMAILADDRESS;
//                    sessionStorage.COMPANYNAME = COMPANYNAME;
//                    sessionStorage.COMPANYID = COMPANYID;
//                    sessionStorage.ISCOMPANYADMIN = ISCOMPANYADMIN;
                    localStorage.setItem('APIKEY', APIKEY);
                    localStorage.setItem('FULLNAME', FULLNAME);
                    localStorage.setItem('EMAILADDRESS', EMAILADDRESS);
                    localStorage.setItem('COMPANYNAME', COMPANYNAME);
                    localStorage.setItem('COMPANYID', COMPANYID);
                    localStorage.setItem('ISCOMPANYADMIN', ISCOMPANYADMIN);
                    localStorage.setItem('EMPLOYEEID', EMPLOYEEID);
                    localStorage.setItem('TimeZoneName', TimeZoneName);
                    localStorage.setItem('LangCode', LangCode);
                    window.location = "dashboard.php";
                }
                else {
                    $("#invalidLogin").html(response['message']);
                }
            }
        });
    }
}

$(function () {
    $('#login-form').submit(function () {
        onConfirmWhenLogin();
        return false;
    });

});
