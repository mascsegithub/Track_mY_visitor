var fileNames;
var tmpFileNameAttached;
var lastEmployeeId = 0;
function validateEmail(email) {
    var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return re.test(email);
}
function resetForm(id) {
    $('#' + id).each(function () {
        this.reset();
    });
}
function resetAllForm() {
    $('#stock-input').fileinput('clear');
}
function loadSiteDropdown() {
    $.ajax({
        "async": true,
        url: baseUrl + "site-combo-load/" + COMPANYID,
        "method": "GET",
        "headers": {
            "Apikey": APIKEY,
            "cache-control": "no-cache"
        },
        success: function (response)
        {
            response = response['siteList'];
            $.each(response, function (key, value) {
                $('#siteIdLoad').append($('<option></option>').val(value.siteId).html(value.siteName));
            });
        }

    });
}
function loadDivisionDropdown(siId) {
    $.ajax({
        "async": true,
        url: baseUrl + "division-combo-load/" + COMPANYID,
        "method": "GET",
        "data": '&siId=' + siId,
        "headers": {
            "Apikey": APIKEY,
            "cache-control": "no-cache"
        },
        success: function (response)
        {
            response = response['divisionList'];
            var count = response.length;
            if (count > 0) {
                $.each(response, function (key, value) {
                    $('#divisionIdLoad').append($('<option></option>').val(value.DivisionId).html(value.DivisionName));
                });
            }
            else {
                $('#divisionIdLoad').val('');
            }

        }

    });

}
function onConfirmWhenEmployeeAdd() {


    var error = 0;
    var Email = $("#EmailAddress").val();
    var firstName = $("#firstName").val();
    var lastName = $("#lastName").val();
    var jobTitle = $("#jobTitle").val();
    var divisionId = $("#divisionId").val();
    if (Email == '') {
        $("#invalidEmail").html('Please enter your email address');
        $("#login-form-email").addClass('invalidval');
        error = 1;
    }
    else if (!validateEmail(Email)) {
        $("#invalidEmail").html('Please enter valid email address');
        $("#EmailAddress").addClass('invalidval');
        //$("#AllHostSH").hide();
        //$("#AddNewEmployeeInfo").show();
        error = 1;
    }
    else {
        $("#invalidEmail").html('');
        $("#EmailAddress").removeClass('invalidval');
    }

    if (firstName == '') {
        $("#firstNameVal").html('Please enter your first name');
        $("#firstName").addClass('invalidval');
        error = 1;
    }
    else {
        $("#firstNameVal").html('');
        $("#firstName").removeClass('invalidval');
    }
    if (lastName == '') {
        $("#lastNameVal").html('Please enter your last name');
        $("#lastName").addClass('invalidval');
        error = 1;
    }
    else {
        $("#lastNameVal").html('');
        $("#lastName").removeClass('invalidval');
    }
    if (jobTitle == '') {
        $("#jobTitleVal").html('Please enter your job title');
        $("#jobTitle").addClass('invalidval');
        error = 1;
    }
    else {
        $("#jobTitleVal").html('');
        $("#jobTitle").removeClass('invalidval');
    }
    if (divisionId == '' || divisionId == 'N/A') {
        $("#divisionIdVal").html('Please enter your division name');
        $("#divisionIdLoad").addClass('invalidval');
        error = 1;
    }
    else {
        $("#divisionIdVal").html('');
        $("#divisionIdLoad").removeClass('invalidval');
    }
    if (error == 1) {
        return false;
    }
    else {
        $.ajax({
            "async": true,
            url: baseUrl + "host-create",
            "method": "POST",
            "data": $('#employee_add_form').serialize() + '&CompanyId=' + COMPANYID,
            "headers": {
                "Apikey": APIKEY,
                "cache-control": "no-cache"
            },
            success: function (response)
            {
                //console.log(response);
                //return false;
                $("#AllHostSH").hide();
                $("#AddNewEmployeeInfo").show();
                if (response['error'] == false) {
                    $(".dImage").show();
                    lastEmployeeId = response['EmployeeId'];
                    $("#MessageShow").html(response['message']);
                    $('#myModalMsg').modal('show');
                    //return false;
                }
                else {
                    $("#MessageShow").html(response['message']);
                    $('#myModalMsg').modal('show');
                    //return false;
                }

            }
        });
    }
}

function onConfirmWhenEmployeeEdit(response) {

    response = response['employeeEdit'];
    lastEmployeeId = response[0]['Id']
    var RecordId = response[0]['Id']
    var FirstName = response[0]['FirstName'];
    var LastName = response[0]['LastName'];
    var EmailAddress = response[0]['EmailAddress'];
    var CompanyId = response[0]['CompanyId'];
    var EmployeeImage = response[0]['EmployeeImage'];
    var JobTitle = response[0]['JobTitle'];
    var MobileNo = response[0]['MobileNo'];
    var DeskPhoneNo = response[0]['DeskPhoneNo'];
    var IsHost = response[0]['IsHost'];
    var SendEmail = response[0]['SendEmail'];

    var SiteId = response[0]['SiteId'];
    loadDivisionDropdown(SiteId);
    var DivisionId = response[0]['DivisionId'];



//alert(DivisionId);
    $("#AddNewEmployeeInfo").show();
    $("#AllHostSH").hide();
    $("#firstName").val(FirstName);
    $("#lastName").val(LastName);
    $("#EmailAddress").val(EmailAddress);
    $("#jobTitle").val(JobTitle);
    $("#mobileNo").val(MobileNo);
    $("#deskPhoneNo").val(DeskPhoneNo);
    $("#RecordId").val(RecordId);

    $("#siteIdLoad").val(SiteId);
    $("#divisionIdLoad").val(DivisionId);

    if (IsHost == 1) {
        document.getElementById("IsHost").checked = true;
    } else {
        document.getElementById("IsHost").checked = false;
    }
    if (SendEmail == 1) {
        document.getElementById("SendEmail").checked = true;
    } else {
        document.getElementById("SendEmail").checked = false;
    }

    $(".dImage").hide();
    $('.OriginalImage').show();
    //$('.OriginalImage').html('<img src="images/employees/thumbs/' + EmployeeImage + '" alt="UploadImage">');
    if (EmployeeImage != '') {
        $('.OriginalImage').html('<img src="images/employees/thumbs/' + EmployeeImage + '" alt="UploadImage">');
    } else {
        $('.OriginalImage').html('<img src="images/em.jpg" alt="UploadImage height="140" width="125" ">');
    }

}
function employeeEdit(EmployeeId) {
//alert(EmployeeId);
    $.ajax({
        "async": true,
        url: baseUrl + "host-list-edit/" + EmployeeId,
        "method": "GET",
        "headers": {
            "Apikey": APIKEY,
            "cache-control": "no-cache"
        },
        success: function (response)
        {
            onConfirmWhenEmployeeEdit(response);
        }
    });
}
function employeeDelete(EmpId) {
    if (!confirm("Do you really want to delete this record?")) {
        return false;
    } else {
        $.ajax({
            "async": true,
            url: baseUrl + "employee-delete/" + EmpId,
            "method": "GET",
            "headers": {
                "Apikey": APIKEY,
                "cache-control": "no-cache"
            },
            success: function (response)
            {
                if (response['error'] == false) {
                    var msg = "Employee  info. has been deleted successfully";
                    $("#MessageShow").html(msg);
                    $('#myModalMsg').modal('show');
                    getEmployeeHistoryData();
                } else {
                    var msg = "Sorry, Employee  info. name has not been deleted";
                    $("#MessageShow").html(msg);
                    $('#myModalMsg').modal('show');
                }
            }
        });
    }
}
function removeErrorline() {
    
    $("#EmailAddress").removeClass('invalidval');
    $("#invalidEmail").html('');
    
    $("#EmployeeAddMessage").html('');
    $("#firstNameVal").html('');
    $("#firstName").removeClass('invalidval');
    $("#lastNameVal").html('');
    $("#lastName").removeClass('invalidval');
    $("#jobTitleVal").html('');
    $("#jobTitle").removeClass('invalidval');
    
    $("#divisionIdVal").html('');
    $("#divisionId").removeClass('invalidval');
}
function aKey() {
    var checkboxstate = document.getElementById('Activation').checked;

    $('#Activation').val(checkboxstate);
}
function hKey() {
    var checkboxstate = document.getElementById('IsHost').checked;
    $('#IsHost').val(checkboxstate);
}
function mKey() {

    var checkboxstate = document.getElementById('SendEmail').checked;
    //alert(checkboxstate);
    $('#SendEmail').val(checkboxstate);
}

function onListPanel() {
    $('#AllHostSH').show();
    $('#AddNewEmployeeInfo').hide();
    getEmployeeHistoryData();
    $(".dImage").hide();
    $('.OriginalImage').hide();
    removeErrorline();
}

/*---------------------- Ready function--------------------------*/
$(function () {

    loadSiteDropdown();
    getEmployeeHistoryData();
    $('#employee_add_form').submit(function () {
        //onConfirmWhenEmployeeAdd();
        return false;
    });

    $("#siteIdLoad").change(function () {
        var siId = $("#siteIdLoad").val();
        loadDivisionDropdown(siId);

    });
    var checkboxstate = document.getElementById('Activation').checked;
    $('#Activation').val(checkboxstate);
    $(".dImage").hide();
    resetForm("employee_add_form");
    $("#AddNewEmployee").click(function () {

        $("#AllHostSH").hide();
        $("#AddNewEmployeeInfo").show();
        $("#firstName").val('');
        $("#lastName").val('');
        $("#EmailAddress").val('');
        $("#jobTitle").val('');
        $("#mobileNo").val('');
        $("#deskPhoneNo").val('');
        $("#RecordId").val('');
        $("#divisionIdLoad").val('');
        //$('#divisionIdLoad').val('');
        //$('#siteIdLoad').val('');

        //document.getElementById("IsHost").checked = false;
        document.getElementById("SendEmail").checked = false;
        $('.OriginalImage').hide()
        $(".dImage").hide();
    });
    $(".OriginalImage").click(function () {
        resetAllForm();
    });
    $(".dImage").click(function () {
        resetAllForm();
    });
    $("#AllHost").click(function () {
        removeErrorline();
        resetForm("employee_add_form");
        getEmployeeHistoryData();
        $("#AllHostSH").show();
        $("#divisionIdLoad").val('');
        $("#AddNewEmployeeInfo").hide();
        $(".dImage").hide();
        $('.OriginalImage').hide();
    });
    $("#datetimepicker1").datepicker();
    $("#datetimepicker2").datepicker();

});
function getEmployeeHistoryDataInfo(response) {
    //$("#AllHostSH").show();
    response = response['employee'];
    var trHTML = '';
    var EmployeeId = '';
    var EmployeePhotoPath = '';
    var EmployeeName = '';
    var Division = '';
    var EmailAddress = '';
    var CompanyName = '';
    trHTML += '<div id="list-panel"><h3>Hosts List</h3><table  id="AllHostInfo" class="table table-striped table-bordered display table-hover" cellspacing="0"><thead><tr><th style="text-align: left;">Host Photo</th><th style="text-align: left;">Host Name</th><th style="text-align: left;">Email</th><th style="text-align: left;">  </th></tr></thead><tbody>';
    $.each(response, function (key, value) {
        EmployeePhotoPath = value.EmployeeImage;
//        if (EmployeePhotoPath == ' ') {
//            alert(123);
//        }
        EmployeeId = value.EmployeeId;
        EmployeeName = value.EmployeeName;
        Division = value.Division;
        EmailAddress = value.EmailAddress;
        CompanyName = value.CompanyName;
        var Image = '<img src="images/em.jpg" alt="UploadImage height="140" width="125" ">';
        trHTML +=
                '<tr><a href="#"><td><img src =' + EmployeePhotoPath + '  alt="" height="40" width="40"><b>' +
                '</td><td>' + EmployeeName + '</br>' + Division +
                '</td><td>' + EmailAddress +
                '</td><td style="text-align: center;width:15%;"> <input type="submit"  value="Edit" class="btn btn-primary btn-sm" onClick="employeeEdit(' + EmployeeId + ')">' + '    ' + '<input type="submit" value="Delete" class="btn btn-danger btn-sm" onClick="employeeDelete(' + EmployeeId + ')">' +
                '</td></a></tr>';
    });
    trHTML += '</tbody></table></div>';
    $('#AllHostSH').html(trHTML); //append
}
function getEmployeeHistoryData() {
    $.ajax({
        "async": true,
        url: baseUrl + "employee-by-id/" + COMPANYID,
        "method": "GET",
        "headers": {
            "Apikey": APIKEY,
            "cache-control": "no-cache"
        },
        success: function (response)
        {
            getEmployeeHistoryDataInfo(response);
        }
    });
}
function  updateHostImage(EmployeeImage) {

    $.ajax({
        "async": true,
        url: baseUrl + "host-image-add-web/" + lastEmployeeId,
        "method": "POST",
        "data": '&EmployeeImage=' + EmployeeImage,
        "headers": {
            "Apikey": APIKEY,
            "cache-control": "no-cache"
        },
        success: function (response)
        {
            $("#AllHostSH").hide();
            $("#AddNewEmployeeInfo").show();
            if (response['error'] == false) {
                $(".dImage").hide();
                //alert('ok');
            }
            else {

            }

        }
    });
}
$("#stock-input").fileinput({
    //uploadUrl: '/trackmyvisitor/logoUploadProcess.php', //ok
    uploadUrl: ImageUrl + '/uploadProcess.php',
    maxFileCount: 1,
    maxFileSize: 5120,
    previewFileIcon: '<i class="fa fa-file"></i>',
    previewFileType: false,
    wrapTextLength: 30,
    allowedFileExtensions: ['jpg', 'png'],
    allowedPreviewTypes: null,
    uploadExtraData: {
        "company": "softworks"
    },
    previewFileIconSettings: {
        'jpg': '<i class="fa fa-file-photo-o text-warning"></i>',
        'png': '<i class="fa fa-file-photo-o text-danger"></i>'
    }
});
$('#stock-input').on('filebrowse', function (event) {
    $('#stock-input').fileinput('reset');
});
$('#stock-input').on('fileloaded', function (event, file, previewId, index) {
    console.log("fileloaded");
});
//resetAllForm();
$('#stock-input').on('fileuploaded', function (event, data, previewId, index) {
    var formdata = data.form, files = data.files, extradata = data.extra, responsedata = data.response;
    fuResponse = responsedata;
    $('.OriginalImage').html('<img src="images/employees/thumbs/' + fuResponse.FileName + '" alt="UploadImage">');
    $('.dImage').hide();
    $('.OriginalImage').show();
    $('#myModal').modal('hide');
    $('#AddNewEmployeeInfo').hide();
    //$('#AllHostSH').show();
    updateHostImage(fuResponse.FileName);
    fileNames += fuResponse.FileName + "|";
    var fileNamesString = $("#ImageName").val();
    tmpFileNameAttached += fuResponse.FileName + "|";
    if (fileNamesString != '') {
        $("#ImageName").val(fileNamesString + '|' + fuResponse.FileName);
    }
    else {
        $("#ImageName").val(fuResponse.FileName);
    }
});
$('#stock-input').on('fileuploaderror', function (event, data, previewId, index) {
    var formdata = data.form, files = data.files, extradata = data.extra, responsedata = data.response;
    console.log('File upload error');
});
$('#stock-input').on('filecleared', function (event) {
    var fileNamesString = $("#ImageName").val();
    if (typeof tmpFileNameAttached != 'undefined') {
        var tmpfiles = tmpFileNameAttached.split('undefined').join('');
        tmpfiles = tmpfiles.substring(0, tmpfiles.length - 1);
        var fileNames = fileNamesString.split('|' + tmpfiles).join('');
    }
    $("#ImageName").val(fileNames);
    tmpFileNameAttached = '';
});

