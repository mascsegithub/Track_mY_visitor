<?php 
	session_start();
	$CompanyId = $_SESSION['CompanyId'];	
	$apikey = $_SESSION['apikey'];	
	$IsCompanyAdmin = $_SESSION['IsCompanyAdmin'];	
    $LangCode = $_SESSION['LangCode'];	

	$sQuery = " SELECT t_language_text.LangCode,LangTextName, LangText,`t_company`.`CompanyImage` FROM t_language_text
	INNER JOIN t_company ON t_language_text.CompanyId = t_company.CompanyId AND t_language_text.LangCode =t_company.`LangCode`
	WHERE t_company.CompanyId=$CompanyId;";

	$rResult = mysql_query($sQuery);
	$LangText = array();
	
	while ($row = mysql_fetch_assoc($rResult)) {
			$LangText[$row['LangTextName']] = $row['LangText'];
                        $CompannyLogo = $row['CompanyImage'];
	}
	
	if($CompannyLogo){
		 $CompannyLogo = $CompannyLogo;
	}else{
		$CompannyLogo = 'd_logo.jpg';
	}