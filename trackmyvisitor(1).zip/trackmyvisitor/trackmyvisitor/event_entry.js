function resetForm(id) {
    $('#' + id).each(function () {
        this.reset();
    });
}
function onConfirmWhenEventAdd() {
    //console.log(COMPANYID);
    var error = 0;
    var EventName = $("#EventName").val();
    var EventDate = $("#EventDate").val();
    if (EventName == '') {
        $("#EventNameVal").html('Please enter event name');
        $("#EventName").addClass('invalidval');
        error = 1;
    }
    else {
        $("#EventNameVal").html('');
        $("#EventName").removeClass('invalidval');
    }
    if (EventDate == '') {
        $("#EventDateVal").html('Please enter event date');
        $("#EventDate").addClass('invalidval');
        error = 1;
    }
    else {
        $("#EventDateVal").html('');
        $("#EventDate").removeClass('invalidval');
    }
    if (error == 1) {
        return false;
    }
    else {
        $.ajax({
            "async": true,
            url: baseUrl + "event-create",
            "method": "POST",
            "data": $('#event_add_form').serialize() + '&CompanyId=' + COMPANYID,
            "headers": {
                "Apikey": APIKEY,
                "cache-control": "no-cache"
            },
            success: function (response)
            {
                //console.log(response);
                //return false;
                $("#AllEventTable").hide();
                $("#AddNewEvent").show();
                if (response['error'] == false) {
                    $("#MessageShow").html(response['message']);
                    $('#myModal').modal('show');
                    //return false;
                }
                else {
                    $("#MessageShow").html(response['message']);
                    $('#myModal').modal('show');
                }

            }
        });
    }
}

function onConfirmWhenEventTypeEdit(response) {

    response = response['EventEdit'];
    //lastEmployeeId = response[0]['Id']
    var RecordId = response[0]['EventId']
    var EventName = response[0]['EventName'];
    var EventDate = response[0]['EventDate'];

    $("#EventEntry").show();
    $("#AllEventTable").hide();
    $("#EventName").val(EventName);
    $("#EventDate").val(EventDate);
    $("#RecordId").val(RecordId);

}
function eventEdit(EventId) {
//alert(EmployeeId);
    $.ajax({
        "async": true,
        url: baseUrl + "event-list-edit/" + EventId,
        "method": "GET",
        "headers": {
            "Apikey": APIKEY,
            "cache-control": "no-cache"
        },
        success: function (response)
        {
            onConfirmWhenEventTypeEdit(response);
        }
    });
}
function eventDelete(EventId) {
    if (!confirm("Do you really want to delete this record?")) {
        return false;
    } else {
        $.ajax({
            "async": true,
            url: baseUrl + "event-delete/" + EventId,
            "method": "GET",
            "headers": {
                "Apikey": APIKEY,
                "cache-control": "no-cache"
            },
            success: function (response)
            {
                if (response['error'] == false) {
                    var msg = "Event has been deleted successfully";
                    $("#MessageShow").html(msg);
                    $('#myModal').modal('show');
                    getEvnetList();
                } else {
                    var msg = "Sorry, Event has not been deleted";
                    $("#MessageShow").html(msg);
                    $('#myModal').modal('show');
                }
            }
        });
    }
}
function removeErrorline() {
    $("#EventNameVal").html('');
    $("#EventName").removeClass('invalidval');

    $("#EventDateVal").html('');
    $("#EventDate").removeClass('invalidval');
}
function onListPanel() {
    $('#AllEventTable').show();
    $('#EventEntry').hide();
    getEvnetList();
}
/*---------------------- Ready function--------------------------*/
$(function () {

    getEvnetList();

    $('#event_add_form').submit(function () {
        //onConfirmWhenEventAdd();
        return false;
    });

    resetForm("event_add_form");
    $("#AddNewEvent").click(function () {
        removeErrorline();
        $("#AllEventTable").hide();
        $("#EventEntry").show();
        $("#EventName").val('');
        $("#EventDate").val('');
        $("#RecordId").val('');
    });
    $("#AllEvent").click(function () {
        removeErrorline();
        resetForm("event_add_form");
        getEvnetList();
        $("#AllEventTable").show();
        $("#EventEntry").hide();
    });
});
function getEvnetListData(response) {
    response = response['event'];
    var trHTML = '';
    var EventId = '';
    var EventName = '';
    var CompanyName = '';
    var EventDate = '';
    trHTML += '<div id="list-panel"><h3>Event List</h3><table  id="" class="table table-striped table-bordered display table-hover" cellspacing="0"><thead><tr><th style="text-align: left;">Event Name</th><th style="text-align: left;">Event Date</th><th style="text-align:center;">Action</th></tr></thead><tbody>';
    $.each(response, function (key, value) {
        EventId = value.EventId;
        EventName = value.EventName;
        EventDate = value.EventDate;
        trHTML +=
                '<tr><td>' + EventName +
                '</td><td>' + EventDate +
                '</td><td style="text-align: center;width:20%;"> <input type="submit"  value="Edit" class="btn btn-primary btn-sm" onClick="eventEdit(' + EventId + ')">' + '    ' + '<input type="submit" value="Delete" class="btn btn-danger btn-sm" onClick="eventDelete(' + EventId + ')">' +
                '</td></a></tr>';
    });
    trHTML += '</tbody></table></div>';
    $('#AllEventTable').html(trHTML); //append
}
function getEvnetList() {
    $.ajax({
        "async": true,
        url: baseUrl + "get-event/" + COMPANYID,
        "method": "GET",
        "headers": {
            "Apikey": APIKEY,
            "cache-control": "no-cache"
        },
        success: function (response)
        {
            getEvnetListData(response);
        }
    });
}


