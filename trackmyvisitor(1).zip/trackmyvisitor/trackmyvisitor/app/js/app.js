var myApp = angular.module("myVisitor",[]);

myApp.controller('visitorController', function($scope, $http, $timeout){

	//console.log = function() {}

	console.log('i am visitorController');

	$scope.showPreviousStyle = {visibility: 'hidden'};
	$scope.showNextStyle = {visibility: 'visible'};

	$scope.app_base_url = app_base_url;

	$scope.qrText = '';

	$scope.audio = new Audio('../sound/camera-shutter-click.mp3');

	$scope.curDate = new Date();

	// divIndex
	$scope.index = 0;

	$scope.ROUTE1_INDEXS = [1, 2, 3, 4, 5, 6, 7, 8];
	$scope.ROUTE2_INDEXS = [1, 2, 11, 4, 5, 7, 8, 0];
	$scope.ROUTE3_INDEXS = [1, 2, 9, 10, 0, 0, 0, 0];
    
    $scope.ROUTE1 = 1;
    $scope.ROUTE2 = 2;
    $scope.ROUTE3 = 3;

    $scope.route = $scope.ROUTE1;


	$scope.ROUTE_INDEXS = [];

	$scope.MIN_INDEX = 0;
	$scope.MAX_INDEX = 7;


	$scope.visitorNameValid = false;
	$scope.visitorCompanyValid = false;

	

	$scope.pageIndexs = {
		PAGE1: 1,
		PAGE2: 2,
		PAGE3: 3,
		PAGE4: 4,
		PAGE5: 5,
		PAGE6: 6,
		PAGE7: 7,
		PAGE8: 8,
		PAGE9: 9,
		PAGE10: 10,
		PAGE11: 11};

		$scope.showHomePage = true;
		$scope.showVisitorType = false;
		$scope.showVisitorInfo = false;
		$scope.showCameraInput = false;
		$scope.showImageView = false;
		$scope.showHostList = false;
		$scope.showSelectedInfo = false;
		$scope.showConnectingHost = false;
		$scope.showNonSignoutVisitor = false;
		$scope.showSignedOut = false;
		$scope.showAuthVisitor = false;



		$scope.VisitorTypeId = 0;
		$scope.visitorType = '';	

		$scope.myTexts = {
			MY_VISITOR: myVisitor,
			HOW_MAY_I_HELP_YOU: howMayIHelpYou,
			TELL_ABOUT_YOURSELF: tellAboutYourself,
			TAKE_A_PICTURE: takeAPicture,
			YOUR_SELECTED_PICTURE: itYourSelectedPicture,
			WHO_ARE_YOU_VISITING: whoAreYouVisiting,
			IS_EVERYTHING_CORRECT: isEverythingCorrect,
			POSTING_YOUR_INFORMATION: postinfInformation,
			SIGNING_OUT: signingOut,
			SCAN_YOUR_QR_CODE: scanYourQrCode
		};

		$scope.pageTitle = $scope.myTexts.MY_VISITOR;	
		
		$scope.hostList = [];
		$scope.nonSignOutVisitorList = [];

		$scope.switchNavRoute = function(){			
			if($scope.ROUTE1 == $scope.route){
				$scope.ROUTE_INDEXS = $scope.ROUTE1_INDEXS;
				$scope.MIN_INDEX = 0;
				$scope.MAX_INDEX = 7;							
			}
			else if($scope.ROUTE2 == $scope.route){
				$scope.ROUTE_INDEXS = $scope.ROUTE2_INDEXS;
				$scope.MIN_INDEX = 0;
				$scope.MAX_INDEX = 7;							
			}
			else if($scope.ROUTE3 == $scope.route){
				$scope.ROUTE_INDEXS = $scope.ROUTE3_INDEXS
				$scope.MIN_INDEX = 0;								
			}
		}

		$scope.route = $scope.ROUTE1;
		$scope.switchNavRoute($scope.route);


		$scope.changeVistorType = function(visitorTypeId, visitorType){
			console.log('i am changeVistorType');
			$scope.VisitorTypeId = visitorTypeId;		
			$scope.visitorType = visitorType;
			param_visitor_type_id = $scope.VisitorTypeId;
		};

		$scope.showPrevious = function(){
			console.log('i am showPrevious');
			console.log('page index: ' + $scope.index);	

			if($scope.index == $scope.MIN_INDEX){			
				return;
			}	
			
			//console.log(this);

			 if($scope.showImageView){				
			 	$scope.index--;			
			 	$scope.index--;			
			 }else{
				$scope.index--;				
			}

			// when go back from qrcode scan screen and non signout visitor screnn, you must reset the path
			if(($scope.showAuthVisitor || $scope.showNonSignoutVisitor) && $scope.route != $scope.ROUTE1){				
				$scope.route = $scope.ROUTE1;
				$scope.switchNavRoute($scope.route);
			}
			
			
			$scope.showHide();
			$scope.getMyText();			
		};

		// for take picture again
		$scope.showPreviousRetake = function(){
			console.log('i am showPrevious');
			console.log('page index: ' + $scope.index);	

			if($scope.index == $scope.MIN_INDEX){			
				return;
			}	
						
			$scope.index--;				
						
			$scope.showHide();
			$scope.getMyText();
		};

		$scope.showNext = function(){
			console.log('i am showNext');
			console.log('page index: ' + $scope.index);	

			if(!$scope.visitorNameValid && $scope.showVisitorInfo){
				alert(fillVisitorName);				
				return;
			} else if ($scope.visitorNameValid){
				param_visitor_name = visitorForm.nvisitorName.value;				
			}
		
			if(!$scope.visitorCompanyValid && $scope.showVisitorInfo){
				alert(fillVisitorCompany);				
				return;
			} else if ($scope.visitorCompanyValid){
				param_visitor_company = visitorForm.nvisitorCompany.value;
			}

			if($scope.index == $scope.MAX_INDEX){					
				return;
			}	

			$scope.index++;	
			
			
			$scope.showHide();
			$scope.getMyText();		

		};

		$scope.showHide = function(){	

			$scope.setVisiblePage($scope.index);

			$scope.showHideNavButton();

			if($scope.showCameraInput){	

				if($scope.route == $scope.ROUTE2){
					$scope.setValueForRoute2();
				}

				Webcam.attach( '#camera-input' );

				$timeout(function () {										
					take_snapshot();	
					$scope.playAudio();	
					$scope.showNext();	
				}, 3000);

			}

			if($scope.showConnectingHost){	
				// alert($scope.VisitorTypeId);
				// return;

				upload_image();
			}
		}


		$scope.showHideNavButton = function(){

			if($scope.showHomePage){

				$scope.showPreviousStyle = {visibility: 'hidden'};	
				$scope.showNextStyle = {visibility: 'visible'};	

			} else if ($scope.showNonSignoutVisitor){

				$scope.showPreviousStyle = {visibility: 'visible'};
				$scope.showNextStyle = {visibility: 'hidden'};

			} else if ($scope.showAuthVisitor){

				$scope.showPreviousStyle = {visibility: 'visible'};
				$scope.showNextStyle = {visibility: 'hidden'};

			} else if ($scope.showSelectedInfo){

				$scope.showPreviousStyle = {visibility: 'visible'};
				$scope.showNextStyle = {visibility: 'hidden'};

			} else if ($scope.showConnectingHost){

				$scope.showPreviousStyle = {visibility: 'hidden'};
				$scope.showNextStyle = {visibility: 'hidden'};

			} else {

				$scope.showPreviousStyle = {visibility: 'visible'};
				$scope.showNextStyle = {visibility: 'visible'};

			}
		}

		$scope.setValueForRoute2 = function () {

			var regex_patrn = /: (.*?)\n/g;

			$scope.authVisitor = {};

			result = regex_patrn.exec($scope.qrText);
			$scope.authVisitor.Visitor_ID = result[1];

			result = regex_patrn.exec($scope.qrText);
			$scope.authVisitor.Visitor_Name = result[1];

			// setting param
			visitorForm.nvisitorName.value = $scope.authVisitor.Visitor_Name;
			$scope.visitorName = visitorForm.nvisitorName.value;
			param_visitor_name = $scope.visitorName;

			result = regex_patrn.exec($scope.qrText);
			$scope.authVisitor.Visitor_Company = result[1];

			// setting param
			visitorForm.nvisitorCompany.value = $scope.authVisitor.Visitor_Company;
			$scope.visitorCompany = visitorForm.nvisitorCompany.value;
			param_visitor_company = $scope.visitorCompany;

			result = regex_patrn.exec($scope.qrText);
			$scope.authVisitor.Visitor_Type_ID = result[1];

			// setting param Vistitor Type Id
			$scope.VisitorTypeId = $scope.authVisitor.Visitor_Type_ID;
			param_visitor_type_id = $scope.VisitorTypeId

  
			result = regex_patrn.exec($scope.qrText);
			$scope.authVisitor.Visitor_Type = result[1];

			// setting param Vistitor Type Id
			$scope.VisitorType = $scope.authVisitor.Visitor_Type;
			
			result = regex_patrn.exec($scope.qrText);
			$scope.authVisitor.Email = result[1];

			result = regex_patrn.exec($scope.qrText);
			$scope.authVisitor.Phone = result[1];

			result = regex_patrn.exec($scope.qrText);
			$scope.authVisitor.Event_ID = result[1];

			result = regex_patrn.exec($scope.qrText);
			$scope.authVisitor.Event_Name = result[1];

			result = regex_patrn.exec($scope.qrText);
			$scope.authVisitor.Host_ID = result[1];
			
			// setting param Employee/Host Id
			$scope.selHost.id = $scope.authVisitor.Host_ID;
			param_employee_id = $scope.selHost.id;

			result = regex_patrn.exec($scope.qrText);
			$scope.authVisitor.Host_Name = result[1];

			$scope.selHost.full_name = $scope.authVisitor.Host_Name;

			result = regex_patrn.exec($scope.qrText);
			$scope.authVisitor.Company = result[1];

			// result = regex_patrn.exec($scope.qrText);
			// $scope.authVisitor.Appointment_Date = result[1];


			//console.log($scope.authVisitor);
		}

		$scope.setVisiblePage = function(idx){
			$scope.showHomePage = $scope.ROUTE_INDEXS[idx] == $scope.pageIndexs.PAGE1;
			$scope.showVisitorType = $scope.ROUTE_INDEXS[idx] == $scope.pageIndexs.PAGE2;
			$scope.showVisitorInfo = $scope.ROUTE_INDEXS[idx] == $scope.pageIndexs.PAGE3;
			$scope.showCameraInput = $scope.ROUTE_INDEXS[idx] == $scope.pageIndexs.PAGE4;
			$scope.showImageView = $scope.ROUTE_INDEXS[idx] == $scope.pageIndexs.PAGE5;
			$scope.showHostList = $scope.ROUTE_INDEXS[idx] == $scope.pageIndexs.PAGE6;
			$scope.showSelectedInfo = $scope.ROUTE_INDEXS[idx] == $scope.pageIndexs.PAGE7;
			$scope.showConnectingHost = $scope.ROUTE_INDEXS[idx] == $scope.pageIndexs.PAGE8;
			$scope.showNonSignoutVisitor = $scope.ROUTE_INDEXS[idx] == $scope.pageIndexs.PAGE9;
			$scope.showSignedOut = $scope.ROUTE_INDEXS[idx] == $scope.pageIndexs.PAGE10;
			$scope.showAuthVisitor = $scope.ROUTE_INDEXS[idx] == $scope.pageIndexs.PAGE11;

		}

		$scope.getMyText = function(){

			if($scope.showHomePage){	
				$scope.pageTitle = $scope.myTexts.MY_VISITOR;
			}else if ($scope.showVisitorType){
				$scope.pageTitle = $scope.myTexts.HOW_MAY_I_HELP_YOU;
			}else if ($scope.showVisitorInfo){
				$scope.pageTitle = $scope.myTexts.TELL_ABOUT_YOURSELF;
			}else if ($scope.showCameraInput){
				$scope.pageTitle = $scope.myTexts.TAKE_A_PICTURE;
			}else if ($scope.showImageView){
				$scope.pageTitle = $scope.pageTitle = $scope.myTexts.YOUR_SELECTED_PICTURE;
			}else if ($scope.showHostList){
				$scope.pageTitle = $scope.myTexts.WHO_ARE_YOU_VISITING;
			}else if ($scope.showSelectedInfo){
				$scope.pageTitle = $scope.myTexts.IS_EVERYTHING_CORRECT;
			}else if ($scope.showConnectingHost){
				$scope.pageTitle = $scope.myTexts.POSTING_YOUR_INFORMATION;
			}else if ($scope.showNonSignoutVisitor){
				$scope.pageTitle = $scope.myTexts.SIGNING_OUT;
			}else if ($scope.showSignedOut){
				$scope.pageTitle = '';
			}else if ($scope.showAuthVisitor){
				$scope.pageTitle = $scope.myTexts.SCAN_YOUR_QR_CODE;
			}
		};	

		$scope.selHost = {};
		
		$scope.setHostValue = function(host) {
			$scope.selHost.id = host.Id;
			$scope.selHost.full_name = host.FullName;	
			param_employee_id = $scope.selHost.id;	
			$scope.showNext();
		}

		$scope.setNVisitorValue = function(nv) {			
			param_nvisitor_id = nv.VisitorId;	
			$scope.signOut();
			//$scope.showNonSignoutVisitor = false;
			//$scope.showSignedOut = true;
			$scope.getMyText();
		}

		 $scope.playAudio = function() {	        
	        $scope.audio.play();
	    };

	    $scope.wantSignOut = function(){
	    	$scope.route = $scope.ROUTE3;
			$scope.switchNavRoute($scope.route);
	    	$scope.index++;
	    	$scope.showHide();	    	
			$scope.getMyText();
	    }

	    $scope.goForQrCode = function(){	
	    	$scope.route = $scope.ROUTE2;
			$scope.switchNavRoute($scope.route);	    	
	    	$scope.index++;
	    	$scope.showHide();	    	
	    	$scope.showHide();	    	
			$scope.getMyText();
			// load camera for scanning qr code
			load();

	    }

	    $scope.notSignOutVisitors = function(){	    	
	    	$http({
				method: 'GET',        
		        url: app_base_url + '/api/v1/not-signout-visitors/'+COMPANYID,
		        headers: {'Content-Type': 'application/x-www-form-urlencoded', 'ApiKey': APIKEY}
		    }).then(function successCallback(response) {    	
				$scope.nonSignOutvisitorList = response.data.visitors;  
				//console.log($scope.nonSignOutvisitorList);
			}, function errorCallback(response) {
			    console.log('error');
			});
	    }

	    $scope.notSignOutVisitors();

	    $scope.signOut = function(){
	    	$http({
				method: 'GET',        
		        url: app_base_url + '/api/v1/visitor-logout/' + param_nvisitor_id,
		        headers: {'Content-Type': 'application/x-www-form-urlencoded', 'ApiKey': APIKEY}
		    }).then(function successCallback(response) { 
		    	window.location.reload(true);
			}, function errorCallback(response) {
			    console.log('error');
			});
	    }

	    $http({
			method: 'GET',        
	        url: app_base_url + '/api/v1/VisitorTypeByCompanyId/'+COMPANYID,
	        headers: {'Content-Type': 'application/x-www-form-urlencoded', 'ApiKey': APIKEY}
	    }).then(function successCallback(response) {    	
		    $scope.visitorTypes = response.data.VisitorTypeList;
		    $scope.VisitorTypeId = $scope.visitorTypes[0].VisitorTypeId;
			$scope.visitorType = $scope.visitorTypes[0].VisitorType;
			param_visitor_type_id = $scope.VisitorTypeId;
		}, function errorCallback(response) {
		    console.log('error');
		    //console.log(response);
		});

		$http({
			method: 'GET',        
		    url: app_base_url + '/api/v1/employee-list/'+COMPANYID,
		    headers: {'Content-Type': 'application/x-www-form-urlencoded', 'ApiKey': APIKEY}
	    }).then(function successCallback(response) { 
	    	//console.log(response.data.employee);	
			 $scope.hostList = response.data.employee;
		}, function errorCallback(response) {
		    console.log('error');
		    //console.log(response);
		});


	});

myApp.directive('autoFocus', function($timeout) {	
	return {
		link: function (scope, element, attrs) {        	
			attrs.$observe("autoFocus", function(newValue){              	       	
				if (newValue === "true")
					$timeout(function(){element[0].focus();});
			});
		}
	};
});
