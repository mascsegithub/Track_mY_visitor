<?php 
	include('../connection.php');
	include('../myvisitor-app-datasource.php'); 
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">	
	<link rel="shortcut icon" href="../../images/favicon.ico" type="image/x-icon">
	<link rel="icon" href="../../images/favicon.ico" type="image/x-icon">
  <!-- <link href="https://fonts.googleapis.com/css?family=Roboto:300" rel="stylesheet">  -->
	<title><?php echo $LangText['MY_VISITOR']; ?></title>
	<link href="../css/style.css" rel="stylesheet"> 
	<script src="../js/angular.min.js"></script>
	<script src="../js/angular-animate.js"></script>  
  <script src="../js/angular-animate.js"></script> 
  <script type="text/javascript" src="../js/webqr/llqrcode.js"></script>      
  <script type="text/javascript" src="../js/webqr/webqr.js"></script>
  <script>
    	var APIKEY = '<?php echo $apikey; ?>';
    	var COMPANYID = '<?php echo $CompanyId; ?>';
    	var ISCOMPANYADMIN = '<?php echo $IsCompanyAdmin; ?>';			
    	var myVisitor = '<?php echo $LangText['MY_VISITOR']; ?>';
    	var howMayIHelpYou = '<?php echo $LangText['HOW_MAY_I_HELP_YOU']; ?>';
    	var tellAboutYourself = '<?php echo $LangText['TELL_ABOUT_YOURSELF']; ?>';
      var takeAPicture = '<?php echo $LangText['TAKE_A_PICTURE']; ?>';
    	var itYourSelectedPicture = '<?php echo mysql_real_escape_string($LangText['YOUR_SELECTED_PICTURE']); ?>';
    	var whoAreYouVisiting = '<?php echo $LangText['WHO_ARE_YOU_VISITING']; ?>';
    	var isEverythingCorrect = '<?php echo $LangText['IS_EVERYTHING_CORRECT']; ?>';
    	var signingOut = '<?php echo $LangText['SIGNING_OUT']; ?>';
    	var postinfInformation = '<?php echo $LangText['POATING_YOUR_INFORMATION']; ?>';
    	var fillVisitorName = '<?php echo $LangText['YOU_MUST_FILL_THE_NAME']; ?>';
      var fillVisitorCompany = '<?php echo $LangText['YOU_MUST_FILL_THE_COMPANY']; ?>';	
      var scanYourQrCode = '<?php echo $LangText['SCAN_YOUR_QR_CODE']; ?>'; 		
   </script>
	<script src="../js/app.js"></script>	
</head>
<body>
 <div class="container" ng-app="myVisitor" ng-controller="visitorController" >
   <!-- <div class="roundcls"></div> -->
   <div class="nav clearfix">
     <input id="previous" type="image" src="../images/previous.jpg" alt="Previous" ng-click="showPrevious()" ng-style="showPreviousStyle">
     <div class="title">{{ pageTitle }}</div>
     <input id="next" type="image" src="../images/next.jpg" alt="Next" ng-click="showNext()"  ng-style="showNextStyle">
   </div>
    <!-- start home page == PAGE1 == -->
   <div class="home-page-wrap" ng-show="showHomePage" ng-click="showNext()">      
    <div class="home-page"> 
      <div class="img-wrap">
          <img class="company-log" src="../../images/companylogo/thumbs/<?php echo $CompannyLogo;?>"></img>
      </div>
      <div class="welcome"><?php echo $LangText['WELCOME']; ?></div> 
      <div class="touch-to-start"><img src="../images/touch-icon.png"><div>	<?php echo $LangText['TOUCH_TO_START']; ?></div></div>     
    </div>
  </div>
  <!-- end home page -->
   <!-- start visitor type selection == PAGE2 == -->
   <div class="visitor-type-wrap clearfix" ng-show="showVisitorType">  
     <div class="visitor-type">
        <span><?php echo $LangText['VISITOR_TYPE']; ?>: </span>  
        <div class="visitortype-list"> 
          <li class="visitortype">
            {{visitorType}}
          </li>       
          <li class="visitortype" ng-repeat="vt in visitorTypes"  ng-click="changeVistorType(vt.VisitorTypeId, vt.VisitorType)">
            {{ vt.VisitorType }}
          </li>
        </div>     
      </div>
      <div class="want-sign-out" ng-click="wantSignOut()"><?php echo $LangText['I_WANT_TO_SIGN_OUT']; ?></div>
      <div class="go-for-qrcode" ng-click="goForQrCode()"><img id="qrcode" src="../images/qrcode.jpg" width="120" /></div>
  </div>
  <!-- end visitor type selection -->
  <!-- start visitor input == PAGE3 == -->
  <div class="visitor-info" ng-show="showVisitorInfo">
    <form name="visitorForm">
      <input name="nvisitorName" placeholder="<?php echo $LangText['VISITOR_NAME']; ?>" ng-model="visitorName" auto-focus="{{ showVisitorInfo }}" required>
      <input name="nvisitorCompany" placeholder="<?php echo $LangText['VISITOR_COMPANY']; ?>" ng-model="visitorCompany" required>
      <span style="display:none" >{{visitorNameValid = visitorForm.nvisitorName.$valid}}</span>
      <span style="display:none" >{{visitorCompanyValid = visitorForm.nvisitorCompany.$valid}}</span>
    </form>
  </div>
  <!-- end visitor input -->

  <!-- start visitor camera input  == PAGE4 == -->
  <div id="camera-input-wrap" ng-show="showCameraInput">
    <div id="camera-input"></div>
    <div class="lookat"><?php echo $LangText['PLEASE_LOOK_AT_THE_SCREEN_FOR_5_SECONDS']; ?></div>
    <!-- <audio src="http://www.soundjay.com/mechanical/camera-shutter-click-08.mp3"></audio> -->
  </div>
  <!-- end visitor camera input --> 

  <!-- start visitor image view  == PAGE5 == -->
  <div id="image-view-wrap" ng-show="showImageView">
    <div id="image-view"></div>
    <div class="retake" ng-click="showPreviousRetake()"><?php echo $LangText['TAKE_PICTURE_AGAIN']; ?></div>
  </div>
  <!-- end visitor image view --> 

   <!-- start host list  == PAGE6 == -->
  <div id="host-list-wrap" ng-show="showHostList">   
    <div id="host-search"><input type="search" name="hostname-search" placeholder="<?php echo $LangText['NAME_OF_HOST']; ?>" ng-model='query' auto-focus="{{ showHostList }}"></div>
    <div id="host-list">
      <ul>
        <li class="host" ng-repeat='host in hostList | filter:query' ng-click="setHostValue(host)">
          <img src="../../images/employees/{{ host.EmpImage }}" width="64" height="64px">
          <p>
            <div id="full-name">{{ host.FullName }}</div>           
            <div id="division">{{ host.DivisionName }}</div>
          </p>
        </li>
      </ul>
    </div>
    
  </div>
  <!-- end host list --> 

  <!-- start selected info for submission  == PAGE7 == -->
  <div id="sel-info-wrap" ng-show="showSelectedInfo">   
    <div id="sel-info" class="clearfix">
      <div id="company-name">Softworks Ltd.</div>
      <div id="sel-image"></div>
      <div id="sel-info-text" class="clearfix">
        <div id="sel-visitor-type"> {{ visitorType | uppercase}} </div>
        <div id="sel-visitor-name" class="sel-info">{{ visitorName }}</div>
        <div id="sel-visitor-company" class="sel-info">{{ visitorCompany }}</div>
        <div id="sel-visiting" class="sel-info">Visiting</div>    
        <div id="sel-host" class="sel-info">{{selHost.full_name}}</span></div>            
      </div>  
      <center><div id="sel-date" class="sel-info">{{curDate | date:'fullDate' | uppercase}}</div></center>  
    </div>
    <div id="submit" ng-click="showNext()"><?php echo $LangText['LOOKS_GOOD_TO_GO']; ?></div>
  </div>
  <!-- end selected info for submission --> 

  <!-- start connecting  == PAGE8 == -->
  <div id="connecting-host-wrap" ng-show="showConnectingHost" >   
    <center><div id="connecting-host">
      <?php echo $LangText['CONNECTING_YOUR_HOST']; ?>
    </div></center>  
  </div>
  <!-- end connecting --> 

  <!-- start non sign out visitor list  == PAGE9 == -->
  <div id="non-signout-vistors-wrap" ng-show="showNonSignoutVisitor">   
    <div id="non-signout-visitor-search">
    <input type="search" name="nv-name-search" placeholder="<?php echo $LangText['PLEASE_TYPE_YOUR_NAME_FOR_LOGGING_OUT']; ?>" ng-model='query' auto-focus="{{ showNonSignoutVisitor }}" ng-minlength="3"></div>
    <div id="nvisitor-list">
      <ul>
        <li class="nvisitor" ng-repeat='nv in nonSignOutvisitorList | filter:query' ng-click="setNVisitorValue(nv)">
          <img src="{{ app_base_url }}/images/visitors/{{ nv.ImagePath }}" width="64" height="64px">
          <p>
            <div id="nvisitor-name">{{ nv.VisitorName }}</div>           
            <div id="nvisitor-company">{{ nv.VisitorCompany }}</div>
          </p>
        </li>
      </ul>
    </div>
    
  </div>
  <!-- end non sign out visitor list --> 

   <!-- start signing out  == PAGE10 == -->
  <div id="signed-out-wrap" ng-show="showSignedOut" >   
    <center><div id="signed-out">
      <?php echo $LangText['YOU_HAVE_SIGNED_OUT_THANKS_FOR_VISITING_US']; ?>
    </div></center>  
  </div>
  <!-- end signing out --> 

  <!-- start authorize visitor  == PAGE11 == -->
  <div id="start-auth-visitor-wrap" ng-show="showAuthVisitor">   
    <div id="auth-visitor">
      <div id="outdiv">
      <video id="v" autoplay="autoplay"></video>
    </div>
    <div id="result">- scanning -</div>
    <canvas id="qr-canvas" width="640" height="480" style="width: 640px; height: 480px;"></canvas>
      <!-- <script type="text/javascript">load();</script> -->
    </div>    
  </div>
  <!-- end authorize visitor list --> 

</div>

<script src="../js/webcam/webcam.js"></script>
<script language="JavaScript">  
  var app_base_url = 'http://localhost/trackmyvisitor';
  var param_visitor_name = '';
  var param_visitor_company = '';
  var param_visitor_type_id = 0;
  var param_employee_id = 0;
  var param_nvisitor_id = 0;
  var param_data_uri = '';
  var countCallBack = 0;

  Webcam.set({
    width: 560,
    height: 420,
    image_format: 'jpeg',
    jpeg_quality: 90,
    upload_name: 'ImagePath'
  });

  //Webcam.attach( '#camera-input' );
  
  function take_snapshot() {
      // take snapshot and get image data
      Webcam.snap( function(data_uri) {                
        document.getElementById('image-view').innerHTML = '<img src="' + data_uri + '" width="360"/>';
        document.getElementById('sel-image').innerHTML = '<img src="' + data_uri + '" width="250"/>';  
        param_data_uri = data_uri;    
      } );
    }

     Webcam.on( 'load', function() {
        console.log('Webcam library is loaded');
    } );

    Webcam.on( 'live', function() {
        // camera is live, showing preview image
        // (and user has allowed access)        
        console.log('camera is live, showing preview image (and user has allowed access)');

    } );

    Webcam.on( 'error', function(err) {
        console.log('Webcam - an error occurred (see "err")');         
    } );

    function upload_image() {
      Webcam.upload( param_data_uri, app_base_url + '/api/v1/create-visitor', function(code, text) {        
          window.location.reload(true);
      } );

     // } );
  }

  </script>

</body>
</html>