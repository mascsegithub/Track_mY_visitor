<?php
$outputResponse = 'Login Fail';

	session_start();

	if((isset($_POST['EmailAddress']))&&(isset($_POST['Password'])))
	{
		include('../connection.php');

		$Email = stripcslashes($_POST['EmailAddress']);
		$email = mysql_real_escape_string($Email);
		$passw = stripcslashes($_POST['Password']);
		$pword = mysql_real_escape_string($passw);
		$Password = md5($pword);

		if($email!='' && $Password!='')
		{
			$sql="SELECT t_employee.Id, 
				t_employee.FullName, 
				t_employee.EmailAddress,
				t_employee.Password,
				t_company.CompanyName, 
				t_employee.CompanyId, t_company.api_key, 
				t_employee.IsCompanyAdmin,
				`t_company`.`TimeZoneId`
				FROM t_employee
				INNER JOIN t_company  ON (t_employee.CompanyId = t_company.CompanyId)
				WHERE EmailAddress='".$email."';";			
			$result=mysql_query($sql);			
			if(mysql_num_rows($result)>0)
			{			
				$arr=mysql_fetch_array($result);
				
				$sql1="SELECT CompanyId FROM t_company WHERE CompanyId = '".$_POST['CompanyId']."';";			
				$result1=mysql_query($sql1);
				$aRow=mysql_fetch_array($result1);
				if($arr['CompanyId']==$aRow['CompanyId']){
					
					if($arr['Password']==$Password){
							$_SESSION['Id']=$arr['Id'];
							$_SESSION['FullName']=$arr['FullName'];
							$_SESSION['EmailAddress']=$arr['EmailAddress'];
							$_SESSION['CompanyName']=$arr['CompanyName'];
							$_SESSION['CompanyId']=$arr['CompanyId'];
							$_SESSION['apikey']=$arr['api_key'];
							$_SESSION['IsCompanyAdmin']=$arr['IsCompanyAdmin'];
							$_SESSION['TimeZoneName']=$arr['TimeZoneId'];
							
							$outputResponse = 1;
					}
					else{
						$outputResponse = 'Password not match.';
					}
					
				}else{
					$outputResponse = 'This company code is not found.';
				}

			}
			else{
				$outputResponse = 'This user not found.';
			}
		}
		else{
			$outputResponse = 'Please type valid UserName and Password.';
		}
	}
	else{
		$outputResponse = 'Please type valid UserName and Password.';
	}	

echo $outputResponse;
?>

