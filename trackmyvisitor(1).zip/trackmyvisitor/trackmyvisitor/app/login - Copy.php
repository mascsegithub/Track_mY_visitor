<?php 
	include('../connection.php');
	$CompanyId = $_GET['CompanyId'];
	$sQuery = "SELECT LangTextName, LangText FROM t_language_text 
	WHERE CompanyId=$CompanyId;";
	$rResult = mysql_query($sQuery);
	$total = mysql_num_rows($rResult);
	$LangText = array();
	while ($row = mysql_fetch_assoc($rResult)) {
		$LangText[$row['LangTextName']] = $row['LangText'];
	}
		
	if($total>0){
?>

<!DOCTYPE html>
<html dir="ltr" lang="en-US">
    <head>
        <meta http-equiv="content-type" content="text/html; charset=utf-8" />
        <meta name="author" content="SoftWorks" />
        <!-- Stylesheets
        ============================================= -->
        <link href="http://fonts.googleapis.com/css?family=Lato:300,400,400italic,600,700|Raleway:300,400,500,600,700|Crete+Round:400italic" rel="stylesheet" type="text/css" />
        <link rel="stylesheet" href="../css/bootstrap.css" type="text/css" />
        <link rel="stylesheet" href="../style.css" type="text/css" />
        <link rel="stylesheet" href="../css/dark.css" type="text/css" />
        <link rel="stylesheet" href="../css/font-icons.css" type="text/css" />
        <link rel="stylesheet" href="../css/animate.css" type="text/css" />
        <link rel="stylesheet" href="../css/magnific-popup.css" type="text/css" />

        <link rel="stylesheet" href="../css/responsive.css" type="text/css" />
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
		<link rel="shortcut icon" href="../images/favicon.ico" type="image/x-icon">
		<link rel="icon" href="../images/favicon.ico" type="image/x-icon">
		<link href="css/style.css" rel="stylesheet">
        <!--[if lt IE 9]>
            <script src="http://css3-mediaqueries-js.googlecode.com/svn/trunk/css3-mediaqueries.js"></script>
        <![endif]-->

        <!-- Document Title
        ============================================= -->
        <title>Track My Visitor - User Login</title>
		<?php include('../baseurl.php'); ?>
        <script>
			var baseUrl = '<?php echo $SiteBaseUrl; ?>';
			var APIKEY = '<?php echo $apikey; ?>';
			var COMPANYID = '<?php echo $CompanyId; ?>';
			var ISCOMPANYADMIN = '<?php echo $IsCompanyAdmin; ?>';			
		</script>
    </head>

    <body class="stretched">
        <!-- Document Wrapper -->
        <div id="wrapper" class="clearfix">
   <!-- <div class="roundcls"></div> -->
   <div class="nav clearfix">
     <!--<input id="previous" type="image" src="images/previous.jpg" alt="Previous" ng-click="showPrevious()">-->
     <div class="title"><?php echo $LangText['MY_VISITOR']; ?></div>
     <!--<input id="next" type="image" src="images/next.jpg" alt="Next" ng-click="showNext()">-->
   </div>
    <!-- start home page -->
            <!-- Content -->
            <section id="content">
                <div class="content-wrap">
                    <div class="container clearfix">
                        <div class="accordion accordion-lg divcenter nobottommargin clearfix" style="max-width: 550px;">

                            <div class="acctitle"><i class="acc-closed icon-lock3"></i><i class="acc-open icon-unlock"></i><?php echo $LangText['LOGIN']; ?></div>
                            <div class="acc_content clearfix">
								<form id="login-form" name="login-form" class="nobottommargin" method="post">
                                    <div class="col_full">
                                        <em class="invalid" id="invalidLogin"></em>
                                    </div>
                                    
                                    <div class="col_full">
                                        <label for="login-form-email"><?php echo $LangText['EMAIL']; ?>:<?php //echo $LangText['WELCOME']; ?></label>
                                        <input type="text" id="login-form-email" name="EmailAddress" class="form-control" />
                                        <em class="invalid" id="invalidEmail"></em>
                                    </div>

                                    <div class="col_full">
                                        <label for="login-form-password"><?php echo $LangText['PASSWORD']; ?>:</label>
                                        <input type="password" id="login-form-password" name="Password" class="form-control" />
                                        <em class="invalid" id="invalidpassword"></em>
                                    </div>

                                    <div class="col_full nobottommargin">
										<input type="submit" value="<?php echo $LangText['SIGN_IN']; ?>" class="button button-3d button-black nomargin btn-form-login">
									</div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </section><!-- #content end -->
        </div><!-- #wrapper end -->

        <!-- External JavaScripts -->
        <script type="text/javascript" src="../js/jquery.js"></script>
        <script type="text/javascript" src="../js/plugins.js"></script>
		
        <script type="text/javascript" src="../js/functions.js"></script>
        <script type="text/javascript" src="login.js"></script>

    </body>
</html>
<?php
 }else{
	header("location:404.php");
} 
?>