
var $ = jQuery.noConflict();

function validateEmail(email) {
    var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return re.test(email);
}

function onConfirmWhenLogin() {
    var Email = $("#login-form-email").val();
    var password = $("#login-form-password").val();
    var error = 0;
    if (Email == '') {
        $("#invalidEmail").html('Please enter your email address');
        $("#login-form-email").addClass('invalidval');
        error = 1;
    }
    else if (!validateEmail(Email)) {
        $("#invalidEmail").html('Please enter valid email address');
        $("#login-form-email").addClass('invalidval');
        error = 1;
    }
    else {
        $("#invalidEmail").html('');
        $("#login-form-email").removeClass('invalidval');
    }

    if (password == '') {
        $("#invalidpassword").html('Please enter your password');
        $("#login-form-password").addClass('invalidval');
        error = 1;
    }
    else {
        $("#invalidpassword").html('');
        $("#login-form-password").removeClass('invalidval');

    }
    if (error == 1) {
        return false;
    }
    else {
		$.ajax({
			"type" : "POST",
			"url" : "login_server.php",
			"data" : $('#login-form').serialize()+"&CompanyId="+COMPANYID,
			"success" : function(response) {
				if (response == 1) {
					window.location.href = baseUrl+"app/"+COMPANYID+"/loggedin";
				}else{
					$('#invalidLogin').html(response);
				}
			}
		});
        
    }
}

$(function () {
    $('#login-form').submit(function () {
        onConfirmWhenLogin();
        return false;
    });

});
