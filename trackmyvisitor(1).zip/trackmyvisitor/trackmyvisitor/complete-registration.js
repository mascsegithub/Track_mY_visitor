
var $ = jQuery.noConflict();

function resetForm(id) {
	$('#' + id).each(function() {
		this.reset();
	});
}

function validateEmail(email) {
    var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return re.test(email);
}

function onConfirmWhenRegister() {

    var Email = $("#EmailAddress").val();
    var Password = $("#Password").val();
    var ConfirmPass = $("#ConfirmPassword").val();
    var error = 0;
    if (Email == '') {
        $("#invalidEmail").html('Please enter your email address');
        error = 1;
    }else if (!validateEmail(Email)) {
        $("#invalidEmail").html('Please enter valid email address');
        error = 1;
    }else {
        $("#invalidEmail").html('');
    }
	
    if (Password == '') {
        $("#invalidpassword").html('Please enter password');
        error = 1;
    }else {
        $("#invalidpassword").html('');
    }
	
    /* if (ConfirmPass == '') {
        $("#invalidConfirmpassword").html('Mitch match your password');
        error = 1;
    }else {
        $("#invalidConfirmpassword").html('');
    } */
	
    if (error == 1) {
        return false;
    }
    else {
    $.ajax({
        "async": true,
        url: baseUrl + "complete-registration",
        "method": "POST",
        "data": $('#complete-register-form').serialize(),
        success: function (response){
			if(response['error'] == 0){
				resetForm("complete-register-form");
				$("#registerformsuccess").show();
				$("#registerform").hide();				
			}else if(response['error'] == 2){				
				$("#registerform").show();
				$("#registerformsuccess").hide();
				$("#invalidEmail").html(response['message']);
				
			}else if(response['error'] == 3){				
				$("#registerform").show();
				$("#registerformsuccess").hide();
				$("#invalidConfirmpassword").html(response['message']);

			}else{				
				$("#registerform").show();
				$("#registerformsuccess").hide();
				$("#Errormessage").html(response['message']);
			}
        }
    });
   }
}

$(function () {
    $('#complete-register-form').submit(function () {
        onConfirmWhenRegister();
        return false;
    });

});
