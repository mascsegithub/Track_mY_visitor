var fileNames;
var tmpFileNameAttached;
var totalrow = 0;
var gLanguageId = 'en';

function loadLanguageDropdown() {
    $.ajax({
        "async": true,
        url: baseUrl + "language-combo-load",
        "method": "GET",
        "headers": {
            "Apikey": APIKEY,
            "cache-control": "no-cache"
        },
        success: function (response)
        {
            response = response['LanguageList'];
            var count = response.length;
            if (count > 0) {
                $.each(response, function (key, value) {
                    $('#LanguageTitle').append($('<option></option>').val(value.LangCode).html(value.LangTitle));
                });
                $('#LanguageTitle').val(gLanguageId);
            }
            else {
                $('#LanguageTitle').val('');
            }
        }

    });

}


/*----------------------Start Ready function--------------------------*/

$(function () {
    loadLanguageDropdown();
    $('#LanguageTitle').change(function () {
        gLanguageId = $("#LanguageTitle").val();
        $.ajax({
            "async": true,
            url: baseUrl + "getInterFacingStringByLanguage/" + gLanguageId,
            "method": "GET",
            "headers": {
                "Apikey": APIKEY,
                "cache-control": "no-cache"
            },
            success: function (response)
            {
                response = response['LanguageText'];
                totalrow = response.length;

                var trHTML = '';
                var LangTextName = '';
                var LangText = '';
                var i = 1;
                trHTML += '<div id="list-panel">' +
                        '<div style="float: left; margin-bottom: -10px"><h3></h3></div>' +
                        '<table id="LanguageTable" class="table table-bordered nobottommargin" cellspacing="0">' +
                        '<thead><tr><th style="text-align: left;">Language Variable</th><th style="text-align: left;">Language Text</th></tr>' +
                        '</thead>' +
                        '<tbody>';
                if (totalrow >= 1) {
                    $.each(response, function (key, value) {
                        LangTextName = value.LangTextName;
                        LangText = value.LangText;
                        trHTML +=
                                '<tr><td style="width:40%;" id="lanTextName_' + i + '" class="">' + LangTextName +
                                '</td><td><a  href="#" data-pk="' + LangTextName + '" class="newuser" name="lanTextId_' + i + '"  id="lanTextId_' + i + '">' + LangText + '</a></td>'
                        '</td></tr>';
                        i++;
                    });
                    trHTML += '</tbody></table></div>';
                }
                else {
                    trHTML += '<tr><td colspan="2" style="text-align:center">No data available in table</td></tr>';
                    trHTML += '</tbody></table></div>';
                }
                $('#LanguageTextTable').html(trHTML);

                $.fn.editable.defaults.mode = 'inline';
                $('#LanguageTable a').editable({
                    type: 'text',
                    name: 'textname',
                    pk: 1,
                    url: baseUrl + 'update-master-lan-text/' + gLanguageId,
                    title: 'Enter Text',
                    ajaxOptions: {
                        type: 'put',
                        dataType: 'json',
                        headers: {
                            "ApiKey": APIKEY
                        }
                    }
                });
                formValidation();
                autoOpenNextField();
            }
        });
    });


    $.ajax({
        "async": true,
        url: baseUrl + "getInterFacingStringByLanguage/" + gLanguageId,
        "method": "GET",
        "headers": {
            "Apikey": APIKEY,
            "cache-control": "no-cache"
        },
        success: function (response)
        {
            response = response['LanguageText'];
            totalrow = response.length;

            var trHTML = '';
            var LangTextName = '';
            var LangText = '';
            var i = 1;
            trHTML += '<div id="list-panel">' +
                    '<div style="float: left; margin-bottom: -10px"><h3></h3></div>' +
                    '<table id="LanguageTable" class="table table-bordered nobottommargin" cellspacing="0">' +
                    '<thead><tr><th style="text-align: left;">Language Variable</th><th style="text-align: left;">Language Text</th></tr>' +
                    '</thead>' +
                    '<tbody>';
            if (totalrow >= 1) {
                $.each(response, function (key, value) {
                    LangTextName = value.LangTextName;
                    LangText = value.LangText;
                    trHTML +=
                            '<tr><td style="width:40%;" id="lanTextName_' + i + '" class="">' + LangTextName +
                            '</td><td><a  href="#" data-pk="' + LangTextName + '" class="newuser" name="lanTextId_' + i + '"  id="lanTextId_' + i + '">' + LangText + '</a></td>'
                    '</td></tr>';
                    i++;
                });
                trHTML += '</tbody></table></div>';
            }
            else {
                trHTML += '<tr><td colspan="2" style="text-align:center">No data available in table</td></tr>';
                trHTML += '</tbody></table></div>';
            }
            $('#LanguageTextTable').html(trHTML);

            $.fn.editable.defaults.mode = 'inline';
            $('#LanguageTable a').editable({
                type: 'text',
                name: 'textname',
                pk: 1,
                url: baseUrl + 'update-master-lan-text/' + gLanguageId,
                title: 'Enter Text',
                ajaxOptions: {
                    type: 'put',
                    dataType: 'json',
                    headers: {
                        "ApiKey": APIKEY
                    }
                }
            });
            formValidation();
            autoOpenNextField();
        }
    });
});

/*----------------------End Ready function--------------------------*/


function formValidation() {
    for (var i = 1; i <= totalrow; i++) {
        $('#lanTextId_' + i).editable('option', 'validate', function (v) {
            if (!v)
                return 'This Field is Required!';
        });
    }
}
function autoOpenNextField() {
    $('#LanguageTable .editable').on('hidden', function (e, reason) {
        if (reason === 'save' || reason === 'nochange') {
            var $next = $(this).closest('tr').next().find('.editable');
            setTimeout(function () {
                $next.editable('show');
            }, 200);

        }
    });
}
