<!DOCTYPE html>
<html dir="ltr" lang="en-US">
    <head>

        <meta http-equiv="content-type" content="text/html; charset=utf-8" />
        <meta name="author" content="SemiColonWeb" />

        <!-- Stylesheets
        ============================================= -->
        <link href="http://fonts.googleapis.com/css?family=Lato:300,400,400italic,600,700|Raleway:300,400,500,600,700|Crete+Round:400italic" rel="stylesheet" type="text/css" />
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"/> 
        <link rel="stylesheet" href="css/bootstrap.css" type="text/css" />
        <link rel="stylesheet" href="style.css" type="text/css" />
        <link rel="stylesheet" href="css/dark.css" type="text/css" />
        <link rel="stylesheet" href="css/font-icons.css" type="text/css" />
        <link rel="stylesheet" href="css/animate.css" type="text/css" />
        <link rel="stylesheet" href="css/magnific-popup.css" type="text/css" />
        <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/font-awesome/4.2.0/css/font-awesome.min.css">

        <link rel="stylesheet" href="css/jquery-ui.css" type="text/css" />
        <link rel="stylesheet" href="css/responsive.css" type="text/css" />
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
        <link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon">
        <link rel="icon" href="images/favicon.ico" type="image/x-icon">

        <!--[if lt IE 9]>
            <script src="http://css3-mediaqueries-js.googlecode.com/svn/trunk/css3-mediaqueries.js"></script>
        <![endif]-->

        <!-- Document Title
        ============================================= -->
        <title>Track My Visitor - My Settings</title>
        <?php include('global_variables.php'); ?>
        <script>
            if (APIKEY != '' && COMPANYID != '' && ISCOMPANYADMIN == 1) {
            } else {
                window.location = "login.php?redirect_to=dashboard.php";
            }
<?php include('baseurl.php'); ?>
            var baseUrl = '<?php echo $BaseUrl; ?>';
            var ImageUrl = '<?php echo $ImageUrl; ?>';
            //alert(ImageUrl);
        </script>		
    </head>

    <body class="stretched">

        <!-- Document Wrapper
        ============================================= -->
        <div id="wrapper" class="clearfix">

            <!-- Header
            ============================================= -->
            <?php include('header.php'); ?>
            <!-- #header end -->
            <!-- Content
            ============================================= -->
            <section id="content">
                <div class="content-wrap">
                    <div class="container clearfix">
                          <h3>Master Language Settings</h3>
                        <div class="panel panel-default">
                            <div class="panel-body">
                                <div class="row">
                                    <div class="col-md-12">
                                        <!--                                    <button class="button button-3d button-black nomargin" id="" name="" value="" onclick="MySettings()">Master Language Settings</button>-->
                                        <div class="col-md-3" style="margin-left:-13px">
                                            <div class="form-group">
                                                <label for="register-form-name">Language*</label>
                                                <select class="form-control" id="LanguageTitle" name="LanguageTitle"> 
                                                </select>
                                            </div>  
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="table-responsive" id="LanguageTextTable">

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section><!-- #content end aa -->
			  <?php include('footer.php'); ?>
        </div>
        <!-- Footer
        ============================================= -->

        <!-- #footer end -->

    </div><!-- #wrapper end -->

    <!-- Go To Top
    ============================================= -->
    <div id="gotoTop" class="icon-angle-up"></div>



    <!-- External JavaScripts
    ============================================= -->

    <script type="text/javascript" src="js/jquery.js"></script>
    <script type="text/javascript" src="js/plugins.js"></script>
    <script type="text/javascript" src="js/jquery-ui.js"></script>

    <script>
            var $ = jQuery.noConflict();
// var COMPANYID = sessionStorage.getItem("COMPANYID");
// alert(COMPANYID);



    </script>

    <!-- Footer Scripts
    ============================================= -->
    <link  rel="stylesheet"  href="css/fileinput.css" type="text/css"/>
    <script type="text/javascript" src="js/fileinput.js"></script>
    <script type="text/javascript" src="js/functions.js"></script>

<!--    <script type="text/javascript" src="js/bootstrap.min.js"></script>-->

    <link href="//cdnjs.cloudflare.com/ajax/libs/x-editable/1.5.0/bootstrap3-editable/css/bootstrap-editable.css" rel="stylesheet"/>
    <script src="//cdnjs.cloudflare.com/ajax/libs/x-editable/1.5.0/bootstrap3-editable/js/bootstrap-editable.min.js"></script>
    <script type="text/css" src="css/bootstrap-combined.min.css"></script>
    <script type="text/javascript" src="js/jquery.mockjax.js"></script>

    <script type="text/javascript" src="master_language_setting.js"></script>
    <script type="text/javascript" src="js/moment.js"></script>

    <style>

        .AddNewCompany{
            padding-bottom: 10px;
        }
        .AllCompany{
            padding-bottom: 10px;
        }
		element.style {
				margin-top: 0 !important;
		}
    </style>
</body>
</html>