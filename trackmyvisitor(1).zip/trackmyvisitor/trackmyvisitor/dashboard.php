<!DOCTYPE html>
<html dir="ltr" lang="en-US">
    <head>
        <meta http-equiv="content-type" content="text/html; charset=utf-8" />
        <meta name="author" content="trackmyvisitor" />
        <!-- Date & Time Picker CSS -->
        <!-- Stylesheets
        ============================================= -->
        <link href="http://fonts.googleapis.com/css?family=Lato:300,400,400italic,600,700|Raleway:300,400,500,600,700|Crete+Round:400italic" rel="stylesheet" type="text/css" />
        <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css" />
		<link rel="stylesheet" href="css/dataTables.bootstrap.min.css" type="text/css" />
        <link rel="stylesheet" href="style.css" type="text/css" />
        <link rel="stylesheet" href="css/dark.css" type="text/css" />
        <link rel="stylesheet" href="css/font-icons.css" type="text/css" />
        <link rel="stylesheet" href="css/animate.css" type="text/css" />
        <link rel="stylesheet" href="css/magnific-popup.css" type="text/css" />
        <link rel="stylesheet" href="css/responsive.css" type="text/css" />
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
        <link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon">
        <link rel="icon" href="images/favicon.ico" type="image/x-icon">
        <link rel="stylesheet" href="css/jquery-ui.css" type="text/css" />
        <!--[if lt IE 9]>
		<script src="http://css3-mediaqueries-js.googlecode.com/svn/trunk/css3-mediaqueries.js"></script>
		<![endif]-->

        <!-- Document Title
        ============================================= -->
        <title>Track My Visitor - Dashboard</title>
        <?php
        include('global_variables.php');
        include('currentdate.php');
        ?>
        <script>
			if (APIKEY != '' && COMPANYID != '' && ISCOMPANYADMIN == 1) {
			}else{
				window.location = "login.php?redirect_to=dashboard.php";
			}
			<?php include('baseurl.php'); ?>
			var baseUrl = '<?php echo $BaseUrl; ?>';
			var CurrentDate = '<?php echo Currentdate("d-M-Y"); ?>';
			//alert(CDate);
		</script>
    </head>
    <body class="stretched">
        <!-- Document Wrapper
        ============================================= -->
        <div id="wrapper" class="clearfix">
            <!-- Header
            ============================================= -->
            <?php include('header.php'); ?>
            <!-- #header end -->
            <!-- Content
            ============================================= -->
            <section id="content">              
                <div class="content-wrap">
                    <div class="container clearfix">                
                        <div class="row"> 
                            <div class="col-md-8">
                                <div class="form-group">
                                    <div class="col-md-5">
                                        <h3>Signed In Visitors on</h3>
                                    </div>
                                    <div class='col-md-4'style="padding-top:6px;">
                                        <div class="form-group">
                                            <div class='input-group date' style="">
                                                <input type="text" id="SearchDate" name="SearchDate" class="form-control" />
                                                <span id="btn-search" class="input-group-addon">
                                                    <span class="icon-calendar"></span>
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-3"></div>
                                </div> 
                            </div>
                            <div class="col-md-4"></div>
                        </div>
						
                        <div class="row">
                            <div class="col-md-4">                              
                                <div class="nobottommargin center">
									<span class="divcenter nobottommargin DoorIcons"><img src="images/in.png"></span>
                                    <div class="counter counter-large" style="color: #1abc9c;" id="CountSignedInVisitors">
                                    </div>
                                    <h5>Signed In Visitors</h5>
                                </div>
                             </div>
							 <div class="col-md-4">	
                                <div class="nobottommargin center">
									<span class="divcenter nobottommargin DoorIcons"><img src="images/out.png"></span>
                                    <div class="counter counter-large" style="color: #3498db;" id="CountSignedOutVisitors">
                                    </div>
                                    <h5>Signed Out Visitors</h5>
                                </div>
                             </div>
							 <div class="col-md-4">	
                                <div class="nobottommargin center col_last">
									<span class="divcenter nobottommargin DoorIcons"><img src="images/on_premise.png"></span>
                                    <div class="counter counter-large" style="color: #9b59b6;" id="CountPremiseVisitors">
                                    </div>
                                    <h5>On Premise Visitors</h5>
                                </div>
                            </div>
                        </div>
						
						<!-- Modal -->
                        <div class="row">
                            <div class="col-md-12">
                                <div class="modal fade" id="myModal" role="dialog">
                                    <div class="modal-dialog">
                                        <!-- Modal content-->
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <button type="button" class="close" data-dismiss="modal">&times;</button>
                                                <h4 class="modal-title">Host</h4>
                                            </div>
                                            <div class="modal-body">
                                                <table id="HostInfo" class="table table-striped table-bordered display table-hover" cellspacing="0">
                                                </table>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
						<!-- End Modal -->
						
                        <div class="row">
                            <div class="col-md-12">
								<table id="AllVisitorsDataList" class="table table-striped table-bordered table-hover" width="100%" cellspacing="0">
									<thead>
										<tr>
											<th>EmployeeId</th>
											<th style="width:7%; text-align: center;"></th>
											<th style="width:15%; text-align: left;">Visitor</th>
											<th style="width:19%; text-align: left;">Host</th>
											<th style="width:19%; text-align: center;">Sign In</th>
											<th style="width:19%; text-align: center;">Sign Out</th>
											<th style="width:10%; text-align: center;">Duration</th>
											<th style="width:10%; text-align: center;">Visitor Type</th>
										</tr>
									</thead>
									<tbody></tbody>
								</table>
                            </div>
                        </div>
						
                        <div class="row">
							<div class="col-md-6">
								<div class="panel panel-default">
									<div class="panel-heading">
										<h2 class="panel-title" id="SelectDays"></h2>
									</div>
									<div class="panel-body">
										<div id="VisitorsNumbersPerDay">
										</div>
									</div>
								</div>
                            </div>
							<div class="col-md-6">
								<div class="panel panel-default col_last">
									<div class="panel-heading">
										<h2 class="panel-title" id="SelectDaysPieChart"></h2>
									</div>
									<div class="panel-body">
										<div id="VisitorsNumbersPerDay_pichart">
										</div>
									</div>
								</div>
                            </div>
                        </div>
                    </div>
                </div>
            </section><!-- #content end -->

            <!-- Footer
            ============================================= -->
            <?php include('footer.php'); ?>
            <!-- #footer end -->

        </div><!-- #wrapper end -->

        <!-- Go To Top
        ============================================= -->
        <div id="gotoTop" class="icon-angle-up"></div>
        <style>
            .box_border{
                border: 2px solid #dddddd;
            }
            .panel-title {
                margin-bottom: 7px !important;
            }
            .col-md-5 {
                width: 35.667%;
            }
            .col-sm-4 {
                width: 35.333%;
            }
            hr {
                border-bottom-color: #fff;
                border-top-color: #eee;
                margin: 0.7em auto !important;
            }
        </style>


        <!-- Footer Scripts
        ============================================= -->
        <!-- External JavaScripts
        ============================================= -->


        <script type="text/javascript" src="js/jquery.js"></script>
        <script type="text/javascript" src="js/plugins.js"></script>	
		
        <script type="text/javascript" src="js/jquery.dataTables.min.js"></script>
        <script type="text/javascript" src="js/dataTables.bootstrap.min.js"></script>
		
        <script type="text/javascript" src="js/functions.js"></script>
        <script type="text/javascript" src="js/moment.js"></script>
        <script type="text/javascript" src="js/highcharts.js"></script>
        <script type="text/javascript" src="js/exporting.js"></script>
        <script type="text/javascript" src="dashboard.js"></script>

        <script type="text/javascript" src="js/jquery-ui.js"></script>
        <script type="text/javascript" src="js/moment.js"></script>


    </body>
</html>