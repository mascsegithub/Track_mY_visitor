<!DOCTYPE html>
<html dir="ltr" lang="en-US">
    <head>
        <meta http-equiv="content-type" content="text/html; charset=utf-8" />
        <meta name="author" content="SemiColonWeb" />
        <!-- Stylesheets
        ============================================= -->
        <link href="http://fonts.googleapis.com/css?family=Lato:300,400,400italic,600,700|Raleway:300,400,500,600,700|Crete+Round:400italic" rel="stylesheet" type="text/css" />
        <link rel="stylesheet" href="css/bootstrap.css" type="text/css" />
        <link rel="stylesheet" href="style.css" type="text/css" />
        <link rel="stylesheet" href="css/dark.css" type="text/css" />
        <link rel="stylesheet" href="css/font-icons.css" type="text/css" />
        <link rel="stylesheet" href="css/animate.css" type="text/css" />
        <link rel="stylesheet" href="css/magnific-popup.css" type="text/css" />
        <link rel="stylesheet" href="css/responsive.css" type="text/css" />
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />

        <link rel="stylesheet" type="text/css" href="css/settings.css" media="screen" />
        <link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon">
        <link rel="icon" href="images/favicon.ico" type="image/x-icon">
        <!--[if lt IE 9]>
            <script src="http://css3-mediaqueries-js.googlecode.com/svn/trunk/css3-mediaqueries.js"></script>
        <![endif]-->
        <!-- Document Title
        ============================================= -->
        <title>Home - Track My Visitor</title>
        <?php include('global_variables.php'); ?>
        <style>

            .revo-slider-emphasis-text {
                font-size: 64px;
                font-weight: 700;
                letter-spacing: -1px;
                font-family: 'Raleway', sans-serif;
                padding: 15px 20px;
                border-top: 2px solid #FFF;
                border-bottom: 2px solid #FFF;
            }

            .revo-slider-desc-text {
                font-size: 20px;
                font-family: 'Lato', sans-serif;
                width: 650px;
                text-align: center;
                line-height: 1.5;
            }

            .revo-slider-caps-text {
                font-size: 16px;
                font-weight: 400;
                letter-spacing: 3px;
                font-family: 'Raleway', sans-serif;
            }

        </style>

    </head>

    <body class="stretched">
        <!-- Document Wrapper
        ============================================= -->
        <div id="wrapper" class="clearfix">
            <!-- Header
            ============================================= -->
            <?php include('header.php'); ?>
            <!-- #header end -->

            <section id="slider" class="slider-parallax revslider-wrap clearfix">

                <!--
                #################################
                    - THEMEPUNCH BANNER -
                #################################
                -->
                <div class="tp-banner-container">
                    <div class="tp-banner" >
                        <ul>    <!-- SLIDE  -->

                            <!-- SLIDE  -->
                            <li class="dark" data-transition="zoomout" data-slotamount="1" data-masterspeed="1500"  data-saveperformance="off" >
                                <!-- MAIN IMAGE -->
                                <img src="images/slider/sl_bg.jpg"  alt="citybg" data-lazyload="images/slider/sl_bg.jpg" data-bgposition="center top" data-bgfit="cover" data-bgrepeat="no-repeat">
                                <!-- LAYERS -->

                                <!-- LAYER NR. 1 -->
                                <div class="tp-caption customin ltl tp-resizeme"
                                     data-x="640"
                                     data-y="45"
                                     data-customin="x:250;y:0;z:0;rotationZ:0;scaleX:1;scaleY:1;skewX:0;skewY:0;opacity:0;transformPerspective:200;transformOrigin:50% 0%;"
                                     data-speed="400"
                                     data-start="1000"
                                     data-easing="easeOutQuad"
                                     data-splitin="none"
                                     data-splitout="none"
                                     data-elementdelay="0.01"
                                     data-endelementdelay="0.1"
                                     data-endspeed="1000"
                                     data-endeasing="Power4.easeIn"><img style="width: 552px; height: 400px;" src="images/slider/1.png" alt=""></div>

                                <div class="tp-caption customin ltl tp-resizeme revo-slider-emphasis-text nopadding noborder"
                                     data-x="-3"
                                     data-y="70"
                                     data-customin="x:0;y:150;z:0;rotationZ:0;scaleX:1;scaleY:1;skewX:0;skewY:0;opacity:0;transformPerspective:200;transformOrigin:50% 0%;"
                                     data-speed="800"
                                     data-start="1200"
                                     data-easing="easeOutQuad"
                                     data-splitin="none"
                                     data-splitout="none"
                                     data-elementdelay="0.01"
                                     data-endelementdelay="0.1"
                                     data-endspeed="1000"
                                     data-endeasing="Power4.easeIn" style="font-size: 27px; line-height:30px; color:#000;"><br>myVisitor is a visitor Management System</div>

                                <div class="tp-caption customin ltl tp-resizeme revo-slider-desc-text tleft"
                                     data-x="0"
                                     data-y="140"
                                     data-customin="x:0;y:150;z:0;rotationZ:0;scaleX:1;scaleY:1;skewX:0;skewY:0;opacity:0;transformPerspective:200;transformOrigin:50% 0%;"
                                     data-speed="800"
                                     data-start="1400"
                                     data-easing="easeOutQuad"
                                     data-splitin="none"
                                     data-splitout="none"
                                     data-elementdelay="0.01"
                                     data-endelementdelay="0.1"
                                     data-endspeed="1000"
                                     data-endeasing="Power4.easeIn" style="max-width: 550px; white-space: normal; color:#000;">Effective visitor registration with image capture and optional badge printing</div>

                             
                            </li>
                            <li class="dark" data-transition="zoomout" data-slotamount="1" data-masterspeed="1500" data-saveperformance="off">
                                <!-- MAIN IMAGE -->
                                <img src="images/slider/sl_bg2.jpg"  alt="kenburns6"  data-bgposition="left bottom" data-kenburns="on" data-duration="20000" data-ease="Linear.easeNone" data-bgfit="100" data-bgfitend="120" data-bgpositionend="right top">
                                <!-- LAYERS -->
                                <div class="tp-caption customin"
                                     data-x="0"
                                     data-y="110"
                                     data-customin="x:0;y:0;z:0;rotationZ:0;scaleX:0.6;scaleY:0.6;skewX:0;skewY:0;opacity:0;transformPerspective:0;transformOrigin:50% 50%;"
                                     data-speed="850"
                                     data-start="1200"
                                     data-easing="easeOutQuad"
                                     data-splitin="none"
                                     data-splitout="none"
                                     data-elementdelay="0.01"
                                     data-endelementdelay="0.1"
                                     data-endspeed="1000"
                                     data-endeasing="Power4.easeIn">
                                    <img style="width:552px; height: 293px;" src="images/slider/2.png" alt="uims">
                                </div>

                                <div class="tp-caption customin ltl tp-resizeme revo-slider-emphasis-text nopadding noborder"
                                     data-x="672"
                                     data-y="90"
                                     data-customin="x:140;y:0;z:0;rotationZ:0;scaleX:1;scaleY:1;skewX:0;skewY:0;opacity:0;transformPerspective:200;transformOrigin:50% 0%;"
                                     data-speed="800"
                                     data-start="1200"
                                     data-easing="easeOutQuad"
                                     data-splitin="none"
                                     data-splitout="none"
                                     data-elementdelay="0.01"
                                     data-endelementdelay="0.1"
                                     data-endspeed="1000"
                                     data-endeasing="Power4.easeIn" style="font-size: 27px; line-height:30px; color:#000;"><br>myVisitor improves front-desk efficiency</div>

                                <div class="tp-caption customin ltl tp-resizeme revo-slider-desc-text tleft"
                                     data-x="675"
                                     data-y="160"
                                     data-customin="x:140;y:0;z:0;rotationZ:0;scaleX:1;scaleY:1;skewX:0;skewY:0;opacity:0;transformPerspective:200;transformOrigin:50% 0%;"
                                     data-speed="800"
                                     data-start="1400"
                                     data-easing="easeOutQuad"
                                     data-splitin="none"
                                     data-splitout="none"
                                     data-elementdelay="0.01"
                                     data-endelementdelay="0.1"
                                     data-endspeed="1000"
                                     data-endeasing="Power4.easeIn" style="max-width: 550px; white-space: normal; color:#000;">Automatic visitor notification to the host via SMS, email</div>

                               
                            </li>
                            <li class="dark" data-transition="zoomout" data-slotamount="1" data-masterspeed="1500"  data-saveperformance="off" >
                                <!-- MAIN IMAGE -->
                                <img src="images/slider/sl_bg.jpg"  alt="citybg" data-lazyload="images/slider/sl_bg.jpg" data-bgposition="center top" data-bgfit="cover" data-bgrepeat="no-repeat">
                                <!-- LAYERS -->

                                <!-- LAYER NR. 1 -->
                                <div class="tp-caption customin ltl tp-resizeme"
                                     data-x="640"
                                     data-y="45"
                                     data-customin="x:250;y:0;z:0;rotationZ:0;scaleX:1;scaleY:1;skewX:0;skewY:0;opacity:0;transformPerspective:200;transformOrigin:50% 0%;"
                                     data-speed="400"
                                     data-start="1000"
                                     data-easing="easeOutQuad"
                                     data-splitin="none"
                                     data-splitout="none"
                                     data-elementdelay="0.01"
                                     data-endelementdelay="0.1"
                                     data-endspeed="1000"
                                     data-endeasing="Power4.easeIn"><img style="width: 552px; height: 400px;" src="images/slider/3.png" alt="imac"></div>
									 
                                <div class="tp-caption customin ltl tp-resizeme revo-slider-emphasis-text nopadding noborder"
                                     data-x="-3"
                                     data-y="70"
                                     data-customin="x:0;y:150;z:0;rotationZ:0;scaleX:1;scaleY:1;skewX:0;skewY:0;opacity:0;transformPerspective:200;transformOrigin:50% 0%;"
                                     data-speed="800"
                                     data-start="1200"
                                     data-easing="easeOutQuad"
                                     data-splitin="none"
                                     data-splitout="none"
                                     data-elementdelay="0.01"
                                     data-endelementdelay="0.1"
                                     data-endspeed="1000"
                                     data-endeasing="Power4.easeIn" style="font-size: 27px; line-height:30px; color:#000;"><br>myVisitor simplifies visitor management</div>

                                <div class="tp-caption customin ltl tp-resizeme revo-slider-desc-text tleft"
                                     data-x="0"
                                     data-y="140"
                                     data-customin="x:0;y:150;z:0;rotationZ:0;scaleX:1;scaleY:1;skewX:0;skewY:0;opacity:0;transformPerspective:200;transformOrigin:50% 0%;"
                                     data-speed="800"
                                     data-start="1400"
                                     data-easing="easeOutQuad"
                                     data-splitin="none"
                                     data-splitout="none"
                                     data-elementdelay="0.01"
                                     data-endelementdelay="0.1"
                                     data-endspeed="1000"
                                     data-endeasing="Power4.easeIn" style="max-width: 550px; white-space: normal; color:#000;">Hosts can generate pre-registration which will send QR code to visitor for quick  sign in</div>

                                
                            </li>
                            <li class="dark" data-transition="zoomout" data-slotamount="1" data-masterspeed="1500" data-saveperformance="off">
                                <!-- MAIN IMAGE -->
                                <img src="images/slider/sl_bg2.jpg"  alt="kenburns6"  data-bgposition="left bottom" data-kenburns="on" data-duration="20000" data-ease="Linear.easeNone" data-bgfit="100" data-bgfitend="120" data-bgpositionend="right top">
                                <!-- LAYERS -->
                                <div class="tp-caption customin"
                                     data-x="0"
                                     data-y="45"
                                     data-customin="x:0;y:0;z:0;rotationZ:0;scaleX:0.6;scaleY:0.6;skewX:0;skewY:0;opacity:0;transformPerspective:0;transformOrigin:50% 50%;"
                                     data-speed="850"
                                     data-start="1200"
                                     data-easing="easeOutQuad"
                                     data-splitin="none"
                                     data-splitout="none"
                                     data-elementdelay="0.01"
                                     data-endelementdelay="0.1"
                                     data-endspeed="1000"
                                     data-endeasing="Power4.easeIn">
                                    <img style="width: 465px; height: 400px;" src="images/slider/4.png" alt="uims">
                                </div>

                                <div class="tp-caption customin ltl tp-resizeme revo-slider-emphasis-text nopadding noborder"
                                     data-x="672"
                                     data-y="90"
                                     data-customin="x:140;y:0;z:0;rotationZ:0;scaleX:1;scaleY:1;skewX:0;skewY:0;opacity:0;transformPerspective:200;transformOrigin:50% 0%;"
                                     data-speed="800"
                                     data-start="1200"
                                     data-easing="easeOutQuad"
                                     data-splitin="none"
                                     data-splitout="none"
                                     data-elementdelay="0.01"
                                     data-endelementdelay="0.1"
                                     data-endspeed="1000"
                                     data-endeasing="Power4.easeIn" style="font-size: 27px; line-height:30px; color:#000;"><br>myVisitor Dashboard for monitoring</div>

                                <div class="tp-caption customin ltl tp-resizeme revo-slider-desc-text tleft"
                                     data-x="675"
                                     data-y="160"
                                     data-customin="x:140;y:0;z:0;rotationZ:0;scaleX:1;scaleY:1;skewX:0;skewY:0;opacity:0;transformPerspective:200;transformOrigin:50% 0%;"
                                     data-speed="800"
                                     data-start="1400"
                                     data-easing="easeOutQuad"
                                     data-splitin="none"
                                     data-splitout="none"
                                     data-elementdelay="0.01"
                                     data-endelementdelay="0.1"
                                     data-endspeed="1000"
                                     data-endeasing="Power4.easeIn" style="max-width: 550px; white-space: normal; color:#000;">Simple dashboard reports to monitor visitors real time</div>

                               
                            </li>
                        </ul>
                    </div>
                </div>

                <!-- END REVOLUTION SLIDER -->

            </section>

            <section id="content">
                <div class="promo promo-dark promo-flat promo-full">
                    <div class="container" style="overflow:hidden">
						<div class="row">
							<div class="col-md-8">
								<h3 style="float:left; margin-left:0px!important;">Learn how myVisitor can help you make your business more safer and efficient.</h3>
							</div>
							<div class="col-md-4">
								<a style="right:0px!important;margin:0px!important;" href="register.php" class="button button-xlarge button-rounded">Start your free trial now</a>
							</div>
						</div>
                    </div>
                </div>
            </section>
            <section id="content">

                <div class="content-wrap">
                    <div class="container clearfix">
					
						<div class="clear"></div>
						<div class="divider divider-short divider-center"></div>
                        <div id="section-features" class="heading-block title-center nobottomborder page-section">
							<h1>Just the right amount of functionality</h1>
							<span>Increase efficiency, optimize out-dated processes and improve security at the same time.</span>
                        </div>
					
                        <div class="pricing bottommargin">
                            <div class="col-sm-4">
                                &nbsp;&nbsp;
                                <div class="feature-box fbox-center fbox-effect">
                                    <div class="fbox-icon">
                                        <a href="#"><i class="icon-bell"></i></a>
                                    </div>
                                    <h3>Host Notifications</h3>
                                    <p>My Visitor sends automatic visitor notifications to the host via SMS, email and voice alerting them of their guest as well as their guest's pick-up location.</p>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                &nbsp;&nbsp;
                                <div class="feature-box fbox-center fbox-effect">
                                    <div class="fbox-icon">
                                        <a href="#"><i class="icon-large icon-file"></i></a>
                                    </div>
                                    <h3>Legal & Compliance</h3>
                                    <p>My Visitor makes it easy for guests to complete and submit legal documents digitally and for them to be available for efficient future look-ups.</p>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                &nbsp;&nbsp;
                                <div class="feature-box fbox-center fbox-effect">
                                    <div class="fbox-icon">
                                        <a href="#"><i class="icon-bullhorn2"></i></a>
                                    </div>
                                    <h3>Evacuation Mode</h3>
                                    <p>My Visitor assists during emergency evacuations by dispatching notifications to all employees letting them know that there is an evacuation in effect.</p>
                                </div>
                            </div>
                        </div>
                        <div class="pricing bottommargin">
                            <div class="col-sm-4">
                                &nbsp;&nbsp;
                                <div class="feature-box fbox-center fbox-effect">
                                    <div class="fbox-icon">
                                        <a href="#"><i class="icon-large icon-vcard"></i></a>
                                    </div>
                                    <h3>Visitor Badges</h3>
                                    <p>My Visitor prints custom visitor badges that help employees easily recognize visitors as well as their credentials, clearance levels and access durations.</p>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                &nbsp;&nbsp;
                                <div class="feature-box fbox-center fbox-effect">
                                    <div class="fbox-icon">
                                        <a href="#"><i class="icon-large icon-qrcode"></i></a>
                                    </div>
                                    <h3>QR Codes</h3>
                                    <p>Automatically-assigned QR codes let visitors re-use their previously-issued badge for a much quicker registration process on subsequent visits.</p>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                &nbsp;&nbsp;
                                <div class="feature-box fbox-center fbox-effect">
                                    <div class="fbox-icon">
                                        <a href="#"><i class="icon-large icon-camera"></i></a>
                                    </div>
                                    <h3>Visitor Image Capture</h3>
                                    <p>For security reasons, My Visitor automatically captures an image of every visitor to your facility and stores it within your customer portal for easy retrieval.</p>
                                </div>
                            </div>
                        </div>
                        <div class="pricing bottommargin">
                            <div class="col-sm-4">
                                &nbsp;&nbsp;
                                <div class="feature-box fbox-center fbox-effect">
                                    <div class="fbox-icon">
                                        <a href="#"><i class="icon-tasks"></i></a>
                                    </div>
                                    <h3>End-of-day Reports</h3>
                                    <p>My Visitor can quickly and automatically generate daily, weekly or monthly visitation reports using custom data points and with multiple export options.</p>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                &nbsp;&nbsp;
                                <div class="feature-box fbox-center fbox-effect">
                                    <div class="fbox-icon">
                                        <a href="#"><i class="icon-credit"></i></a>
                                    </div>
                                    <h3>Smart Pre-registrations</h3>
                                    <p>Hosts can generate pre-registrations to be automatically sent to their visitors including location and meeting details as well as a QR code for easy sign in.</p>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                &nbsp;&nbsp;
                                <div class="feature-box fbox-center fbox-effect">
                                    <div class="fbox-icon">
                                        <a href="#"><i class="icon-large icon-dribbble"></i></a>
                                    </div>
                                    <h3>Multilingual Ready </h3>
                                    <p>My Visitor can be translated into any language as well as offer multiple language options to visitors based on geographic location or visitor type.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div>
                        <div class="promo promo-center bottommargin">
                            <h3>More awesome features</h3>
                            <span>Easy to digest plans with room for customization in between</span>
                        </div>
                    </div>
                    <div class="section nobottommargin" style="padding-bottom: 0px;"> 
                        <div>
                            <!--<div class="content-wrap">-->
                            <div class="container clearfix">
							
								<div class="clear"></div>
								<div id="section-pricing" class="heading-block title-center nobottomborder page-section">
									<h1>Try myVisitor for free. Start paying when you're ready.</h1>
									<span>FULLY-FEATURED FOR 30 DAYS. NO CREDIT CARD REQUIRED. CHOOSE YOUR PLAN LATER</span>
									<a href="register.php" class="button button-xlarge button-rounded">Sign Up Now</a>
								</div>
							
                                <div class="pricing bottommargin clearfix">
                                    <div class="col-sm-4">

                                        <div class="pricing-box">
                                            <div class="pricing-title">
                                                <h3>Free</h3>
                                                <span style="color:#000">Perfect to get a taste of what myVisitor can do for a small office with one site.</span>
                                            </div>
                                            <div class="pricing-price">
                                                <span class="price-unit">$</span>0<span class="price-tenure">/mo</span>
                                            </div>
                                            <div class="pricing-features">
                                                <ul>
                                                    <li><strong>Email</strong> Support</li>  
                                                    <li><strong>Phone</strong> Support</li>   
                                                    <li><strong>Single</strong> Site Only</li>
                                                    <li><strong>1 Month</strong> Free</li>
                                                    <li class="notavailable"><strong>Unlimited</strong> User</li>
                                                    <li class="notavailable"><strong>Multi-Site</strong> Available</li>
                                                    <li class="notavailable"><strong>API</strong> Integrations</li>
                                                    <li class="notavailable"><strong>Evacuation</strong> Notification</li>
                                                    <li class="notavailable"><strong>Custom Logos</strong> and Branding</li>
                                                    <li class="notavailable"><strong>Dedicated</strong> Account Rep</li>
                                                </ul>
                                            </div>
                                            <div class="pricing-action">
                                                <a href="register.php" class="btn btn-danger btn-block btn-lg">Sign Up</a>
                                            </div>
                                        </div>

                                    </div>

                                    <div class="col-sm-4">

                                        <div class="pricing-box best-price">
                                            <div class="pricing-title">
                                                <h3>Corporate</h3>
                                                <span style="color:#000">Designed to meet the efficiency & security needs of multi-site businesses.</span>
                                            </div>
                                            <div class="pricing-price">
                                                <span class="price-unit">Contact</span>
                                            </div>
                                            <div class="pricing-features">
                                                <ul>
                                                    <li><strong>Email & Phone</strong> Support</li>
                                                    <li><strong>SMS & Voice</strong> Support</li>
                                                    <li><strong>Multi-Site</strong> Available</li>
                                                    <li><strong>Unlimited</strong> User</li>
                                                    <li><strong>API</strong> Integrations</li>
                                                    <li><strong>Visitor Image</strong> Capture</li>
                                                    <li><strong>Custom Logos</strong> and Branding</li>
                                                    <li><strong>Evacuation</strong> Notification</li>
                                                    <li>Support for<strong> Additional Languages</strong></li>
                                                    <li class="notavailable"><strong>Dedicated</strong> Account Rep</li>
                                                </ul>
                                            </div>
                                            <div class="pricing-action">
                                                <a href="/register.php" class="btn btn-danger btn-block btn-lg bgcolor border-color">Sign Up</a>
                                            </div>
                                        </div>

                                    </div>

                                    <div class="col-sm-4">

                                        <div class="pricing-box">
                                            <div class="pricing-title">
                                                <h3>Enterprise</h3>
                                                <span style="color:#000">A custom-made solution tailored to the needs and conditions of your enterprise.</span>
                                            </div>
                                            <div class="pricing-price">
                                                <span class="price-unit">Contact</span>
                                            </div>
                                            <div class="pricing-features">
                                                <ul>
                                                    <li><strong>Dedicated</strong> Account Rep</li>
                                                    <li><strong>Email & Phone</strong> Support</li>
                                                    <li><strong>SMS & Voice</strong> Support</li>
                                                    <li><strong>Multi-Site</strong> Available</li>
                                                    <li><strong>Unlimited</strong> User</li>
                                                    <li><strong>API</strong> Integrations</li>
                                                    <li><strong>Visitor Image</strong> Capture</li>
                                                    <li><strong>Custom Logos</strong> and Branding</li>
                                                    <li><strong>Evacuation</strong> Notification</li>
                                                    <li>Support for<strong> Additional Languages</strong></li>
                                                </ul>
                                            </div>
                                            <div class="pricing-action">
                                                <a href="register.php" class="btn btn-danger btn-block btn-lg">Sign Up</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div>
                                    <div class="promo promo-center bottommargin">
                                        <h3>Not sure which plan fits you best?</h3>
                                        <span>Take a look at the extensive feature list for a more detailed breakdown.</span>
                                        <a href="register.php" class="button button-xlarge button-rounded">Sign Up Now</a>
                                    </div>
                                </div>
                                <div class="pricing bottommargin clearfix">
                                    <div class="col-sm-4">

                                        <div class="feature-box fbox-effect">
                                            <div class="fbox-icon">
                                                <a href="#"><i class="icon-lock3"></i></a>
                                            </div>
                                            <h3>100% Scalable & Secure</h3>
                                            <p>Our platform was built with the intent to grow and adapt to ever-changing security measures.</p>
                                        </div>

                                    </div>
                                    <div class="col-sm-4">
                                        <div class="feature-box fbox-effect">
                                            <div class="fbox-icon">
                                                <a href="#"><i class="icon-plane"></i></a>
                                            </div>
                                            <h3>Robust Features & Functionality</h3>
                                            <p>Enjoy the benefits of a custom-feeling,form fitted platform without the development costs.</p>
                                        </div>
                                    </div>
                                    <div class="col-sm-4">
                                        <div class="feature-box fbox-effect">
                                            <div class="fbox-icon">
                                                <a href="#"><i class="icon-large icon-time"></i></a>
                                            </div>
                                            <h3>Fast & Friendly Support</h3>
                                            <p>We're here when you need us throughout the entire process - it's in our best interest too!</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="notopmargin nobottommargin">
                        <div class="container clearfix">
                            
							<div class="clear"></div>
							<div class="divider divider-short divider-center"></div>
							<div id="section-faq" class="heading-block title-center nobottomborder page-section">
								<h1>Frequently Asked Questions.</h1>
								<span>myVisitor is a Lobby Visitor Management System</span>
							</div>
							
                            <div id="faqs" class="faqs clearfix">
                                <div class="toggle faq faq-marketplace faq-authors">
                                    <div class="togglet fontSizeQuestions" style=""><i class="toggle-closed icon-plus-sign fontClrSize" style=""></i><i class="toggle-open icon-minus-sign fontClrSize" style=""></i> &nbsp;What is myVisitor?</div>
                                    <div class="togglec fontSizeAnswer" style="display: none;"> myVisitor is a new way of recording information about who is visiting, a replacement for a sign-in book sitting on the reception desk. It consists of a tablet (iPad or Android) that is used by a visitor to input their information. It then sends an email along with an instant message SMS/MMS to notify hosts that they have a visitor waiting. All the data is stored securely and can be accessed in the cloud.</div>
                                </div>
                                <div class="toggle faq faq-marketplace faq-authors">
                                    <div class="togglet fontSizeQuestions" style=""><i class="toggle-closed icon-plus-sign fontClrSize" style=""></i><i class="toggle-open icon-minus-sign fontClrSize" style=""></i> &nbsp;As a Host how will I know somebody is looking for me?</div>
                                    <div class="togglec fontSizeAnswer" style="display: none;"> You will get an email and if your cell/mobile number is loaded into myVisitor an SMS/MMS containing a notice with a picture of the "Visitor".</div>
                                </div>

                                <div class="toggle faq faq-marketplace faq-authors">
                                    <div class="togglet fontSizeQuestions" style=""><i class="toggle-closed icon-plus-sign fontClrSize" style=""></i><i class="toggle-open icon-minus-sign fontClrSize" style=""></i>&nbsp;What do I do if I am not in the building or available immediately?</div>
                                    <div class="togglec fontSizeAnswer" style="display: none; ">If you are unable to go and meet your visitor you need to either contact them directly (if you know their mobile phone number) or contact reception to ask them to relay your situation to your visitor.</div>
                                </div>

                                <div class="toggle faq faq-marketplace faq-authors">
                                    <div class="togglet fontSizeQuestions" style=""><i class="toggle-closed icon-plus-sign fontClrSize" style=""></i><i class="toggle-open icon-minus-sign fontClrSize" style=""></i>&nbsp;What do I do to add or change my phone number?</div>
                                    <div class="togglec fontSizeAnswer" style="display: none; ">In every email notification you receive from myVisitor there is a link 'here' that is individual and specific to you.</div>
                                </div>

                                <div class="toggle faq faq-marketplace faq-authors">
                                    <div class="togglet fontSizeQuestions" style=""><i class="toggle-closed icon-plus-sign fontClrSize" style=""></i><i class="toggle-open icon-minus-sign fontClrSize" style=""></i>&nbsp;Will the visitor see my mobile number?</div>
                                    <div class="togglec fontSizeAnswer" style="display: none;">No: myVisitor does not display any of your contact details, email or phone numbers. The visitor will only see your name and department when they search for you. Only you and a system administrator can see your contact details.</div>
                                </div>

                                <div class="toggle faq faq-marketplace faq-authors">
                                    <div class="togglet fontSizeQuestions" style=""><i class="toggle-closed icon-plus-sign fontClrSize" style=""></i><i class="toggle-open icon-minus-sign fontClrSize" style=""></i>&nbsp;Where is my information stored?</div>
                                    <div class="togglec fontSizeAnswer" style="display: none;">Your information is stored in the secure cloud at trackmyvisitor.com<br>
                                        Physically the servers are located in Bangladesh. myVisitor takes data privacy very seriously and is in compliance with all necessary regulations.</div>
                                </div>

                                <div class="toggle faq faq-marketplace faq-authors">
                                    <div class="togglet fontSizeQuestions" style=""><i class="toggle-closed icon-plus-sign fontClrSize" style=""></i><i class="toggle-open icon-minus-sign fontClrSize" style=""></i>&nbsp;Who has access to my Information?</div>
                                    <div class="togglec fontSizeAnswer" style="display: none;">Your information can only be accessed by you (via the link in any email you receive from the system) and the system administrators for your site.</div>
                                </div>

                                <div class="toggle faq faq-marketplace faq-authors">
                                    <div class="togglet fontSizeQuestions" style=""><i class="toggle-closed icon-plus-sign fontClrSize" style=""></i><i class="toggle-open icon-minus-sign fontClrSize" style=""></i>&nbsp;How long is data stored in myVisitor?</div>
                                    <div class="togglec fontSizeAnswer" style="display: none;">Information can be stored indefinitely or removed based how the platform is configured for your specific location.</div>
                                </div>

                                <div class="toggle faq faq-marketplace faq-authors">
                                    <div class="togglet fontSizeQuestions" style=""><i class="toggle-closed icon-plus-sign fontClrSize" style=""></i><i class="toggle-open icon-minus-sign fontClrSize" style=""></i>&nbsp;How is the information removed?</div>
                                    <div class="togglec fontSizeAnswer" style="display: none;">If requested, information (visitor access logs) can be purged from the Database using an automated rule.  Backups may contain the data for an additional period, as configured for the location.</div>
                                </div>
                                <div class="toggle faq faq-marketplace faq-authors">
                                    <div class="togglet fontSizeQuestions" style=""><i class="toggle-closed icon-plus-sign fontClrSize" style=""></i><i class="toggle-open icon-minus-sign fontClrSize" style=""></i>&nbsp;What happens at the end of the visit?</div>
                                    <div class="togglec fontSizeAnswer" style="display: none; ">To keep the visitor log up to date it is important that you encourage your visitor to sign-out at the end of their visit.
                                        You can press the Sign-out button displayed on the home screen on the device and enter the visitor's name to sign out.</div>
                                </div>
                                <div class="toggle faq faq-marketplace faq-authors">
                                    <div class="togglet fontSizeQuestions" style=""><i class="toggle-closed icon-plus-sign fontClrSize" style=""></i><i class="toggle-open icon-minus-sign fontClrSize" style=""></i>&nbsp;What happens if my visitor forgets to sign-out?</div>
                                    <div class="togglec fontSizeAnswer" style="display: none;">If so configured, you will receive an email notification asking you if the visitor is still at the facility. If the visitor is no longer at your facility, there is a link in the email you can click to automatically sign them out.</div>
                                </div>
                                <div class="toggle faq faq-marketplace faq-authors">
                                    <div class="togglet fontSizeQuestions" style=""><i class="toggle-closed icon-plus-sign fontClrSize" style=""></i><i class="toggle-open icon-minus-sign fontClrSize" style=""></i>&nbsp;What happens in an emergency or need to evacuate the building?</div>
                                    <div class="togglec fontSizeAnswer" style="display: none;">In the event of an evacuation, myVisitor can send you an email notification advising that there is an evacuation in effect. Visitor details will also be included in the notification to the Host as well as to the appointed Health and Safety Officer.</div>
                                </div>
                                <div class="toggle faq faq-marketplace faq-authors">
                                    <div class="togglet fontSizeQuestions" style=""><i class="toggle-closed icon-plus-sign fontClrSize" style=""></i><i class="toggle-open icon-minus-sign fontClrSize" style=""></i>&nbsp;If the system doesn't work what do I do?</div>
                                    <div class="togglec fontSizeAnswer" style="display: none;">For customer service and technical support, please call 01819295651. Support is also available by email at support@trackmyvisitor.com</div>
                                </div>
                                <div class="toggle faq faq-marketplace faq-authors">
                                    <div class="togglet fontSizeQuestions" style=""><i class="toggle-closed icon-plus-sign fontClrSize" style=""></i><i class="toggle-open icon-minus-sign fontClrSize" style=""></i>&nbsp;Where can I find out more about myVisitor?</div>
                                    <div class="togglec fontSizeAnswer" style="display: none;">You can email or call us at sales@trackmyvisitor.com, 01819295651. One of our friendly agents would be happy to answer all your questions.</div>
                                </div>
                            </div>
                            &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;  &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
                            <div class="pricing bottommargin clearfix">
                                <div class="col-sm-4">
                                    <div class="feature-box fbox-effect">
                                        <div class="fbox-icon">
                                            <a href="#"><i class="icon-lock3"></i></a>
                                        </div>
                                        <h3>100% Scalable & Secure</h3>
                                        <p>Our platform was built with the intent to grow and adapt to ever-changing security measures.</p>
                                    </div>

                                </div>
                                <div class="col-sm-4">
                                    <div class="feature-box fbox-effect">
                                        <div class="fbox-icon">
                                            <a href="#"><i class="icon-plane"></i></a>
                                        </div>
                                        <h3>Robust Features & Functionality</h3>
                                        <p>Enjoy the benefits of a custom-feeling,form fitted platform without the development costs.</p>
                                    </div>
                                </div>
                                <div class="col-sm-4">
                                    <div class="feature-box fbox-effect">
                                        <div class="fbox-icon">
                                            <a href="#"><i class="icon-large icon-time"></i></a>
                                        </div>
                                        <h3>Fast & Friendly Support</h3>
                                        <p>We're here when you need us throughout the entire process - it's in our best interest too!</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section><!-- #content end -->

            <!-- Footer
            ============================================= -->
            <?php include('footer.php'); ?>
            <!-- #footer end -->

        </div><!-- #wrapper end -->

        <!-- Go To Top
        ============================================= -->
        <div id="gotoTop" class="icon-angle-up"></div>

        <!-- Footer Scripts
        ============================================= -->
        <!-- External JavaScripts
        ============================================= -->
        <script type="text/javascript" src="js/jquery.js"></script>
        <script type="text/javascript" src="js/plugins.js"></script>	
        <script type="text/javascript" src="js/functions.js"></script>

        <script type="text/javascript" src="js/jquery.themepunch.tools.min.js"></script>
        <script type="text/javascript" src="js/jquery.themepunch.revolution.min.js"></script>

        <script type="text/javascript">
            jQuery(document).ready(function () {
                /*======Slider=======*/
                jQuery('.tp-banner').revolution(
                        {
                            //delay:9000,
                            delay: 6000,
                            startwidth: 1170,
                            startheight: 500,
                            hideThumbs: 10
                        });
                /*======end of Slider=======*/


                /*============step2============*/
                var $container = $('#portfolio');

                $container.isotope({transitionDuration: '0.65s'});

                $('#portfolio-filter a').click(function () {
                    $('#portfolio-filter li').removeClass('activeFilter');
                    $(this).parent('li').addClass('activeFilter');
                    var selector = $(this).attr('data-filter');
                    $container.isotope({filter: selector});
                    return false;
                });

                $('#portfolio-shuffle').click(function () {
                    $container.isotope('updateSortData').isotope({
                        sortBy: 'random'
                    });
                });

                $(window).resize(function () {
                    $container.isotope('layout');
                });
                /*============end of step2============*/
            });
            $("#widget-subscribe-form2").validate({
                submitHandler: function (form) {
                    $(form).find('.input-group-addon').find('.icon-email2').removeClass('icon-email2').addClass('icon-line-loader icon-spin');
                    $(form).ajaxSubmit({
                        target: '#widget-subscribe-form2-result',
                        success: function () {
                            $(form).find('.input-group-addon').find('.icon-line-loader').removeClass('icon-line-loader icon-spin').addClass('icon-email2');
                            $('#widget-subscribe-form2').find('.form-control').val('');
                            $('#widget-subscribe-form2-result').attr('data-notify-msg', $('#widget-subscribe-form2-result').html()).html('');
                            SEMICOLON.widget.notifications($('#widget-subscribe-form2-result'));
                        }
                    });
                }
            });

        </script>
        <style> 
            .promo-full a.button {
                right: -70px !important;
            }
            .promo.promo-dark h3 {
                margin-left: -81px !important;
            }
            .promo.promo-flat {
                background-color: #009933;
            }

            .fontClrSize{              
                color:#1abc9c;
            }
            .fontSizeQuestions{
                font-size:25px !important; 
            }
            .fontSizeAnswer{
                font-size:20px !important; 
            }
            .faqs .toggle .togglet i {
                font-size: 25px;
                top: 1px;
            }
            .notavailable{
                text-decoration: line-through;
            }
        </style>
    </body>
</html>