var lan = 'en';
var timeZone = 'Asia/Dhaka';
var $ = jQuery.noConflict();

function resetForm(id) {
    $('#' + id).each(function () {
        this.reset();
    });
}

function validateEmail(email) {
    var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return re.test(email);
}

function onConfirmWhenRegister() {

    var FirstName = $("#FirstName").val();
    var LastName = $("#LastName").val();
    var Email = $("#EmailAddress").val();
    var CompanyName = $("#CompanyName").val();
    var MobileNo = $("#MobileNo").val();

    var LanguageTitle = $("#LanguageTitle").val();
    var TimeZone = $("#TimeZone").val();

    var LanguageTitleText = $("#LanguageTitle option:selected").text();
    $("#LanTitleText").val(LanguageTitleText);

    var error = 0;

    if (FirstName == '') {
        $("#invalidFirstName").html('Please enter First Name');
        error = 1;
    } else {
        $("#invalidFirstName").html('');
    }

    if (LastName == '') {
        $("#invalidLastName").html('Please enter Last Name');
        error = 1;
    } else {
        $("#invalidLastName").html('');
    }

    if (Email == '') {
        $("#invalidEmail").html('Please enter your email address');
        error = 1;
    } else if (!validateEmail(Email)) {
        $("#invalidEmail").html('Please enter valid email address');
        error = 1;
    } else {
        $("#invalidEmail").html('');
    }

    if (CompanyName == '') {
        $("#invalidCompany").html('Please enter company name');
        error = 1;
    } else {
        $("#invalidCompany").html('');
    }

    if (MobileNo == '') {
        $("#invalidMobileNo").html('Please enter Phone Number');
        error = 1;
    } else {
        $("#invalidMobileNo").html('');
    }

    if (LanguageTitle == '') {
        $("#invalidLanguageTitle").html('Please Select Language');
        error = 1;
    } else {
        $("#invalidLanguageTitle").html('');
    }

    if (TimeZone == '') {
        $("#invalidTimeZone").html('Please Select Time Zone');
        error = 1;
    } else {
        $("#invalidTimeZone").html('');
    }

   if (grecaptcha.getResponse() == "") {
       $("#invalidReCaptcha").html('Please select captcha');
       error = 1;
   } else {
       $("#invalidReCaptcha").html('');
   }

    if (error == 1) {
        return false;
    }
    else {
        $.ajax({
            "async": true,
            url: baseUrl + "employee-registration-web",
            "method": "POST",
            "data": $('#register-form').serialize(),
            success: function (response) {
                if (response['error'] == 0) {
                    $("#registerformsuccess").show();
                    $("#registerform").hide();
                    resetForm("register-form");
                } else if (response['error'] == 2) {
                    $("#registerform").show();
                    $("#registerformsuccess").hide();
                    $("#invalidCompany").html(response['message']);

                } else if (response['error'] == 3) {
                    $("#registerform").show();
                    $("#registerformsuccess").hide();
                    $("#invalidEmail").html(response['message']);

                } else if (response['error'] == 4) {
                    $("#registerform").show();
                    $("#registerformsuccess").hide();
                    $("#invalidReCaptcha").html(response['message']);

                } else {
                    $("#registerform").show();
                    $("#registerformsuccess").hide();
                    //$("#invalidEmail").html(response['message']);
                }
            }
        });
    }
}

$(function () {
    loadLanguageDropdown();
    loadTimeZoneDropdown();

    $('#register-form').submit(function () {
        onConfirmWhenRegister();
        return false;
    });
    //alert(timeZone);

});
function loadLanguageDropdown() {
    $.ajax({
        "async": true,
        url: baseUrl + "register-language-combo-load",
        "method": "GET",
        success: function (response)
        {
            response = response['LanguageList'];
            var count = response.length;
            if (count > 0) {
                $.each(response, function (key, value) {
                    $('#LanguageTitle').append($('<option></option>').val(value.LangCode).html(value.LangTitle));
                });
                $('#LanguageTitle').val(lan);
            }
            else {
                $('#LanguageTitle').val('');
            }
            ;
        }

    });

}
function loadTimeZoneDropdown() {
    $.ajax({
        "async": true,
        url: baseUrl + "register-time-zone-combo-load",
        "method": "GET",
        success: function (response)
        {
            response = response['TimeZoneList'];
            var count = response.length;
            if (count > 0) {
                $.each(response, function (key, value) {
                    $('#TimeZone').append($('<option></option>').val(value.TimeZoneId).html(value.TimeZoneName));
                });
                $('#TimeZone').val(timeZone);
            }
            else {
                $('#TimeZone').val('');
            }
        }

    });
}
