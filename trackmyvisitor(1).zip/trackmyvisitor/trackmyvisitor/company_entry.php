<!DOCTYPE html>
<html dir="ltr" lang="en-US">
    <head>

        <meta http-equiv="content-type" content="text/html; charset=utf-8" />
        <meta name="author" content="SemiColonWeb" />

        <!-- Stylesheets
        ============================================= -->
        <link href="http://fonts.googleapis.com/css?family=Lato:300,400,400italic,600,700|Raleway:300,400,500,600,700|Crete+Round:400italic" rel="stylesheet" type="text/css" />
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"/> 


        <link  rel="stylesheet"  href="chosen/bootstrap-chosen.css" type="text/css"/>


        <link rel="stylesheet" href="css/bootstrap.css" type="text/css" />
        <link rel="stylesheet" href="style.css" type="text/css" />
        <link rel="stylesheet" href="css/dark.css" type="text/css" />
        <link rel="stylesheet" href="css/font-icons.css" type="text/css" />
        <link rel="stylesheet" href="css/animate.css" type="text/css" />
        <link rel="stylesheet" href="css/magnific-popup.css" type="text/css" />

        <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/font-awesome/4.2.0/css/font-awesome.min.css">

        <link rel="stylesheet" href="css/jquery-ui.css" type="text/css" />
        <link rel="stylesheet" href="css/responsive.css" type="text/css" />
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
        <link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon">
        <link rel="icon" href="images/favicon.ico" type="image/x-icon">


        <!--[if lt IE 9]>
            <script src="http://css3-mediaqueries-js.googlecode.com/svn/trunk/css3-mediaqueries.js"></script>
        <![endif]-->

        <!-- Document Title
        ============================================= -->
        <title>Track My Visitor - My Settings</title>
        <?php include('global_variables.php'); ?>
        <script>
            if (APIKEY != '' && COMPANYID != '' && ISCOMPANYADMIN == 1) {
            } else {
                window.location = "login.php?redirect_to=dashboard.php";
            }
			<?php include('baseurl.php'); ?>
            var baseUrl = '<?php echo $BaseUrl; ?>';
            var ImageUrl = '<?php echo $ImageUrl; ?>';
            //alert(ImageUrl);
        </script>		
    </head>

    <body class="stretched">

        <!-- Document Wrapper
        ============================================= -->
        <div id="wrapper" class="clearfix">

            <!-- Header
            ============================================= -->
            <?php include('header.php'); ?>
            <!-- #header end -->
            <!-- Content
            ============================================= -->
            <section id="content">
                <div class="content-wrap">
                    <div class="container clearfix">
                        <div class="row">
                            <div class="col-md-12">
                                <div id="myModal" class="modal fade" role="dialog">
                                    <div class="modal-dialog">
                                        <!-- Modal content-->
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <button type="button" class="close" data-dismiss="modal">&times;</button>
                                                <h4 class="modal-title">Message</h4>
                                            </div>
                                            <div class="modal-body" id="MessageShow">

                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <form id="company_add_form" name="company_add_form" class="nobottommargin" method="post">
                                    <div class="col-md-3">
                                        <div class="nobottommargin">
                                            <button class="button button-3d button-black nomargin" id="" name="" value="" onclick="MySettings()">My Settings</button>
                                        </div>             
                                    </div>
                                    <div class="col-md-7">
                                        <div class="row"> 
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label for="register-form-name">Company Name*</label>
                                                    <input type="text" id="CompanyName" name="CompanyName" value="" class="form-control" />
                                                    <em class="invalid" id="CompanyNameVal"></em>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                            </div>
                                        </div>
                                        <div class="row"> 
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label for="register-form-name">Company Logo</label>
                                                    <div class="dummyComapnyLogo" data-toggle="modal" data-target="#myModalLogo">
                                                        <img src="images/d_logo.jpg" alt="Upload Image" height="120" width="125" style="cursor:pointer">
                                                    </div>
                                                    <div class="originalComapnyLogo" data-toggle="modal" data-target="#myModalLogo" style="cursor:pointer">

                                                    </div>
                                                </div>
                                            </div>
                                            <div class="modal fade" id="myModalLogo" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                                                <div class="modal-dialog" role="document">
                                                    <div class="modal-content">
                                                        <div class="modal-body">
                                                            <div class="col-md-12">
                                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                    <span aria-hidden="true">&times;</span>
                                                                </button>
                                                                <div class="form-group" id="">
                                                                    <label for="register-form-name">Company Logo</label>
                                                                    <input id="stock-input" name="stock-input-file" type="file" class="file-loading" accept=".jpg, .png, .gif, .ico">
                                                                </div>
                                                            </div>
                                                            <div class="">
                                                                <div class="form-group">                                                        
                                                                    <input type="hidden" id="LogoName" name="LogoName" value="" class="form-control" style="cursor:pointer"/>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                            <button type="button" class="btn btn-primary">Save changes</button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6">

                                            </div>
                                        </div>
                                        <div class="row"> 
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label for="register-form-name">Phone*</label>
                                                    <input type="text" id="Phone" name="Phone" value="" class="form-control" />
                                                    <em class="invalid" id="PhoneVal"></em>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                            </div>
                                        </div>
                                        <div class="row"> 
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label for="register-form-name">Email*</label>
                                                    <input type="text" id="Email" name="Email" value="" class="form-control" />
                                                    <em class="invalid" id="EmailVal"></em>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <label for="">Supported Language</label>
                                                <div class="form-group">
                                                    <select id="LanguageTitle" class="chosen-select"  data-placeholder="Choose a Language"  multiple tabindex="4"> 
                                                    </select>
                                                    <em class="invalid" id="SupportLanVal"></em>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label for="CompanyEntry">Default Language*</label>
                                                    <select class="form-control" id="DefaultLanguage" name="DefaultLanguage"> 
                                                    </select>
                                                    <em class="invalid" id="DefaultLanVal"></em>
                                                </div>
                                            </div>
                                            <div class="col-md-6">

                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label for="CompanyEntry">Time Zone*</label>
                                                    <select class="form-control" id="TimeZone" name="TimeZone"> 
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-md-6">

                                            </div>
                                        </div>
                                        <div class="row"> 
                                            <input type="text" id="RecordId" name="RecordId" style="display: none;"/>
                                            <div class="col-md-1 nobottommargin">                                               
                                                <input type="submit" value="Save" class="button button-3d button-black nomargin btn-form-login"  onClick="onConfirmWhenComapnyAdd()">
                                            </div>
                                        </div>  
                                        <div class="row"> 
                                            <div class="col-md-4">
                                            </div>
                                            <div class="col-md-8 nobottommargin" id="EmployeeAddMessage">                                               
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
						
						<div class="row"> 
                            <div style="float: left; margin-bottom: -10px;margin-left: 12px"><h3>Language Settings</h3></div>
                            <div class="col-md-12">
                                <div class="tabs tabs-alt tabs-tb clearfix ui-tabs ui-widget ui-widget-content ui-corner-all" id="tab-8">
									<ul class="tab-nav clearfix" id="TabNavbar"></ul>
									<div class="tab-container" id="TableTabs">
									
									</div>
                                </div>
								
                            </div>
                        </div>
						
						
                        <!--<div class="row"> 
                            <div style="float: left; margin-bottom: -10px;margin-left: 12px"><h3>Language Settings</h3></div>
                            <div class="col-md-12">
							<div class="tabs tabs-alt tabs-tb clearfix">
								<ul class="tab-nav clearfix" id="TabNavbar"></ul>
								<div class="tab-container" id="TableTabs"></div>
							</div>
                            </div>
                        </div>-->
						
                    </div>
                </div>
            </section><!-- #content end aa -->
            <!-- Footer
        ============================================= -->
            <?php include('footer.php'); ?>
            <!-- #footer end -->
        </div>


    </div><!-- #wrapper end -->

    <!-- Go To Top
    ============================================= -->
    <div id="gotoTop" class="icon-angle-up"></div>


    <!-- External JavaScripts
    ============================================= -->

    <script type="text/javascript" src="js/jquery.js"></script>
    <script type="text/javascript" src="js/plugins.js"></script>
    <script type="text/javascript" src="js/jquery-ui.js"></script>


    <script>
	var $ = jQuery.noConflict();
	// var COMPANYID = sessionStorage.getItem("COMPANYID");
	// alert(COMPANYID);
    </script>

    <!-- Footer Scripts
    ============================================= -->
    <link  rel="stylesheet"  href="css/fileinput.css" type="text/css"/>
    <script type="text/javascript" src="js/fileinput.js"></script>
    <script type="text/javascript" src="js/functions.js"></script>
    <link href="//cdnjs.cloudflare.com/ajax/libs/x-editable/1.5.0/bootstrap3-editable/css/bootstrap-editable.css" rel="stylesheet"/>
    <script src="//cdnjs.cloudflare.com/ajax/libs/x-editable/1.5.0/bootstrap3-editable/js/bootstrap-editable.min.js"></script>
    <script type="text/css" src="css/bootstrap-combined.min.css"></script>
    <script type="text/javascript" src="js/jquery.mockjax.js"></script>

    <script type="text/javascript" src="company_entry.js"></script>
    <script type="text/javascript" src="js/moment.js"></script>
    <script type="text/javascript" src="chosen/chosen.jquery.js"></script>
    <script type="text/javascript" src="js/underscore-min.js"></script>
    
    <style>

        .AddNewCompany{
            padding-bottom: 10px;
        }
        .AllCompany{
            padding-bottom: 10px;
        }

        /*        .chosen-container, .search-field input{
            width:100% !important;
        }*/
    </style>
</body>
</html>