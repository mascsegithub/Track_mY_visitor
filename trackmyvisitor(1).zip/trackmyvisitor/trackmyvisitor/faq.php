<!DOCTYPE html>
<html dir="ltr" lang="en-US">
    <head>

        <meta http-equiv="content-type" content="text/html; charset=utf-8" />
        <meta name="author" content="SemiColonWeb" />
        <!-- Stylesheets
        ============================================= -->
        <link href="http://fonts.googleapis.com/css?family=Lato:300,400,400italic,600,700|Raleway:300,400,500,600,700|Crete+Round:400italic" rel="stylesheet" type="text/css" />
        <link rel="stylesheet" href="css/bootstrap.css" type="text/css" />
        <link rel="stylesheet" href="style.css" type="text/css" />
        <link rel="stylesheet" href="css/dark.css" type="text/css" />
        <link rel="stylesheet" href="css/font-icons.css" type="text/css" />
        <link rel="stylesheet" href="css/animate.css" type="text/css" />
        <link rel="stylesheet" href="css/magnific-popup.css" type="text/css" />
        <link rel="stylesheet" href="css/responsive.css" type="text/css" />
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />

        <link rel="stylesheet" type="text/css" href="css/settings.css" media="screen" />
        <link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon">
        <link rel="icon" href="images/favicon.ico" type="image/x-icon">
        <!--[if lt IE 9]>
            <script src="http://css3-mediaqueries-js.googlecode.com/svn/trunk/css3-mediaqueries.js"></script>
        <![endif]-->
        <!-- Document Title
        ============================================= -->
        <title>FAQ - Track myVisitor</title>
        <?php include('global_variables.php'); ?>

    </head>

    <body class="stretched">
        <!-- Document Wrapper
        ============================================= -->
        <div id="wrapper" class="clearfix">
            <!-- Header
            ============================================= -->
            <?php include('header.php'); ?>
            <!-- #header end -->
            <!-- Content
            ============================================= -->
            <section id="content">

                <!--                 <div class="content-wrap">-->
                <div class="">

                    <div class="container clearfix">
                        <div class="pricing clearfix">
                            <div class="promo  promo-center">
                                <h3>Frequently Asked Questions.</h3>
                                <span>myVisitor is a Lobby Visitor Management System</span>
                            </div>
                        </div>
                        <div id="faqs" class="faqs clearfix">
                            <div class="toggle faq faq-marketplace faq-authors">
                                <div class="togglet fontSizeQuestions" style=""><i class="toggle-closed icon-plus-sign fontClrSize" style=""></i><i class="toggle-open icon-minus-sign fontClrSize" style=""></i> &nbsp;What is myVisitor?</div>
                                <div class="togglec fontSizeAnswer" style="display: none;"> myVisitor is a new way of recording information about who is visiting, a replacement for a sign-in book sitting on the reception desk. It consists of a tablet (iPad or Android) that is used by a visitor to input their information. It then sends an email along with an instant message SMS/MMS to notify hosts that they have a visitor waiting. All the data is stored securely and can be accessed in the cloud.</div>
                            </div>
                            <div class="toggle faq faq-marketplace faq-authors">
                                <div class="togglet fontSizeQuestions" style=""><i class="toggle-closed icon-plus-sign fontClrSize" style=""></i><i class="toggle-open icon-minus-sign fontClrSize" style=""></i> &nbsp;As a Host how will I know somebody is looking for me?</div>
                                <div class="togglec fontSizeAnswer" style="display: none;"> You will get an email and if your cell/mobile number is loaded into myVisitor an SMS/MMS containing a notice with a picture of the "Visitor".</div>
                            </div>

                            <div class="toggle faq faq-marketplace faq-authors">
                                <div class="togglet fontSizeQuestions" style=""><i class="toggle-closed icon-plus-sign fontClrSize" style=""></i><i class="toggle-open icon-minus-sign fontClrSize" style=""></i>&nbsp;What do I do if I am not in the building or available immediately?</div>
                                <div class="togglec fontSizeAnswer" style="display: none; ">If you are unable to go and meet your visitor you need to either contact them directly (if you know their mobile phone number) or contact reception to ask them to relay your situation to your visitor.</div>
                            </div>

                            <div class="toggle faq faq-marketplace faq-authors">
                                <div class="togglet fontSizeQuestions" style=""><i class="toggle-closed icon-plus-sign fontClrSize" style=""></i><i class="toggle-open icon-minus-sign fontClrSize" style=""></i>&nbsp;What do I do to add or change my phone number?</div>
                                <div class="togglec fontSizeAnswer" style="display: none; ">In every email notification you receive from myVisitor there is a link 'here' that is individual and specific to you.</div>
                            </div>

                            <div class="toggle faq faq-marketplace faq-authors">
                                <div class="togglet fontSizeQuestions" style=""><i class="toggle-closed icon-plus-sign fontClrSize" style=""></i><i class="toggle-open icon-minus-sign fontClrSize" style=""></i>&nbsp;Will the visitor see my mobile number?</div>
                                <div class="togglec fontSizeAnswer" style="display: none;">No: myVisitor does not display any of your contact details, email or phone numbers. The visitor will only see your name and department when they search for you. Only you and a system administrator can see your contact details.</div>
                            </div>

                            <div class="toggle faq faq-marketplace faq-authors">
                                <div class="togglet fontSizeQuestions" style=""><i class="toggle-closed icon-plus-sign fontClrSize" style=""></i><i class="toggle-open icon-minus-sign fontClrSize" style=""></i>&nbsp;Where is my information stored?</div>
                                <div class="togglec fontSizeAnswer" style="display: none;">Your information is stored in the secure cloud at trackmyvisitor.com<br>
                                    Physically the servers are located in Bangladesh. myVisitor takes data privacy very seriously and is in compliance with all necessary regulations.</div>
                            </div>

                            <div class="toggle faq faq-marketplace faq-authors">
                                <div class="togglet fontSizeQuestions" style=""><i class="toggle-closed icon-plus-sign fontClrSize" style=""></i><i class="toggle-open icon-minus-sign fontClrSize" style=""></i>&nbsp;Who has access to my Information?</div>
                                <div class="togglec fontSizeAnswer" style="display: none;">Your information can only be accessed by you (via the link in any email you receive from the system) and the system administrators for your site.</div>
                            </div>

                            <div class="toggle faq faq-marketplace faq-authors">
                                <div class="togglet fontSizeQuestions" style=""><i class="toggle-closed icon-plus-sign fontClrSize" style=""></i><i class="toggle-open icon-minus-sign fontClrSize" style=""></i>&nbsp;How long is data stored in myVisitor?</div>
                                <div class="togglec fontSizeAnswer" style="display: none;">Information can be stored indefinitely or removed based how the platform is configured for your specific location.</div>
                            </div>

                            <div class="toggle faq faq-marketplace faq-authors">
                                <div class="togglet fontSizeQuestions" style=""><i class="toggle-closed icon-plus-sign fontClrSize" style=""></i><i class="toggle-open icon-minus-sign fontClrSize" style=""></i>&nbsp;How is the information removed?</div>
                                <div class="togglec fontSizeAnswer" style="display: none;">If requested, information (visitor access logs) can be purged from the Database using an automated rule.  Backups may contain the data for an additional period, as configured for the location.</div>
                            </div>
                            <div class="toggle faq faq-marketplace faq-authors">
                                <div class="togglet fontSizeQuestions" style=""><i class="toggle-closed icon-plus-sign fontClrSize" style=""></i><i class="toggle-open icon-minus-sign fontClrSize" style=""></i>&nbsp;What happens at the end of the visit?</div>
                                <div class="togglec fontSizeAnswer" style="display: none; ">To keep the visitor log up to date it is important that you encourage your visitor to sign-out at the end of their visit.
                                    You can press the Sign-out button displayed on the home screen on the device and enter the visitor's name to sign out.</div>
                            </div>
                            <div class="toggle faq faq-marketplace faq-authors">
                                <div class="togglet fontSizeQuestions" style=""><i class="toggle-closed icon-plus-sign fontClrSize" style=""></i><i class="toggle-open icon-minus-sign fontClrSize" style=""></i>&nbsp;What happens if my visitor forgets to sign-out?</div>
                                <div class="togglec fontSizeAnswer" style="display: none;">If so configured, you will receive an email notification asking you if the visitor is still at the facility. If the visitor is no longer at your facility, there is a link in the email you can click to automatically sign them out.</div>
                            </div>
                            <div class="toggle faq faq-marketplace faq-authors">
                                <div class="togglet fontSizeQuestions" style=""><i class="toggle-closed icon-plus-sign fontClrSize" style=""></i><i class="toggle-open icon-minus-sign fontClrSize" style=""></i>&nbsp;What happens in an emergency or need to evacuate the building?</div>
                                <div class="togglec fontSizeAnswer" style="display: none;">In the event of an evacuation, myVisitor can send you an email notification advising that there is an evacuation in effect. Visitor details will also be included in the notification to the Host as well as to the appointed Health and Safety Officer.</div>
                            </div>
                            <div class="toggle faq faq-marketplace faq-authors">
                                <div class="togglet fontSizeQuestions" style=""><i class="toggle-closed icon-plus-sign fontClrSize" style=""></i><i class="toggle-open icon-minus-sign fontClrSize" style=""></i>&nbsp;If the system doesn't work what do I do?</div>
                                <div class="togglec fontSizeAnswer" style="display: none;">For customer service and technical support, please call 01819295651. Support is also available by email at support@trackmyvisitor.com</div>
                            </div>
                            <div class="toggle faq faq-marketplace faq-authors">
                                <div class="togglet fontSizeQuestions" style=""><i class="toggle-closed icon-plus-sign fontClrSize" style=""></i><i class="toggle-open icon-minus-sign fontClrSize" style=""></i>&nbsp;Where can I find out more about myVisitor?</div>
                                <div class="togglec fontSizeAnswer" style="display: none;">You can email or call us at sales@trackmyvisitor.com, 01819295651. One of our friendly agents would be happy to answer all your questions.</div>
                            </div>
                        </div>
                        &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;  &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
                        <div class="pricing bottommargin clearfix">
                            <div class="col-sm-4">
                                <div class="feature-box fbox-effect">
                                    <div class="fbox-icon">
                                        <a href="#"><i class="icon-lock3"></i></a>
                                    </div>
                                    <h3>100% Scalable & Secure</h3>
                                    <p>Our platform was built with the intent to grow and adapt to ever-changing security measures.</p>
                                </div>

                            </div>
                            <div class="col-sm-4">
                                <div class="feature-box fbox-effect">
                                    <div class="fbox-icon">
                                        <a href="#"><i class="icon-plane"></i></a>
                                    </div>
                                    <h3>Robust Features & Functionality</h3>
                                    <p>Enjoy the benefits of a custom-feeling,form fitted platform without the development costs.</p>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="feature-box fbox-effect">
                                    <div class="fbox-icon">
                                        <a href="#"><i class="icon-large icon-time"></i></a>
                                    </div>
                                    <h3>Fast & Friendly Support</h3>
                                    <p>We're here when you need us throughout the entire process - it's in our best interest too!</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section><!-- #content end -->
            <div style="" class="promo promo-dark promo-flat promo-full">
                <div class="container clearfix">
                    <h3>Learn how myVisitor can help you make your business safer and more efficient.</h3>
                    <a href="/register.php" class="button button-xlarge button-rounded">Get Started</a>
                </div>
            </div>
            <!-- Footer
            ============================================= -->
            <?php include('footer.php'); ?>

        </div><!-- #wrapper end -->

        <!-- Go To Top
        ============================================= -->
        <div id="gotoTop" class="icon-angle-up"></div>

        <!-- Footer Scripts
        ============================================= -->
        <script type="text/javascript" src="js/jquery.js"></script>
        <script type="text/javascript" src="js/plugins.js"></script>	
        <script type="text/javascript" src="js/functions.js"></script>

        <script type="text/javascript">
            $("#widget-subscribe-form").validate({
                submitHandler: function (form) {
                    $(form).find('.input-group-addon').find('.icon-email2').removeClass('icon-email2').addClass('icon-line-loader icon-spin');
                    $(form).ajaxSubmit({
                        target: '#widget-subscribe-form-result',
                        success: function () {
                            $(form).find('.input-group-addon').find('.icon-line-loader').removeClass('icon-line-loader icon-spin').addClass('icon-email2');
                            $('#widget-subscribe-form').find('.form-control').val('');
                            $('#widget-subscribe-form-result').attr('data-notify-msg', $('#widget-subscribe-form-result').html()).html('');
                            SEMICOLON.widget.notifications($('#widget-subscribe-form-result'));
                        }
                    });
                }
            });
        </script>
        <style>
            .fontClrSize{              
                color:#1abc9c;
            }
            .fontSizeQuestions{
                font-size:25px !important; 
            }
            .fontSizeAnswer{
                font-size:20px !important; 
            }
            .faqs .toggle .togglet i {
                font-size: 25px;
                top: 1px;
            }
        </style>
    </body>
</html>