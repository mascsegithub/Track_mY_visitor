<!DOCTYPE html>
<html dir="ltr" lang="en-US">
    <head>

        <meta http-equiv="content-type" content="text/html; charset=utf-8" />
        <meta name="author" content="SemiColonWeb" />

        <!-- Stylesheets
        ============================================= -->
        <link href="http://fonts.googleapis.com/css?family=Lato:300,400,400italic,600,700|Raleway:300,400,500,600,700|Crete+Round:400italic" rel="stylesheet" type="text/css" />
        <link rel="stylesheet" href="css/bootstrap.css" type="text/css" />
        <link rel="stylesheet" href="style.css" type="text/css" />
        <link rel="stylesheet" href="css/dark.css" type="text/css" />
        <link rel="stylesheet" href="css/font-icons.css" type="text/css" />
        <link rel="stylesheet" href="css/animate.css" type="text/css" />
        <link rel="stylesheet" href="css/magnific-popup.css" type="text/css" />
        <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/font-awesome/4.2.0/css/font-awesome.min.css">

        <link rel="stylesheet" href="css/jquery-ui.css" type="text/css" />
        <link rel="stylesheet" href="css/responsive.css" type="text/css" />

        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
        <link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon">
        <link rel="icon" href="images/favicon.ico" type="image/x-icon">
        <!--[if lt IE 9]>
            <script src="http://css3-mediaqueries-js.googlecode.com/svn/trunk/css3-mediaqueries.js"></script>
        <![endif]-->

        <!-- Document Title
        ============================================= -->
        <title>Track My Visitor - Visitor Type Entry</title>
        <?php include('global_variables.php'); ?>
        <script>
			if (APIKEY != '' && COMPANYID != '' && ISCOMPANYADMIN == 1) {
			}else{
				window.location = "login.php?redirect_to=dashboard.php";
			}
		<?php include('baseurl.php'); ?>
		var baseUrl = '<?php echo $BaseUrl; ?>';
        </script>
    </head>

    <body class="stretched">
        <!-- Document Wrapper
        ============================================= -->
        <div id="wrapper" class="clearfix">
            <!-- Header
            ============================================= -->
            <?php include('header.php'); ?>
            <!-- #header end -->
            <!-- Content
            ============================================= -->
            <section id="content">
                <div class="content-wrap">
                    <div class="container clearfix">
                        <div class="row">
                            <div id="myModal" class="modal fade" role="dialog">
                                <div class="modal-dialog">

                                    <!-- Modal content-->
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                                            <h4 class="modal-title">Message</h4>
                                        </div>
                                        <div class="modal-body" id="MessageShow">

                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                        </div>
                                    </div>

                                </div>
                            </div>
                            <div class="col-md-3" id="">
                                <div class="col_full nobottommargin AddNewVisitorType">
                                    <button class="button button-3d button-black nomargin" id="AddNewVisitorType" name="login-form-submit" value="add_employee">Add New Visitor Type</button>
                                </div>
                                <div class="col_full nobottommargin AllVisitorType" id="AllVisitorType">
                                    <button class="button button-3d button-black nomargin" id="login-form-submit" name="login-form-submit" value="login">Visitor Type List</button>
                                </div>             
                            </div>
                            <div class="col-md-7" id="">
                                <div id="AllVisitorTypeTable">                                  
                                </div>                              
                                <div id="VisitorTypeEntry" style="display:none;">
                                    <div class="col-xs-12">
                                        <form id="visitor_type_add_form" name="visitor_type_add_form" class="nobottommargin" method="post">
                                            <div class="row"> 
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label for="register-form-name">Visitor Type*</label>
                                                        <input type="text" id="VisitorType" name="VisitorType" value="" class="form-control" />
                                                        <em class="invalid" id="visitorTypeVal"></em>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                </div>
                                            </div>
                                            <div class="row"> 
                                                <input type="text" id="RecordId" name="RecordId" style="display: none;"/>
                                                <div class="col-md-5 nobottommargin">                                               
                                                    <input type="submit" value="Save" class="button button-3d button-black nomargin btn-form-login" onClick="onConfirmWhenVisitorTypeAdd()">
                                                     <a href="javascript:void(0);" class="button button-3d button-red nomargin" onClick="onListPanel()">Cancel</a>
                                                </div>
                                            </div>  
                                            <div class="row"> 
                                                <div class="col-md-4">
                                                </div>
                                                <div class="col-md-8 nobottommargin" id="EmployeeAddMessage">                                               
                                                </div>
                                            </div>
                                        </form>                                    

                                    </div>  
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

    </section><!-- #content end aa -->

    <!-- Footer
    ============================================= -->
    <?php include('footer.php'); ?>
    <!-- #footer end -->

</div><!-- #wrapper end -->

<!-- Go To Top
============================================= -->
<div id="gotoTop" class="icon-angle-up"></div>

<!-- External JavaScripts
============================================= -->
<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/plugins.js"></script>
<script type="text/javascript" src="js/jquery-ui.js"></script>

<script>
var $ = jQuery.noConflict();
// var COMPANYID = sessionStorage.getItem("COMPANYID");
// alert(COMPANYID);
</script>

<!-- Footer Scripts
============================================= -->
<link  rel="stylesheet"  href="css/fileinput.css" type="text/css"/>
<script type="text/javascript" src="js/fileinput.js"></script>
<script type="text/javascript" src="js/functions.js"></script>
<script type="text/javascript" src="visitor_type_entry.js"></script>
<script type="text/javascript" src="js/moment.js"></script>

<style>

    .AddNewVisitorType{
        padding-bottom: 10px;
    }
    .AllVisitorType{
        padding-bottom: 10px;
    }

</style>
</body>
</html>