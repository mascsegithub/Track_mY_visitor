<!DOCTYPE html>
<html dir="ltr" lang="en-US">
    <head>

        <meta http-equiv="content-type" content="text/html; charset=utf-8" />
        <meta name="author" content="SemiColonWeb" />

        <!-- Stylesheets
        ============================================= -->
        <link href="http://fonts.googleapis.com/css?family=Lato:300,400,400italic,600,700|Raleway:300,400,500,600,700|Crete+Round:400italic" rel="stylesheet" type="text/css" />
        <link rel="stylesheet" href="css/bootstrap.css" type="text/css" />
        <link rel="stylesheet" href="style.css" type="text/css" />
        <link rel="stylesheet" href="css/dark.css" type="text/css" />
        <link rel="stylesheet" href="css/font-icons.css" type="text/css" />
        <link rel="stylesheet" href="css/animate.css" type="text/css" />
        <link rel="stylesheet" href="css/magnific-popup.css" type="text/css" />
        <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/font-awesome/4.2.0/css/font-awesome.min.css">
        <link rel="stylesheet" href="css/jquery-ui.css" type="text/css" />
        <link rel="stylesheet" href="css/responsive.css" type="text/css" />
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
        <link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon">
        <link rel="icon" href="images/favicon.ico" type="image/x-icon">
        <!--[if lt IE 9]>
        <script src="http://css3-mediaqueries-js.googlecode.com/svn/trunk/css3-mediaqueries.js"></script>
        <![endif]-->

        <!-- Document Title
        ============================================= -->
        <title>Track My Visitor - Authorize Visitor List</title>
        <?php
        include('global_variables.php');

        //echo 'http://'.$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF']);
        $httpsOrHttp = ((!empty($_SERVER['HTTPS'])) && ($_SERVER['HTTPS'] != 'off')) ? 'https' : 'http';
        ?>
        <script>

            if (APIKEY != '' && COMPANYID != '' && ISCOMPANYADMIN == 1) {
            } else {
                window.location = "login.php?redirect_to=dashboard.php";
            }
<?php include('baseurl.php'); ?>
            var baseUrl = '<?php echo $BaseUrl; ?>';
            var ImageUrl = '<?php echo $ImageUrl;?>';
            //var ImageUrl = "<?php //echo $httpsOrHttp . '://' . $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']); ?>";

        </script>
    </head>

    <body class="stretched">

        <!-- Document Wrapper
        ============================================= -->
        <div id="wrapper" class="clearfix">

            <!-- Header
            ============================================= -->
            <?php include('header.php'); ?>
            <!-- #header end -->
            <!-- Content
            ============================================= -->
            <section id="content">
                <div class="content-wrap">
                    <div class="container clearfix">
                        <div class="row">
                            <!-- Modal -->
                            <div class="modal fade" id="HostModal" role="dialog">
                                <div class="modal-dialog">
                                    <!-- Modal content-->
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                                            <h4 class="modal-title">Host</h4>
                                        </div>
                                        <div class="modal-body">
                                            <table id="HostInfo" class="table table-striped table-bordered display table-hover" cellspacing="0">
                                            </table>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                        </div>
                                    </div>

                                </div>
                            </div>
                            <!-- End Modal -->
                            <div id="msgModal" class="modal fade" role="dialog">
                                <div class="modal-dialog">

                                    <!-- Modal content-->
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                                            <h4 class="modal-title">Message</h4>
                                        </div>
                                        <div class="modal-body" id="MessageShow">

                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                        </div>
                                    </div>

                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="col_full nobottommargin AddSpecialVisitor">
                                    <button class="button button-3d button-black nomargin" id="AddSpecialVisitor" name="login-form-submit" value="add_employee">Add Authorize Visitor</button>
                                </div>
                                <div class="col_full nobottommargin AllHost" id="AllHost">
                                    <button class="button button-3d button-black nomargin" id="login-form-submit" name="login-form-submit" value="login">Authorize Visitor List</button>
                                </div>

                            </div>
                            <div class="col-md-9">    
                                <div id="VisitorList">                          
                                    <h3>Authorize Visitor List</h3>
                                    <div id="list-panel" class="">
                                        <table class="table table-striped table-bordered display table-hover" cellspacing="0">
                                            <thead>
                                                <tr>
                                                    <th style="text-align: left;width:7%;">Visitor Photo</th>
                                                    <th style="text-align: left;width:11%;">Visitor Details</th>
                                                    <th style="text-align: left;width:12%;">Email/Phone</th>
                                                    <th style="text-align: left;width:15%;">Event Name</th>
                                                    <th style="text-align: left;width:10%;">Host</th>
                                                    <th style="text-align: left;width:8%;">Appointment Date</th>
                                                    <th style="text-align: center;width:15%;">Action</th>
                                                </tr>
                                            </thead>
                                            <tbody id="AllVisitorInfoTable"></tbody>
                                        </table>			                   
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-7">
                                <div id="AddSpecialVisitorInfo" style="display:none;">
                                    <div class="col-md-12">
                                        <form id="employee_add_form" name="employee_add_form" class="nobottommargin" method="post" enctype="multipart/form-data">
                                            <div class="row"> 
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label for="register-form-name">Visitor Name*</label>
                                                        <input type="text" id="SpecialVisitorName" name="SpecialVisitorName" value="" class="form-control" />
                                                        <em class="invalid" id="invalidSpecialVisitorName"></em>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label for="register-form-name">Visitor Company*</label>
                                                        <input type="text" id="SpecialVisitorCompany" name="SpecialVisitorCompany" value="" class="form-control" />
                                                        <em class="invalid" id="invalidSpecialVisitorCompany"></em>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row"> 
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label for="register-form-name">E-Mail Address*</label>
                                                        <input type="text" id="EmailAddress" name="EmailAddress" value="" class="form-control"/>
                                                        <em class="invalid" id="invalidEmailAddress"></em>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label for="register-form-name">Visitor Type*</label>
                                                        <select class="form-control" id="VisitorTypeId" name="VisitorTypeId">
                                                        </select>
                                                        <em class="invalid" id="invalidVisitorTypeId"></em>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row"> 
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label for="register-form-name">Event Name*</label>
                                                        <select class="form-control" id="EventId" name="EventId">
                                                        </select>
                                                        <em class="invalid" id="invalidEventId"></em>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label for="register-form-name">Host*</label>
                                                        <select class="form-control" id="EmployeeId" name="EmployeeId">
                                                        </select>
                                                        <em class="invalid" id="invalidEmployeeId"></em>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row"> 
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label for="register-form-name">Appointment Date*</label>
                                                        <input type="text" id="AppointmentDate" name="AppointmentDate" value="" class="form-control" />
                                                        <em class="invalid" id="invalidAppointmentDate"></em>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label for="register-form-name">Phone*</label>
                                                        <input type="text" id="Phone" name="Phone" value="" class="form-control" />
                                                        <em class="invalid" id="invalidPhone"></em>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row"> 
                                                <div class="col-md-6 nobottommargin"> 
                                                    <div class="form-group">
                                                        <input type="hidden" id="RecordId" name="RecordId" value="0"/>
                                                        <input type="submit" value="Save" class="button button-3d button-black nomargin btn-form-login">
                                                        <a href="javascript:void(0);" class="button button-3d button-red nomargin" onClick="onListPanel()">Cancel</a>
                                                    </div>
                                                </div>
                                            </div>  
                                            <div class="row"> 
                                                <div class="col-md-4">
                                                </div>
                                                <div class="col-md-8 nobottommargin" id="AuthorizeVisitorAddMessage">                                               
                                                </div>
                                            </div>
                                        </form>                                    
                                    </div>  

                                </div>
                            </div>
                            <div class="col-md-2" id="PhotoArea">
                                <div class="dImage" data-toggle="modal" data-target="#myModal" style="cursor: pointer">
                                    <img src="images/em.jpg" alt="Upload Image" height="80" width="80">
                                </div>
                                <div class="OriginalImage" data-toggle="modal" data-target="#myModal" style="cursor: pointer; margin-left:5px;">
                                </div>
                                &nbsp;
                                <div> 
                                    <div id="QrCodeImage">
                                    </div>
                                </div>
                                <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                                    <div class="modal-dialog" role="document">
                                        <div class="modal-content">
                                            <div class="modal-body">
                                                <div class="col-md-12">
                                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                    </button>
                                                    <div class="form-group">
                                                        <label for="register-form-name">Visitor Photo</label>
                                                        <input id="stock-input" name="stock-input-file" type="file" class="file-loading" accept=".jpg, .png">
                                                    </div>
                                                </div>
                                                <div>
                                                    <div class="form-group">                                                        
                                                        <input type="hidden" id="ImageName" name="ImageName" value="" class="form-control" />
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

    </section><!-- #content end -->

    <!-- Footer
    ============================================= -->
    <?php include('footer.php'); ?>
    <!-- #footer end -->
</div><!-- #wrapper end -->

<!-- Go To Top
============================================= -->
<div id="gotoTop" class="icon-angle-up"></div>

<!-- External JavaScripts
============================================= -->
<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/plugins.js"></script>
<script type="text/javascript" src="js/jquery-ui.js"></script>

<!-- Footer Scripts
============================================= -->
<link  rel="stylesheet"  href="css/fileinput.css" type="text/css"/>
<script type="text/javascript" src="js/fileinput.js"></script>
<script type="text/javascript" src="js/functions.js"></script>
<script type="text/javascript" src="authorize_visitor_list.js"></script>
<script type="text/javascript" src="js/moment.js"></script>

<style>
    .AddSpecialVisitor{
        padding-bottom: 10px;
    }
    .AllHost{
        padding-bottom: 10px;
    }
    .checkbox label:after, 
    .radio label:after {
        content: '';
        display: table;
        clear: both;
    }

    .checkbox .cr,
    .radio .cr {
        position: relative;
        display: inline-block;
        border: 1px solid #a9a9a9;
        border-radius: .25em;
        width: 1.3em;
        height: 1.3em;
        float: left;
        margin-right: .5em;
    }

    .radio .cr {
        border-radius: 50%;
    }

    .checkbox .cr .cr-icon,
    .radio .cr .cr-icon {
        position: absolute;
        font-size: .8em;
        line-height: 0;
        top: 50%;
        left: 20%;
    }

    .radio .cr .cr-icon {
        margin-left: 0.04em;
    }

    .checkbox label input[type="checkbox"],
    .radio label input[type="radio"] {
        display: none;
    }

    .checkbox label input[type="checkbox"] + .cr > .cr-icon,
    .radio label input[type="radio"] + .cr > .cr-icon {
        transform: scale(3) rotateZ(-20deg);
        opacity: 0;
        transition: all .3s ease-in;
    }

    .checkbox label input[type="checkbox"]:checked + .cr > .cr-icon,
    .radio label input[type="radio"]:checked + .cr > .cr-icon {
        transform: scale(1) rotateZ(0deg);
        opacity: 1;
    }

    .checkbox label input[type="checkbox"]:disabled + .cr,
    .radio label input[type="radio"]:disabled + .cr {
        opacity: .5;
    }


</style>


</body>
</html>