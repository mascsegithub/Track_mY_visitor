<footer id="footer" class="dark">

    <div class="container">

        <!-- Footer Widgets
        ============================================= -->
        <div class="footer-widgets-wrap clearfix">
            <div class="col-md-5">
                <div class="widget clearfix">
                    <p>We believe in <strong>Simple</strong>, <strong>Creative</strong> &amp; <strong>Flexible</strong> Software Design and Development Standards.</p>
                    <div style="background: url('images/world-map.png') no-repeat center center; background-size: 100%;">
                        <address>
                            <strong>Head Office:</strong><br>
                            21/15 Babor Road,&nbsp Block B<br>
                            Mohammadpur, Dhaka-1207<br>
                            <abbr title="Phone Number"><strong>Phone:</strong></abbr> (+880) 1819295651<br>
                            <abbr title="Email Address"><strong>Email:</strong></abbr> <a data-mce-href="mailto:info@softworksbd.com" href="mailto:info@softworksbd.com">info@softworksbd.com</a><br>
                            <abbr title="Fax"><strong>Web:</strong></abbr> <a target="_blank" href="http://softworksbd.com/">www.softworksbd.com</a>
                        </address>

                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="widget widget_links clearfix">
                    <h4>Resources</h4>
                    <ul>
                        <li><a href="index.php">Home</a></li>
                        <li><a href="features.php">Features</a></li>
                        <li><a href="pricing.php">Pricing</a></li>
                        <li><a href="faq.php">FAQ</a></li>
                    </ul>
                </div>
            </div>
			<div class="col-md-4">
            </div>
            <!--<div class="col-md-4">
                <div class="widget clearfix">
                    <div class="row">
                        <div class="col-md-6 bottommargin-sm">
                            <div class="counter counter-small"><span data-from="50" data-to="15065421" data-refresh-interval="80" data-speed="3000" data-comma="true"></span></div>
                            <h5 class="nobottommargin">Total Downloads</h5>
                        </div>

                        <div class="col-md-6 bottommargin-sm">
                            <div class="counter counter-small"><span data-from="100" data-to="18465" data-refresh-interval="50" data-speed="2000" data-comma="true"></span></div>
                            <h5 class="nobottommargin">Clients</h5>
                        </div>
                        <div class="col-md-6 clearfix bottommargin-sm">
                            <a href="#" class="social-icon si-dark si-colored si-facebook nobottommargin" style="margin-right: 10px;">
                                <i class="icon-facebook"></i>
                                <i class="icon-facebook"></i>
                            </a>
                            <a href="#"><small style="display: block; margin-top: 3px;"><strong>Like us</strong><br>on Facebook</small></a>
                        </div>
                        <div class="col-md-6 clearfix">
                            <a href="#" class="social-icon si-dark si-colored si-rss nobottommargin" style="margin-right: 10px;">
                                <i class="icon-rss"></i>
                                <i class="icon-rss"></i>
                            </a>
                            <a href="#"><small style="display: block; margin-top: 3px;"><strong>Subscribe</strong><br>to RSS Feeds</small></a>
                        </div>
                    </div>
                </div>
            </div>-->
            
        </div>

    </div><!-- .footer-widgets-wrap end -->

    <!-- Copyrights
    ============================================= -->
    <div id="copyrights">

        <div class="container clearfix">

            <div class="col_half">
                Copyrights &copy; 2017 All Rights Reserved by Softworks.<br>
            </div>

            <div class="col_half col_last tright">
                <i class="icon-envelope2"></i> <a data-mce-href="mailto:info@softworksbd.com" href="mailto:info@softworksbd.com">info@softworksbd.com</a> <i class="icon-phone"></i> +880 1819295651 <span class="middot"></span>
            </div>

        </div>

    </div><!-- #copyrights end -->
    <style>
        #footer .footer-widgets-wrap {
            padding: 25px 0;
            position: relative;
        }
    </style>

</footer>