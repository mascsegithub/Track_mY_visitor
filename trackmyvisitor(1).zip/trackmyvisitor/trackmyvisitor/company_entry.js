var trHTML;
var fileNames;
var tmpFileNameAttached;
var totalrow = 0;
var gTimeZone = '';
var gLangCode = ''
var LangCode = '';
var LangAdded = '';
var gDefaultLanguage = '';
var ajxCallCount = 0;
var LanguageList = [];
var tabId = 0;
var pretabId = 31;

function resetForm(id) {
    $('#' + id).each(function () {
        this.reset();
    });
}
function resetAllForm() {
    $('#stock-input').fileinput('clear');
    $('#stock-input').fileinput('reset');
}

function removeErrorline() {
    $("#CompanyNameVal").html('');
    $("#CompanyName").removeClass('invalidval');
}


function loadTimeZoneDropdown() {
    $.ajax({
        "async": true,
        url: baseUrl + "time-zone-combo-load",
        "method": "GET",
        "headers": {
            "Apikey": APIKEY,
            "cache-control": "no-cache"
        },
        success: function (response)
        {
            response = response['TimeZoneList'];
            var count = response.length;
            if (count > 0) {
                $.each(response, function (key, value) {
                    $('#TimeZone').append($('<option></option>').val(value.TimeZoneId).html(value.TimeZoneName));
                });
            }
            else {
                $('#TimeZone').val('');
            }
            
            ajxCallCount++;
            companyEdit(COMPANYID);
        }

    });
}

function loadLanguageDropdown() {
    $.ajax({
        "async": true,
        url: baseUrl + "language-combo-load",
        "method": "GET",
        "headers": {
            "Apikey": APIKEY,
            "cache-control": "no-cache"
        },
        success: function (response)
        {
            LanguageList = response['LanguageList'];
            
            ajxCallCount++;
            companyEdit(COMPANYID);
        }

    });

}
function setLangList(){
    var count = LanguageList.length;
    if (count > 0) {
        $.each(LanguageList, function (key, value) {

            var sel = '';
            $.each(LangAdded, function (key, obj) {
                if (value.LangCode == obj.LangCode) {
                    sel = 'selected';
                }
            });

            $('#LanguageTitle').append($('<option ' + sel + '></option>').val(value.LangCode).html(value.LangTitle));

        });
    }
    else {
        $('#LanguageTitle').val('');
    }
    $('.chosen-select').chosen();
    $('.chosen-select-deselect').chosen({allow_single_deselect: true});
}

function onConfirmWhenComapnyAdd() {

    var error = 0;
    var CompanyName = $("#CompanyName").val();
    var CompanyLogo = $("#LogoName").val();
    var LanCode = $("#LanguageCode").val();
    var TimeZoneId = $("#TimeZone").val();
    gLanCode = $("#DefaultLanguage").val();
    var Phone = $("#Phone").val();
    var Email = $("#Email").val();


    var LanguageTitle = $("#LanguageTitle").val();


    if (LanguageTitle == null) {
        $("#SupportLanVal").html('Please select at least one support language');
        $("#LanguageTitle").addClass('invalidval');
        error = 1;
    }
    else {
        $("#SupportLanVal").html('');
        $("#LanguageTitle").removeClass('invalidval');
    }

    if (gLanCode == null) {
        $("#DefaultLanVal").html('Please enter default language');
        $("#DefaultLanguage").addClass('invalidval');
        error = 1;
    }
    else {
        $("#DefaultLanVal").html('');
        $("#DefaultLanguage").removeClass('invalidval');
    }

    if (CompanyName == '') {
        $("#CompanyNameVal").html('Please enter company name');
        $("#CompanyName").addClass('invalidval');
        error = 1;
    }
    else {
        $("#CompanyNameVal").html('');
        $("#CompanyName").removeClass('invalidval');
    }
    if (LanCode == '') {
        $("#LanguageCodeVal").html('Please enter Language Code');
        $("#LanguageCode").addClass('invalidval');
        error = 1;
    }
    else {
        $("#LanguageCodeVal").html('');
        $("#LanguageCode").removeClass('invalidval');
    }
    if (Phone == '') {
        $("#PhoneVal").html('Please enter Phone no.');
        $("#Phone").addClass('invalidval');
        error = 1;
    }
    else {
        $("#PhoneVal").html('');
        $("#Phone").removeClass('invalidval');
    }
    if (Phone == '') {
        $("#PhoneVal").html('Please enter your Email no.');
        $("#EmailVal").addClass('invalidval');
        error = 1;
    }
    else {
        $("#PhoneVal").html('');
        $("#EmailVal").removeClass('invalidval');
    }

    if (error == 1) {
        return false;
    }
    else {
        $.ajax({
            "async": true,
            url: baseUrl + "company-create",
            "method": "POST",
            "data": $('#company_add_form').serialize() + '&CompanyId=' + COMPANYID + '&EmployeeId=' + EMPLOYEEID + '&LanCode=' + gLanCode + '&LangAdded=' + JSON.stringify(LangAdded),
            "headers": {
                "Apikey": APIKEY,
                "cache-control": "no-cache"
            },
            success: function (response)
            {
                $("#AllCompanyTable").hide();
                $("#AddNewCompany").show();
                if (response['error'] == false) {
                    insertLanguageByLangCodeAndCompanyId(gLanCode);
                    localStorage.setItem('TimeZoneName', TimeZoneId);
                    $("#MessageShow").html(response['message']);
                    $('#myModal').modal('show');
					
					getLanguageText(gLangCode);
                }
                else {
                    $("#MessageShow").html(response['message']);
                    $('#myModal').modal('show');
                }
            }
        });
    }
}

function onConfirmWhencomanyeEdit(response) {

    response = response['CompanyEdit'];    

    var RecordId = response[0]['CompanyId']
    var CompanyName = response[0]['CompanyName'];
    var CompanyImage = response[0]['CompanyImage'];
    var LangCode = response[0]['LangCode'];
    var LangTitle = response[0]['LangTitle'];
    var TimeZoneId = response[0]['TimeZoneId'];
    LangAdded = response[0]['LanguageAdded'];

    $.each(LangAdded, function (key, value) {        
     $('#DefaultLanguage').append($('<option></option>').val(value.LangCode).html(value.LangTitle));
    });

    setLangList();    

    getLanguageText(LangCode);

    var Phone = response[0]['Phone'];
    var Email = response[0]['Email'];

    $("#CompanyEntry").show();
    $("#AllEventTable").hide();
    $("#CompanyName").val(CompanyName);
    $("#LogoName").val(CompanyImage);
    $("#LanguageCode").val(LangCode);

    $("#DefaultLanguage").val(LangCode);
    $("#TimeZone").val(TimeZoneId);

    $("#Phone").val(Phone);
    $("#Email").val(Email);

    $("#RecordId").val(RecordId);
    $('.dummyComapnyLogo').hide();
    $("#AllCompanyTable").hide();
    $('.originalComapnyLogo').show();
    if (CompanyImage == '' || CompanyImage == null) {
        $('.originalComapnyLogo').html('<img src="images/companylogo/d_logo.jpg " alt="UploadImage" height="140" width="150">');
    } else {
        $('.originalComapnyLogo').html('<img src="images/companylogo/thumbs/' + CompanyImage + '" alt="UploadImage" height="125" width="120">');
    }
}
function companyEdit(CompId) {

    if(ajxCallCount != 2)
        return;

    $.ajax({
        "async": true,
        url: baseUrl + "company-list-edit/" + CompId + '/' + EMPLOYEEID,
        "method": "GET",
        "headers": {
            "Apikey": APIKEY,
            "cache-control": "no-cache"
        },
        success: function (response)
        {
            onConfirmWhencomanyeEdit(response);
        }
    });
}

function MySettings() {
    companyEdit(COMPANYID);
}


function insertLanguageByLangCodeAndCompanyId(gLanCode) {

    $.ajax({
        "async": true,
        url: baseUrl + "insert-language-text-by-langcode-and-companyid",
        "method": "POST",
        "data": '&CompanyId=' + COMPANYID + '&LangCode=' + gLanCode,
        "headers": {
            "Apikey": APIKEY,
            "cache-control": "no-cache"
        },
        success: function (response)
        {
            //getLanguageText(gLanCode);// by anwar
        }
    });
}
function onClickTabs(tabId){
	//alert(pretabId);
	$('#tabs-'+pretabId).hide();
	$('#activeClass-'+pretabId).removeClass("ui-state-default ui-corner-top ui-tabs-active ui-state-active");
	
	$('#tabs-'+tabId).show();
	$('#activeClass-'+tabId).addClass("ui-state-default ui-corner-top ui-tabs-active ui-state-active");
	pretabId = tabId;
}

function getLanguageText(gLangCode) {
    $.ajax({
        "async": true,
        url: baseUrl + "getInterFacingStringforCompany/" + COMPANYID,
        "method": "GET",
        "headers": {
            "Apikey": APIKEY,
            "cache-control": "no-cache"
        },
        success: function (response)
        {
            response = response['LanguageText'];
            totalrow = response.length;
            tabId = 31;
            var uiId = 15;
            var lis = '';
            var divs = '';
			trHTML = '';

            var tabIds = [];

            $.each(LangAdded, function (key, value) {

              lis += '<li id="activeClass-' + tabId + '"><a onClick="onClickTabs(' + tabId + ')" data-mce-href="#" href="javascript:void(0);">' + value.LangTitle + '</a></li>';
               var eachLang = _.where(response, {LangCode: value.LangCode});

               setLanguageTab(eachLang, tabId);

               //alert(tabId);

               //setLanguageTab({}, tabId);

               tabIds.push({'TabId' : tabId, 'LangCode': value.LangCode});

               tabId++;
               uiId++;

            });

			$('#TabNavbar').html(lis); 
			$('#TableTabs').html(trHTML);

            _.each(tabIds, function(obj){
                setInlineEditor(obj);
            })
			
			$('#TabNavbar li:first').addClass("ui-state-default ui-corner-top ui-tabs-active ui-state-active");	
			$('#TableTabs div:first').show();

        }
    });
}

function setInlineEditor(obj){
     $.fn.editable.defaults.mode = 'inline';

    $('#LanguageTable' + obj.TabId + ' a').editable({
        type: 'text',
        name: 'textname',
        pk: 1,
        url: baseUrl + 'update-lan-text/' + COMPANYID + '/' + obj.LangCode,
        title: 'Enter Text',
        ajaxOptions: {
            type: 'put',
            dataType: 'json',
            headers: {
                "ApiKey": APIKEY
            }
        }
    });

    formValidation();

    autoOpenNextField(obj.TabId);
}


function setLanguageTab(response, tabId){
            
            var LangTextName = '';
            var LangText = '';
            var i = 1;
			//alert(tabId);
            //trHTML += '<div class="tab-content clearfix" id="tabs-' + tabId + '"><div id="list-panel' + tabId + '">' +
            trHTML += '<div style="display:none;" class="tab-content clearfix" id="tabs-' + tabId + '"><div id="list-panel' + tabId + '">' +
            '<table id="LanguageTable' + tabId + '" class="table table-bordered nobottommargin" cellspacing="0">' +
            '<thead><tr><th style="text-align: left;">Language Variable</th><th style="text-align: left;">Language Text</th></tr>' +
            '</thead>' +
            '<tbody>'; 

            $.each(response, function (key, value) {
                LangTextName = value.LangTextName;
                LangText = value.LangText;
                trHTML +=
                '<tr><td style="width:40%;" id="lanTextName_' + i +'_'+tabId+ '" class="">' + LangTextName +
                '</td><td><a  href="#" data-pk="' + LangTextName + '" class="newuser" name="lanTextId_' + i +'_'+tabId+ '"  id="lanTextId_' + i +'_'+tabId+ '">' + LangText + '</a></td>'
                '</td></tr>';
                i++;
            });

            trHTML += '</tbody></table></div></div>';
            
}

/*----------------------Start Ready function--------------------------*/

$(function () {
	
    resetForm("company_add_form");

    $('#TimeZone').change(function () {
        gTimeZone = $("#TimeZone").val();
    });

    $('#LanguageTitle').change(function (evt, params) {

     LangAdded = [];

     var options = $("#LanguageTitle option:selected");       

     var optValues = $.map(options, function(option) {

        LangAdded.push({"LangCode":option.value,"LangTitle":option.text});

        return '<option value="' + option.value + '">' + option.text + '</option>'
    }).join('');  

     $("#DefaultLanguage").html(optValues);

 });

    $('#company_add_form').submit(function () {
        return false;
    });

    $(".originalComapnyLogo").click(function () {
        resetAllForm();
    });

    $(".dummyComapnyLogo").click(function () {
        resetAllForm();
    });

    $("#AddNewCompany").click(function () {
        removeErrorline();
        $("#AllCompanyTable").hide();
        $("#CompanyEntry").show();
        $("#CompanyName").val('');
        $("#RecordId").val('');
        $("#LogoName").val('');
        $('.dummyComapnyLogo').show();
        $('.originalComapnyLogo').hide();
    });

    $("#AllCompany").click(function () {
        removeErrorline();
        $("#AllCompanyTable").show();
        $("#CompanyEntry").hide();
        $('.dummyComapnyLogo').hide();
        $('.originalComapnyLogo').hide();
    });

    loadLanguageDropdown();
    loadTimeZoneDropdown();
	
});

/*----------------------End Ready function--------------------------*/

$("#stock-input").fileinput({
    uploadUrl: ImageUrl + '/logoUploadProcess.php',
    maxFileCount: 1,
    maxFileSize: 5120,
    previewFileIcon: '<i class="fa fa-file"></i>',
    previewFileType: false,
    wrapTextLength: 30,
    allowedFileExtensions: ['jpg', 'png', 'gif', 'ico'],
    allowedPreviewTypes: null,
    uploadExtraData: {
        "company": "softworks"
    },
    previewFileIconSettings: {
        'jpg': '<i class="fa fa-file-photo-o text-warning"></i>',
        'png': '<i class="fa fa-file-photo-o text-danger"></i>'
    }
});

$('#stock-input').on('filebrowse', function (event) {
    $('#stock-input').fileinput('reset');
});

$('#stock-input').on('fileloaded', function (event, file, previewId, index) {
    console.log("fileloaded");
});

$('#stock-input').on('fileuploaded', function (event, data, previewId, index) {
    var formdata = data.form, files = data.files, extradata = data.extra, responsedata = data.response;
    fuResponse = responsedata;
    $('.originalComapnyLogo').html('<img src="images/companylogo/thumbs/' + fuResponse.FileName + '" alt="UploadLogo" height="125" width="120">');
    $("#LogoName").val(fuResponse.FileName);
    $('.dummyComapnyLogo').hide();
    $('.originalComapnyLogo').show();
    $('#myModalLogo').modal('hide');
});

$('#stock-input').on('fileuploaderror', function (event, data, previewId, index) {
    var formdata = data.form, files = data.files, extradata = data.extra, responsedata = data.response;
    console.log('File upload error');
});

$('#stock-input').on('filecleared', function (event) {
    var fileNamesString = $("#LogoName").val();
    if (typeof tmpFileNameAttached != 'undefined') {
        var tmpfiles = tmpFileNameAttached.split('undefined').join('');
        tmpfiles = tmpfiles.substring(0, tmpfiles.length - 1);
        var fileNames = fileNamesString.split('|' + tmpfiles).join('');
    }
    $("#LogoName").val(fileNames);
    tmpFileNameAttached = '';
}
);

function formValidation() {
    for (var i = 1; i <= totalrow; i++) {
        $('#lanTextId_' + i).editable('option', 'validate', function (v) {
            if (!v)
                return 'This Field is Required!';
        });
    }
}
function autoOpenNextField(tabId) {
    $('#LanguageTable' + tabId + ' .editable').on('hidden', function (e, reason) {
        if (reason === 'save' || reason === 'nochange') {
            var $next = $(this).closest('tr').next().find('.editable');
            setTimeout(function () {
                $next.editable('show');
            }, 200);
        }
    });
}