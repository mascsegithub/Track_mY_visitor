var $ = jQuery.noConflict();

var i = 0;
var totalVisitors = 0;
var totalVisitorsArray = [];
var EmployeeNameArray = [];
var SignInVisitors = 0;
var SignOutVisitors = 0;
var SelectDays = 30;
function getHostInfoData(hostId) {

    $.ajax({
        "async": true,
        url: baseUrl + "hostinfo/" + hostId,
        "method": "GET",
        "headers": {
            "Apikey": APIKEY,
            "cache-control": "no-cache"
        },
        success: function (response) {
            var response = response['hostinfo'];
            var tabletrHTML = '';
            $.each(response, function (key, value) {
                tabletrHTML = '<tbody>' +
                        '<tr></td><td>Host</td><td>' + value.FullName + '</td></tr>' +
                        '<tr></td><td>Department</td><td>' + value.DivisionName + '</td></tr>' +
                        '<tr></td><td>Job Title</td><td>' + value.JobTitle + '</td></tr>' +
                        '<tr></td><td>Mobile No</td><td>' + value.MobileNo + '</td></tr>' +
                        '<tr></td><td>Desk Phone No</td><td>' + value.DeskPhoneNo + '</td></tr>' +
                        '<tr></td><td>Email Address</td><td>' + value.EmailAddress + '</td></tr>' +
                        '<tr></td><td>Company</td><td>' + value.CompanyName + '</td></tr>' +
                        '<tbody>';
            });
            $('#HostInfo').html(tabletrHTML);
        }
    });
}

function SetDaysAndSelection(OptionSelect) {
    if (OptionSelect == 1) {
        $("#SelectDays").html("Daily Visitors <div style='' class='btn-group pull-right'><button id='OneWeek' class='btn btn-default active' type='button' onclick='OneWeekSet(1)'>1 Week</button><button id='OneMonth' class='btn btn-default active' type='button' onclick='OneMonthSet(1)'>1 Month</button><button id='ThreeMonth' class='btn btn-default active' type='button' onclick='ThreeMonthSet(1)'>3 Months</button></div>");
    } else if (OptionSelect == 2) {
        $("#SelectDaysPieChart").html("Busiest Hosts   <div class='btn-group pull-right'><button id='OneWeekForPie' class='btn btn-default active' type='button' onclick='OneWeekSet(2)'>1 Week</button><button id='OneMonthForPie' class='btn btn-default active' type='button' onclick='OneMonthSetForPieChart(2)'>1 Month</button><button id='ThreeMonthForPie' class='btn btn-default active' type='button' onclick='ThreeMonthSet(2)'>3 Months</button></div>");
    } else {

    }
}
function OneWeekSet(OptionSelect) {
    SelectDays = 7;
    SetDaysAndSelection(OptionSelect);

    if (OptionSelect == 1) {
        $('#OneWeek').addClass('active');
        $('#OneMonth').removeClass('active');
        $('#ThreeMonth').removeClass('active');
        getVisitorsNumberPerDay();
    } else {
        $('#OneWeekForPie').addClass('active');
        $('#OneMonthForPie').removeClass('active');
        $('#ThreeMonthForPie').removeClass('active');
        getTotalVisitor();
    }
}

function OneMonthSet(OptionSelect) {
    SelectDays = 30;
    SetDaysAndSelection(OptionSelect);
    $('#OneWeek').removeClass('active');
    $('#OneMonth').addClass('active');
    $('#ThreeMonth').removeClass('active');
    getVisitorsNumberPerDay();
}
function OneMonthSetForPieChart(OptionSelect) {
    SelectDays = 30;
    SetDaysAndSelection(OptionSelect);

    $('#OneWeekForPie').removeClass('active');
    $('#OneMonthForPie').addClass('active');
    $('#ThreeMonthForPie').removeClass('active');
    getTotalVisitor();

}
function ThreeMonthSet(OptionSelect) {
    SelectDays = 90;
    SetDaysAndSelection(OptionSelect);
    if (OptionSelect == 1) {
        $('#OneWeek').removeClass('active');
        $('#OneMonth').removeClass('active');
        $('#ThreeMonth').addClass('active');
        getVisitorsNumberPerDay();
    } else {
        $('#OneWeekForPie').removeClass('active');
        $('#OneMonthForPie').removeClass('active');
        $('#ThreeMonthForPie').addClass('active');
        getTotalVisitor();
    }
}


function countSignedInVisitors() {
    $.ajax({
        "async": true,
        url: baseUrl + "count-signed-in-visitors/" + COMPANYID + "/" + $("#SearchDate").val(),
        "method": "GET",
        "headers": {
            "ApiKey": APIKEY,
            "cache-control": "no-cache"
        },
        success: function (NumOfSignedInVisitors)
        {
            SignInVisitors = NumOfSignedInVisitors;
            countPremiseVisitor();
            $('#CountSignedInVisitors').html("<span data-from='0' data-to=" + NumOfSignedInVisitors + " data-refresh-interval='50' data-speed='2000'>" + NumOfSignedInVisitors + "</span>");

        }
    });
}

function countSignedOutVisitors() {
    $.ajax({
        "async": true,
        url: baseUrl + "count-signed-out-visitors/" + COMPANYID + "/" + $("#SearchDate").val(),
        "method": "GET",
        "headers": {
            "ApiKey": APIKEY,
            "cache-control": "no-cache"
        },
        success: function (NumOfSignedOutVisitors)
        {
            SignOutVisitors = NumOfSignedOutVisitors;
            countPremiseVisitor();
            $('#CountSignedOutVisitors').html("<span data-from='0' data-to=" + NumOfSignedOutVisitors + " data-refresh-interval='50' data-speed='2000'>" + NumOfSignedOutVisitors + "</span>");
        }
    });
}

function countPremiseVisitor() {
    var NumOfPremiseVisitors = SignInVisitors - SignOutVisitors;
    if (NumOfPremiseVisitors >= 0) {
        $('#CountPremiseVisitors').html("<span data-from='0' data-to=" + NumOfPremiseVisitors + " data-refresh-interval='50' data-speed='2000'>" + NumOfPremiseVisitors + "</span>");
    } else {
        $('#CountPremiseVisitors').html("<span data-from='0' data-to=0 data-refresh-interval='50' data-speed='2000'>0</span>");
    }
}

function getVisitorsNumberPerDay() {

    $.ajax({
        "async": true,
        "url": baseUrl + "daily-visitor/" + COMPANYID + "/" + SelectDays,
        "method": "GET",
        "headers": {
            "ApiKey": APIKEY,
            "cache-control": "no-cache"
        },
        success: function (response) {
            getVisitorsNumberPerDayInfo(response);
        }
    });
}

function getVisitorsNumberPerDayInfo(response) {
    response = response['visitor-summary'];
    var totalData = response.length;
    var dateArray = [];
    var visitorsArray = [];
    for (i = 0; i < totalData; i++) {
        dateArray[i] = response[i]['date'];
        visitorsArray[i] = response[i]['TotalVisitor'];

    }
    $('#VisitorsNumbersPerDay').highcharts({
        chart: {
            type: 'area'
        },
        title: {
            text: 'Daily Visitors (Last ' + SelectDays + ' days)'
                    //text: null
        },
        subtitle: {
        },
        xAxis: {
            categories: dateArray,
            title: {
                text: null
            }
        },
        yAxis: {
            min: 1,
            max: 25,
            title: {
                //text: 'Visitors number states'
                text: ''
            },
            labels: {
                formatter: function () {
                    // return this.value / 1000 + 'k'; //Important don't discurd
                }
            }
        },
        tooltip: {
            pointFormat: '<span style="color:{series.color}">{series.name}</span>:({point.y})<br/>',
            split: true
        },
        exporting: {
            enabled: true,
            filename: 'Daily Visitors (Last ' + SelectDays + ' days)'
        },
        plotOptions: {
            area: {
                pointStart: 0,
                marker: {
                    enabled: false,
                    symbol: 'circle',
                    radius: 1,
                    states: {
                        hover: {
                            enabled: true
                        }
                    }
                }
            }
        },
        credits: {
            enabled: false
        },
        series: [{
                name: 'Visitors',
                data: visitorsArray
            }]
    });
}

function getTotalVisitor() {
    $.ajax({
        "async": true,
        "url": baseUrl + "busiest-hosts/" + COMPANYID + "/" + SelectDays,
        "method": "GET",
        "headers": {
            "ApiKey": APIKEY,
            "cache-control": "no-cache"
        },
        success: function (response) {
            getTotalVisitorInfo(response);
        }
    });
}

function getTotalVisitorInfo(response) {
    response = response['busiest-hosts'];
    $('#VisitorsNumbersPerDay_pichart').highcharts({
        chart: {
            plotBackgroundColor: null,
            plotBorderWidth: null,
            plotShadow: false,
            type: 'pie'
        },
        title: {
            text: 'Busiest Hosts (Last ' + SelectDays + ' days)'
        },
        tooltip: {
            pointFormat: '{series.name}: <b>{point.y}</b>'
        },
        exporting: {
            enabled: true,
            filename: 'Busiest Hosts (Last ' + SelectDays + ' days)'
        },
        plotOptions: {
            pie: {
                allowPointSelect: true,
                cursor: 'pointer',
                dataLabels: {
                    enabled: false
                },
                showInLegend: true
            }
        },
        credits: {
            enabled: false
        },
        series: [{
                name: 'Visitors',
                colorByPoint: true,
                data: response
            }]
    });
}

$(function () {
    $("#SearchDate").datepicker({
        dateFormat: 'yy-mm-dd',
        onSelect: function (selectedDate) {
            countSignedInVisitors();
            countSignedOutVisitors();
            VisitorsDataList.fnDraw();
        }
    }).datepicker("setDate", new Date());

    $("#btn-search").click(function () {
        $("#SearchDate").datepicker("show");
    });

    $('body').animate({
        opacity: 1
    }, 500, function () {

        VisitorsDataList = $('#AllVisitorsDataList').dataTable({
            "bFilter": true,
            "bSort": true,
            "bInfo": true,
            "bPaginate": true,
            "bSortClasses": false,
            "bProcessing": true,
            "bServerSide": true,
            "aaSorting": [[4, 'DESC']],
            "sPaginationType": "full_numbers",
            "aLengthMenu": [[25, 50, 100], [25, 50, 100]],
            "iDisplayLength": 25,
            //"sScrollX" : "100%",
            "sAjaxSource": baseUrl + "visitorlistfordashboard",
            "fnDrawCallback": function (oSettings) {

            },
            "fnServerData": function (sSource, aoData, fnCallback) {
                aoData.push({
                    "name": "CompanyId",
                    "value": COMPANYID
                });
                aoData.push({
                    "name": "TimeZoneName",
                    "value": TimeZoneName
                });
                aoData.push({
                    "name": "CurrentDate",
                    "value": $("#SearchDate").val()
                });

                $.ajax({
                    "dataType": 'json',
                    "type": "POST",
                    "url": sSource,
                    "headers": {"Apikey": APIKEY},
                    "data": aoData,
                    "success": fnCallback
                });
            },
            "aoColumns": [{
                    //EmployeeId	
                    "bVisible": false,
                    "bSortable": false
                }, {
                    //photo
                    "sClass": "text_Center",
                    "sWidth": "7%",
                    "bSortable": false
                }, {
                    //Visitor
                    "sClass": "text_Left",
                    "sWidth": "15%",
                    "bSortable": false
                }, {
                    //Host
                    "sClass": "text_Left",
                    "sWidth": "20%",
                    "bSortable": false
                }, {
                    //Sign In
                    "sClass": "text_Center",
                    "sWidth": "19%",
                    "bSortable": true
                }, {
                    //Sign Out
                    "sClass": "text_Center",
                    "sWidth": "19%",
                    "bSortable": false
                }, {
                    //Duration
                    "sClass": "text_Center",
                    "sWidth": "10%",
                    "bSortable": false
                }, {
                    //Visitor Type
                    "sClass": "text_Center",
                    "sWidth": "10%",
                    "bSortable": false
                }]
        });
    });

    countSignedInVisitors();
    countSignedOutVisitors();
    OneMonthSet(1);
    OneMonthSetForPieChart(2);
});

