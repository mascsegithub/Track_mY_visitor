var fileNames;
var tmpFileNameAttached;
var lastEmployeeId = 0;
var $ = jQuery.noConflict();

function validateEmail(email) {
    var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return re.test(email);
}

function resetForm(id) {
    $('#' + id).each(function () {
        this.reset();
    });
}

function resetAllForm() {
    $('#stock-input').fileinput('clear');
}

function onConfirmWhenVisitorAdd() {
    $("#PhotoArea").show();
    var SpecialVisitorName = $("#SpecialVisitorName").val();
    var SpecialVisitorCompany = $("#SpecialVisitorCompany").val();
    var EmailAddress = $("#EmailAddress").val();
    var Phone = $("#Phone").val();
    var EventId = $("#EventId").val();
    var VisitorTypeId = $("#VisitorTypeId").val();
    var EmployeeId = $("#EmployeeId").val();
    var AppointmentDate = $("#AppointmentDate").val();
    var EventName = $("#EventId option[value=" + $('#EventId').val() + "]").text();
    var VisitorTypeName = $("#VisitorTypeId option[value=" + $('#VisitorTypeId').val() + "]").text();
    var EmployeeName = $("#EmployeeId option[value=" + $('#EmployeeId').val() + "]").text();
    var error = 0;



    if (SpecialVisitorName == '') {
        $("#invalidSpecialVisitorName").html('Please enter your name');
        $("#SpecialVisitorName").addClass('invalidval');
        error = 1;
    }
    else {
        $("#invalidSpecialVisitorName").html('');
        $("#SpecialVisitorName").removeClass('invalidval');

    }

    if (SpecialVisitorCompany == '') {
        $("#invalidSpecialVisitorCompany").html('Please enter your company name');
        $("#SpecialVisitorCompany").addClass('invalidval');
        error = 1;
    }
    else {
        $("#invalidSpecialVisitorCompany").html('');
        $("#SpecialVisitorCompany").removeClass('invalidval');

    }
    if (EmailAddress == '') {
        $("#invalidEmailAddress").html('Please enter your email address');
        $("#EmailAddress").addClass('invalidval');
        error = 1;
    }
    else if (!validateEmail(EmailAddress)) {
        $("#invalidEmailAddress").html('Please enter valid email address');
        $("#EmailAddress").addClass('invalidval');
        error = 1;
    }
    else {
        $("#invalidEmailAddress").html('');
        $("#EmailAddress").removeClass('invalidval');
    }

    if (Phone == '') {
        $("#invalidPhone").html('Please enter your phone number');
        $("#Phone").addClass('invalidval');
        error = 1;
    }
    else {
        $("#invalidPhone").html('');
        $("#Phone").removeClass('invalidval');

    }
    if (EventId == '') {
        $("#invalidEventId").html('Please select event');
        $("#EventId").addClass('invalidval');
        error = 1;
    }
    else {
        $("#invalidEventId").html('');
        $("#EventId").removeClass('invalidval');

    }
    if (VisitorTypeId == '') {
        $("#invalidVisitorTypeId").html('Please select visitor type');
        $("#VisitorTypeId").addClass('invalidval');
        error = 1;
    }
    else {
        $("#invalidVisitorTypeId").html('');
        $("#VisitorTypeId").removeClass('invalidval');

    }
    if (EmployeeId == '') {
        $("#invalidEmployeeId").html('Please select Employee');
        $("#EmployeeId").addClass('invalidval');
        error = 1;
    }
    else {
        $("#invalidEmployeeId").html('');
        $("#EmployeeId").removeClass('invalidval');

    }
    if (AppointmentDate == '') {
        $("#invalidAppointmentDate").html('Please select date');
        $("#AppointmentDate").addClass('invalidval');
        error = 1;
    }
    else {
        $("#invalidAppointmentDate").html('');
        $("#AppointmentDate").removeClass('invalidval');

    }
    if (error == 1) {
        return false;
    }
    else {
        $.ajax({
            "async": true,
            url: baseUrl + "authorize-visitor-create",
            "method": "POST",
            "data": $('#employee_add_form').serialize() + '&CompanyId=' + COMPANYID + '&EventName=' + EventName + '&EmployeeName=' + EmployeeName + '&VisitorTypeName=' + VisitorTypeName,
            "headers": {
                "Apikey": APIKEY,
                "cache-control": "no-cache"
            },
            success: function (response)
            {
                $("#VisitorList").hide();
                $("#AddSpecialVisitorInfo").show();
                if (response['error'] == false) {
                    if ($("#RecordId").val() == 0)
                        $(".dImage").show();
                    else
                        $('.OriginalImage').show();
                    $('#QrCodeImage').html('<img src="images/barcodeimage/' + response['QRAttachment'] + '" alt="QR Code Image" height="200" width="200">');
                    lastEmployeeId = response['SpecialVisitorId'];
                    $("#QrCodeImage").show();
                    $("#RecordId").val(response['SpecialVisitorId']);
                    $("#AuthorizeVisitorAddMessage").html(response['message']);
                }
                else {
                    $("#AuthorizeVisitorAddMessage").html(response['message']);
                }
            }
        });
    }
}

function onConfirmWhenEmployeeEdit(response) {

    response = response['visitorEdit'];
    lastEmployeeId = response[0]['SpecialVisitorId'];
    var RecordId = response[0]['SpecialVisitorId'];
    var SpecialVisitorName = response[0]['SpecialVisitorName'];
    var SpecialVisitorCompany = response[0]['SpecialVisitorCompany'];
    var EmailAddress = response[0]['EmailAddress'];
    var VisitorImage = response[0]['VisitorImage'];
    var Phone = response[0]['Phone'];
    var EmployeeId = response[0]['EmployeeId'];
    var AppointmentDate = response[0]['AppointmentDate'];
    var EventId = response[0]['EventId'];
    var VisitorTypeId = response[0]['VisitorTypeId'];

    //alert(EventId);

    $("#SpecialVisitorName").val(SpecialVisitorName);
    $("#SpecialVisitorCompany").val(SpecialVisitorCompany);
    $("#EmailAddress").val(EmailAddress);
    $("#Phone").val(Phone);
    $("#EmployeeId").val(EmployeeId);
    $("#AppointmentDate").val(AppointmentDate);
    $("#EventId").val(EventId);
    $("#VisitorTypeId").val(VisitorTypeId);
    $("#RecordId").val(RecordId);

    $(".dImage").hide();
    $('.OriginalImage').show();
    $("#PhotoArea").show();

    if (VisitorImage == null) {
        $('.OriginalImage').html('<img src="images/em.jpg"  alt="Upload Image" height="80" width="80">');
    }
    else {
        $('.OriginalImage').html('<img src="images/visitors/thumbs/' + VisitorImage + '"  alt="Upload Image" height="80" width="80">');
    }
    $('#QrCodeImage').html('<img src="images/barcodeimage/' + response[0]['QRAttachment'] + '"  alt="QR Code Image" height="200" width="200">');
    $("#QrCodeImage").show();
    $("#VisitorList").hide();
    $("#AddSpecialVisitorInfo").show();

}
function employeeEdit(EmployeeId) {

//alert(EmployeeId);
    $.ajax({
        "async": true,
        url: baseUrl + "authorize-visitor-list-edit/" + EmployeeId,
        "method": "GET",
        "headers": {
            "Apikey": APIKEY,
            "cache-control": "no-cache"
        },
        success: function (response)
        {
            populateDropDownList();
            setTimeout(function () {
                onConfirmWhenEmployeeEdit(response);
            }, 1000);
        }
    });
}

function removeErrorline() {
    $("#RecordId").val(0);
    $("#SpecialVisitorName").removeClass('invalidval');
    $("#invalidSpecialVisitorName").html('');
    $("#AuthorizeVisitorAddMessage").html('');
    $("#invalidSpecialVisitorCompany").html('');
    $("#SpecialVisitorCompany").removeClass('invalidval');
    $("#invalidEmailAddress").html('');
    $("#EmailAddress").removeClass('invalidval');
    $("#invalidPhone").html('');
    $("#Phone").removeClass('invalidval');
    $("#invalidAppointmentDate").html('');
    $("#AppointmentDate").removeClass('invalidval');
}
function specialVisitorDelete(SVisitorId) {
    if (!confirm("Do you really want to delete this record?")) {
        return false;
    } else {
        $.ajax({
            "async": true,
            url: baseUrl + "authorize-visitor-delete/" + SVisitorId,
            "method": "GET",
            "headers": {
                "Apikey": APIKEY,
                "cache-control": "no-cache"
            },
            success: function (response)
            {
                if (response['error'] == false) {
                    var msg = "Autorize Visitor has been deleted successfully";
                    $("#MessageShow").html(msg);
                    $('#msgModal').modal('show');
                    getEmployeeHistoryData()
                } else {
                    var msg = "Sorry, Autorize Visitor has not been deleted";
                    $("#MessageShow").html(msg);
                    $('#msgModal').modal('show');
                }
            }
        });
    }
}
function onListPanel() {
    $('#VisitorList').show();
    $('#AddSpecialVisitorInfo').hide();
    getEmployeeHistoryData();
    $(".dImage").hide();
    $('.OriginalImage').hide();
    $("#QrCodeImage").hide();
}
$(function () {

    $(".dImage").hide();
    resetForm("employee_add_form");
    $("#AddSpecialVisitor").click(function () {
        removeErrorline();
        $("#QrCodeImage").hide();
        resetForm("employee_add_form");
        populateDropDownList();
        $("#SpecialVisitorName").val('');
        $("#SpecialVisitorCompany").val('');
        $("#EmailAddress").val('');
        $("#Phone").val('');
        $("#AppointmentDate").val('');
        $('.OriginalImage').hide();
        $("#PhotoArea").hide();
        $("#VisitorList").hide();
        $("#VisitorList").hide();
        $("#AddSpecialVisitorInfo").show();
    });

    $(".OriginalImage").click(function () {
        resetAllForm();
    });
    $(".dImage").click(function () {
        resetAllForm();
    });
    $("#AllHost").click(function () {
        removeErrorline();
        resetForm("employee_add_form");
        $("#VisitorList").show();
        $("#AddSpecialVisitorInfo").hide();
        getEmployeeHistoryData();
        $(".dImage").hide();
        $('.OriginalImage').hide();
        $("#QrCodeImage").hide();
    });


    $("#AppointmentDate").datepicker({dateFormat: 'yy-mm-dd'});

    getEmployeeHistoryData();
    $("#PhotoArea").hide();
    $('#employee_add_form').submit(function () {
        onConfirmWhenVisitorAdd();
        return false;
    });
});

function getEmployeeHistoryDataInfo(response) {
    response = response['authorize-visitor'];
    //alert(123);
    //alert(response[0]['SpecialVisitorId']);
    var trHTML = '';
    var VisitorImage = '';
    var SpecialVisitorId = '';
    var SpecialVisitorName = '';
    var SpecialVisitorCompany = '';
    var VisitorType = '';
    var EmailAddress = '';
    var Phone = '';
    var EventName = '';
    var FullName = '';
    var AppointmentDate = '';
    var HostId = '';
    $.each(response, function (key, value) {
        VisitorImage = value.VisitorImage;
        SpecialVisitorId = value.SpecialVisitorId;
        SpecialVisitorName = value.SpecialVisitorName;
        SpecialVisitorCompany = value.SpecialVisitorCompany;
        VisitorType = value.VisitorType;
        EmailAddress = value.EmailAddress;
        Phone = value.Phone;
        EventName = value.EventName;
        FullName = value.FullName;
        HostId = value.HostId;
        AppointmentDate = value.AppointmentDate;
        var emailPhone = EmailAddress + '<br>' + Phone;
        trHTML +=
                '<tr><a href="#"><td style="text-align: left;width:7%;"><img src= ' + VisitorImage + '  alt="Visitor Image" height="50" width="50"><b>' +
                '</td><td style="text-align: left;width:18%;">' + SpecialVisitorName + ', ' + SpecialVisitorCompany + ', ' + VisitorType +
                '</td><td style="text-align: left;width:13%;">' + emailPhone +
                '</td><td style="text-align: left;width:14%;">' + EventName +
                '</td><td style="text-align: left;width:10%;">' + '<a onClick="getHostInfoData(' + HostId + ')" href="javascript:void(0);" data-toggle="modal" data-target="#HostModal"><b>' + value.FullName + '</b></a>' +
                '</td><td style="text-align: left;width:8%;">' + AppointmentDate +
                '</td><td style="text-align: center;width:16%;"> <input type="submit" value="Edit" class="btn btn-primary btn-sm" onClick="employeeEdit(' + SpecialVisitorId + ')">' + ' ' + '<input type="submit" value="Delete" class="btn btn-danger btn-sm" onClick="specialVisitorDelete(' + SpecialVisitorId + ')">' +
                '</td></a></tr>';
    });
    $('#AllVisitorInfoTable').html(trHTML);
}
function getHostInfoData(hostId) {

    $.ajax({
        "async": true,
        url: baseUrl + "hostinfo/" + hostId,
        "method": "GET",
        "headers": {
            "Apikey": APIKEY,
            "cache-control": "no-cache"
        },
        success: function (response) {
            var response = response['hostinfo'];
            var tabletrHTML = '';
            $.each(response, function (key, value) {
                tabletrHTML = '<tbody>' +
                        '<tr></td><td>Host</td><td>' + value.FullName + '</td></tr>' +
                        '<tr></td><td>Department</td><td>' + value.DivisionName + '</td></tr>' +
                        '<tr></td><td>Job Title</td><td>' + value.JobTitle + '</td></tr>' +
                        '<tr></td><td>Mobile No</td><td>' + value.MobileNo + '</td></tr>' +
                        '<tr></td><td>Desk Phone No</td><td>' + value.DeskPhoneNo + '</td></tr>' +
                        '<tr></td><td>Email Address</td><td>' + value.EmailAddress + '</td></tr>' +
                        '<tr></td><td>Company</td><td>' + value.CompanyName + '</td></tr>' +
                        '<tbody>';
            });
            $('#HostInfo').html(tabletrHTML);
        }
    });
}
function getEmployeeHistoryData() {

    $.ajax({
        "async": true,
        url: baseUrl + "authorize-visitor-list-by-companyid/" + COMPANYID,
        "method": "GET",
        "headers": {
            "Apikey": APIKEY,
            "cache-control": "no-cache"
        },
        success: function (response)
        {
            getEmployeeHistoryDataInfo(response);
        }
    });
}

function populateDropDownList() {

    $.ajax({
        "async": true,
        url: baseUrl + "drop-down-event-list-by-companyid/" + COMPANYID,
        "method": "GET",
        "headers": {
            "Apikey": APIKEY,
            "cache-control": "no-cache"
        },
        success: function (response)
        {
            response = response['event'];
            var trHTML = '';
            $.each(response, function (key, value) {
                trHTML += '<option value="' + value.EventId + '">' + value.EventName + '</option>';
            });
            $('#EventId').html(trHTML);
        }
    });

    $.ajax({
        "async": true,
        url: baseUrl + "drop-down-employee-list-by-companyid/" + COMPANYID,
        "method": "GET",
        "headers": {
            "Apikey": APIKEY,
            "cache-control": "no-cache"
        },
        success: function (response)
        {
            response = response['event'];
            var trHTML = '';
            $.each(response, function (key, value) {
                trHTML += '<option value="' + value.Id + '">' + value.FullName + '</option>';
            });
            $('#EmployeeId').html(trHTML);
        }
    });
    $.ajax({
        "async": true,
        url: baseUrl + "drop-down-Visitor-Type-list-by-companyid/" + COMPANYID,
        "method": "GET",
        "headers": {
            "Apikey": APIKEY,
            "cache-control": "no-cache"
        },
        success: function (response)
        {
            response = response['visitor-type'];
            var trHTML = '';
            $.each(response, function (key, value) {
                trHTML += '<option value="' + value.VisitorTypeId + '">' + value.VisitorType + '</option>';
            });
            $('#VisitorTypeId').html(trHTML);
        }
    });
}

function  updateHostImage(EmployeeImage) {

    $.ajax({
        "async": true,
        url: baseUrl + "authorize-visitor-image-add/" + lastEmployeeId,
        "method": "POST",
        "data": '&VisitorImage=' + EmployeeImage,
        "headers": {
            "Apikey": APIKEY,
            "cache-control": "no-cache"
        },
        success: function (response)
        {
            $("#VisitorList").hide();
            $("#AddSpecialVisitorInfo").show();
            if (response['error'] == false) {
                $(".dImage").hide();
            }
            else {

            }

        }
    });
}

$("#stock-input").fileinput({
    //uploadUrl: '/trackmyvisitor/uploadImage.php', //local
    uploadUrl: ImageUrl + '/uploadImage.php',
    maxFileCount: 1,
    maxFileSize: 5120,
    previewFileIcon: '<i class="fa fa-file"></i>',
    previewFileType: false,
    wrapTextLength: 30,
    allowedFileExtensions: ['jpg', 'png'],
    allowedPreviewTypes: null,
    uploadExtraData: {
        "company": "softworks"
    },
    previewFileIconSettings: {
        'jpg': '<i class="fa fa-file-photo-o text-warning"></i>',
        'png': '<i class="fa fa-file-photo-o text-danger"></i>'
    }
});
$('#stock-input').on('filebrowse', function (event) {
    $('#stock-input').fileinput('reset');
});
$('#stock-input').on('fileloaded', function (event, file, previewId, index) {
    console.log("fileloaded");
});
//resetAllForm();
$('#stock-input').on('fileuploaded', function (event, data, previewId, index) {
    var formdata = data.form, files = data.files, extradata = data.extra, responsedata = data.response;
    fuResponse = responsedata;
    $('.OriginalImage').html('<img src="images/visitors/thumbs/' + fuResponse.FileName + '"  alt="Upload Image" height="80" width="80">');
    $('.dImage').hide();
    $('#myModal').modal('hide');
    $('.OriginalImage').show();
    $('#AddSpecialVisitorInfo').hide();
    //$('#AllHostSH').show();
    updateHostImage(fuResponse.FileName);
    fileNames += fuResponse.FileName + "|";
    var fileNamesString = $("#ImageName").val();
    tmpFileNameAttached += fuResponse.FileName + "|";
    if (fileNamesString != '') {
        $("#ImageName").val(fileNamesString + '|' + fuResponse.FileName);
    }
    else {
        $("#ImageName").val(fuResponse.FileName);
    }
});
$('#stock-input').on('fileuploaderror', function (event, data, previewId, index) {
    var formdata = data.form, files = data.files, extradata = data.extra, responsedata = data.response;
    console.log('File upload error');
});
$('#stock-input').on('filecleared', function (event) {
    var fileNamesString = $("#ImageName").val();
    if (typeof tmpFileNameAttached != 'undefined') {
        var tmpfiles = tmpFileNameAttached.split('undefined').join('');
        tmpfiles = tmpfiles.substring(0, tmpfiles.length - 1);
        var fileNames = fileNamesString.split('|' + tmpfiles).join('');
    }
    $("#ImageName").val(fileNames);
    tmpFileNameAttached = '';
});
