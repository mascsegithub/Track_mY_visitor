<!DOCTYPE html>
<html dir="ltr" lang="en-US">
    <head>

        <meta http-equiv="content-type" content="text/html; charset=utf-8" />
        <meta name="author" content="SemiColonWeb" />
        <!-- Stylesheets
        ============================================= -->
        <link href="http://fonts.googleapis.com/css?family=Lato:300,400,400italic,600,700|Raleway:300,400,500,600,700|Crete+Round:400italic" rel="stylesheet" type="text/css" />
        <link rel="stylesheet" href="css/bootstrap.css" type="text/css" />
        <link rel="stylesheet" href="style.css" type="text/css" />
        <link rel="stylesheet" href="css/dark.css" type="text/css" />
        <link rel="stylesheet" href="css/font-icons.css" type="text/css" />
        <link rel="stylesheet" href="css/animate.css" type="text/css" />
        <link rel="stylesheet" href="css/magnific-popup.css" type="text/css" />
        <link rel="stylesheet" href="css/responsive.css" type="text/css" />
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />

        <link rel="stylesheet" type="text/css" href="css/settings.css" media="screen" />
        <link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon">
        <link rel="icon" href="images/favicon.ico" type="image/x-icon">
        <!--[if lt IE 9]>
            <script src="http://css3-mediaqueries-js.googlecode.com/svn/trunk/css3-mediaqueries.js"></script>
        <![endif]-->
        <!-- Document Title
        ============================================= -->
        <title>Pricing - Track My Visitor</title>
        <?php include('global_variables.php'); ?>
        <script>
<?php include('baseurl.php'); ?>
            var baseUrl = '<?php echo $BaseUrl; ?>';
            //alert(baseUrl);
        </script>

    </head>

    <body class="stretched">
        <!-- Document Wrapper
        ============================================= -->
        <div id="wrapper" class="clearfix">
            <!-- Header
            ============================================= -->
            <?php include('header.php'); ?>
            <!-- #header end -->
            <!-- Content
            ============================================= -->
            <section id="content">

                <div class="">
                    <!--               <div class="content-wrap">-->
                    <div class="container clearfix">
                        <div class="pricing bottommargin clearfix">
                            <div class="promo  promo-center bottommargin">
                                <h3>Try myVisitor for free. Start paying when you're ready.</h3>
                                <span>FULLY-FEATURED FOR 30 DAYS. NO CREDIT CARD REQUIRED. CHOOSE YOUR PLAN LATER</span>
                                <a href="/register.php" class="button button-xlarge button-rounded">Sign Up Now</a>
                            </div>

                            <div class="col-sm-4">

                                <div class="pricing-box">
                                    <div class="pricing-title">
                                        <h3>Free</h3>
                                        <span style="color:#000">Perfect to get a taste of what myVisitor can do for a small office with one site.</span>
                                    </div>
                                    <div class="pricing-price">
                                        <span class="price-unit">$</span>0<span class="price-tenure">/mo</span>
                                    </div>
                                    <div class="pricing-features">
                                        <ul>
                                            <li><strong>Email</strong> Support</li>  
                                            <li><strong>Phone</strong> Support</li>   
                                            <li><strong>Single</strong> Site Only</li>
                                            <li><strong>1 Month</strong> Free</li>
                                            <li class="notavailable"><strong>Unlimited</strong> User</li>
                                            <li class="notavailable"><strong>Multi-Site</strong> Available</li>
                                            <li class="notavailable"><strong>API</strong> Integrations</li>
                                            <li class="notavailable"><strong>Evacuation</strong> Notification</li>
                                            <li class="notavailable"><strong>Custom Logos</strong> and Branding</li>
                                            <li class="notavailable"><strong>Dedicated</strong> Account Rep</li>
                                        </ul>
                                    </div>
                                    <div class="pricing-action">
                                        <a href="/register.php" class="btn btn-danger btn-block btn-lg">Sign Up</a>
                                    </div>
                                </div>

                            </div>

                            <div class="col-sm-4">

                                <div class="pricing-box best-price">
                                    <div class="pricing-title">
                                        <h3>Corporate</h3>
                                        <span style="color:#000">Designed to meet the efficiency & security needs of multi-site businesses.</span>
                                    </div>
                                    <div class="pricing-price">
                                        <span class="price-unit">Contact</span>
                                    </div>
                                    <div class="pricing-features">
                                        <ul>
                                            <li><strong>Email & Phone</strong> Support</li>
                                            <li><strong>SMS & Voice</strong> Support</li>
                                            <li><strong>Multi-Site</strong> Available</li>
                                            <li><strong>Unlimited</strong> User</li>
                                            <li><strong>API</strong> Integrations</li>
                                            <li><strong>Visitor Image</strong> Capture</li>
                                            <li><strong>Custom Logos</strong> and Branding</li>
                                            <li><strong>Evacuation</strong> Notification</li>
                                            <li>Support for<strong> Additional Languages</strong></li>
                                            <li class="notavailable"><strong>Dedicated</strong> Account Rep</li>
                                        </ul>
                                    </div>
                                    <div class="pricing-action">
                                        <a href="/register.php" class="btn btn-danger btn-block btn-lg bgcolor border-color">Sign Up</a>
                                    </div>
                                </div>

                            </div>

                            <div class="col-sm-4">

                                <div class="pricing-box">
                                    <div class="pricing-title">
                                        <h3>Enterprise</h3>
                                        <span style="color:#000">A custom-made solution tailored to the needs and conditions of your enterprise.</span>
                                    </div>
                                    <div class="pricing-price">
                                        <span class="price-unit">Contact</span>
                                    </div>
                                    <div class="pricing-features">
                                        <ul>
                                            <li><strong>Dedicated</strong> Account Rep</li>
                                            <li><strong>Email & Phone</strong> Support</li>
                                            <li><strong>SMS & Voice</strong> Support</li>
                                            <li><strong>Multi-Site</strong> Available</li>
                                            <li><strong>Unlimited</strong> User</li>
                                            <li><strong>API</strong> Integrations</li>
                                            <li><strong>Visitor Image</strong> Capture</li>
                                            <li><strong>Custom Logos</strong> and Branding</li>
                                            <li><strong>Evacuation</strong> Notification</li>
                                            <li>Support for<strong> Additional Languages</strong></li>
                                        </ul>
                                    </div>
                                    <div class="pricing-action">
                                        <a href="/register.php" class="btn btn-danger btn-block btn-lg">Sign Up</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div>
                            <div class="promo promo-center bottommargin">
                                <h3>Not sure which plan fits you best?</h3>
                                <span>Take a look at the extensive feature list for a more detailed breakdown.</span>
                                <a href="/register.php" class="button button-xlarge button-rounded">Sign Up Now</a>
                            </div>
                        </div>
                        <div class="pricing bottommargin clearfix">
                            <div class="col-sm-4">

                                <div class="feature-box fbox-effect">
                                    <div class="fbox-icon">
                                        <a href="#"><i class="icon-lock3"></i></a>
                                    </div>
                                    <h3>100% Scalable & Secure</h3>
                                    <p>Our platform was built with the intent to grow and adapt to ever-changing security measures.</p>
                                </div>

                            </div>
                            <div class="col-sm-4">
                                <div class="feature-box fbox-effect">
                                    <div class="fbox-icon">
                                        <a href="#"><i class="icon-plane"></i></a>
                                    </div>
                                    <h3>Robust Features & Functionality</h3>
                                    <p>Enjoy the benefits of a custom-feeling,form fitted platform without the development costs.</p>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="feature-box fbox-effect">
                                    <div class="fbox-icon">
                                        <a href="#"><i class="icon-large icon-time"></i></a>
                                    </div>
                                    <h3>Fast & Friendly Support</h3>
                                    <p>We're here when you need us throughout the entire process - it's in our best interest too!</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section><!-- #content end -->
            <div style="" class="promo promo-dark promo-flat promo-full">
                <div class="container clearfix">
                    <h3>Learn how myVisitor can help you make your business safer and more efficient.</h3>
                    <a href="/register.php" class="button button-xlarge button-rounded">Get Started</a>
                </div>
            </div>
            <!-- Footer
            ============================================= -->
            <?php include('footer.php'); ?>

        </div><!-- #wrapper end -->

        <!-- Go To Top
        ============================================= -->
        <div id="gotoTop" class="icon-angle-up"></div>

        <!-- Footer Scripts
        ============================================= -->
        <script type="text/javascript" src="js/jquery.js"></script>
        <script type="text/javascript" src="js/plugins.js"></script>	
        <script type="text/javascript" src="js/functions.js"></script>

        <script type="text/javascript">
            $("#widget-subscribe-form").validate({
                submitHandler: function (form) {
                    $(form).find('.input-group-addon').find('.icon-email2').removeClass('icon-email2').addClass('icon-line-loader icon-spin');
                    $(form).ajaxSubmit({
                        target: '#widget-subscribe-form-result',
                        success: function () {
                            $(form).find('.input-group-addon').find('.icon-line-loader').removeClass('icon-line-loader icon-spin').addClass('icon-email2');
                            $('#widget-subscribe-form').find('.form-control').val('');
                            $('#widget-subscribe-form-result').attr('data-notify-msg', $('#widget-subscribe-form-result').html()).html('');
                            SEMICOLON.widget.notifications($('#widget-subscribe-form-result'));
                        }
                    });
                }
            });
        </script>
        <style>
            .pricing-price {
                color: #333;
                font-size: 64px;
                font-weight: 300;
                line-height: 1;
                padding: 0px 0;
                position: relative;
            }
            .notavailable{
                text-decoration: line-through;
            }
        </style>

    </body>
</html>