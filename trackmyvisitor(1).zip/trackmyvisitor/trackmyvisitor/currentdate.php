<?php 
//Current date
function Currentdate($dateformat) {
	date_default_timezone_set('Asia/Dhaka');
	//date_default_timezone_set('UTC');
	$date = date($dateformat);
	return $date;
}
?>