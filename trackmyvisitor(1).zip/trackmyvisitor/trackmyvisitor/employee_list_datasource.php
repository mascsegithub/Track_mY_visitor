<?php

include ("define.inc");
$conn = mysql_connect(HOSTNAME, DBUSER, DBPWD) or die('Could not connect: ' . mysql_error());
mysql_select_db(DBNAME, $conn) or die('Could not connect: ' . mysql_error());
mysql_query('SET CHARACTER SET utf8');

//ImageNames

$Activation = $_POST['IsActive'];
$FirstName = $_POST['FirstName'];
$LastName = $_POST['LastName'];
$UserName = $_POST['UserName'];
$FullName = $_POST['FullName'];
$EmailAddress = $_POST['EmailAddress'];
$JobTitle = $_POST['JobTitle'];
$MobileNo = $_POST['MobileNo'];
$DeskPhoneNo = $_POST['DeskPhoneNo'];
$DivisionId = $_POST['DivisionId'];
$SendEmail = $_POST['SendEmail'];
$ImageNames = $_POST['ImageName'];
$Password = $_POST['Password'];


;


$Password = md5($Password);


$sql = "INSERT INTO t_employee (FirstName,lastName,UserName,FullName,EmailAddress,JobTitle,MobileNo,DeskPhoneNo,DivisionId,SendEmail,EmployeeImage,Password)
VALUES ('" . $FirstName . "', '" . $LastName . "', '" . $UserName . "', '" . $FullName . "', '" . $EmailAddress . "', '" . $JobTitle . "', '" . $MobileNo . "', '" . $DeskPhoneNo . "', '" . $DivisionId . "', '" . $SendEmail . "', '" . $ImageNames . "', '" . $Password . "')";

$retval = mysql_query($sql, $conn);
if (!$retval) {
    die('Could not enter data: ' . mysql_error());
}
//header("Location:/trackmyvisitor/employee_list.php"); /* Redirect browser */
//exit();
//echo "Entered data successfully\n";http://softworks22/trackmyvisitor/employee_list.php 
mysql_close($conn);
?>