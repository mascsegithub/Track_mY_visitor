<!DOCTYPE html>
<html dir="ltr" lang="en-US">
    <head>
        <meta http-equiv="content-type" content="text/html; charset=utf-8" />
        <meta name="author" content="SemiColonWeb" />
        <!-- Stylesheets
        ============================================= -->
        <link href="http://fonts.googleapis.com/css?family=Lato:300,400,400italic,600,700|Raleway:300,400,500,600,700|Crete+Round:400italic" rel="stylesheet" type="text/css" />
        <link rel="stylesheet" href="css/bootstrap.css" type="text/css" />
        <link rel="stylesheet" href="style.css" type="text/css" />
        <link rel="stylesheet" href="css/dark.css" type="text/css" />
        <link rel="stylesheet" href="css/font-icons.css" type="text/css" />
        <link rel="stylesheet" href="css/animate.css" type="text/css" />
        <link rel="stylesheet" href="css/magnific-popup.css" type="text/css" />

        <link rel="stylesheet" href="css/responsive.css" type="text/css" />
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
		<link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon">
		<link rel="icon" href="images/favicon.ico" type="image/x-icon">
        <!--[if lt IE 9]>
            <script src="http://css3-mediaqueries-js.googlecode.com/svn/trunk/css3-mediaqueries.js"></script>
        <![endif]-->

        <!-- External JavaScripts
        ============================================= -->
        <script type="text/javascript" src="js/jquery.js"></script>
        <script type="text/javascript" src="js/plugins.js"></script>

        <!-- Document Title
        ============================================= -->
        <title>Home - Track My Visitor</title>
		<?php include('global_variables.php'); ?>

    </head>

    <body class="stretched">
        <!-- Document Wrapper
        ============================================= -->
        <div id="wrapper" class="clearfix">
            <!-- Header
            ============================================= -->
            <?php include('header.php'); ?>
            <!-- #header end -->
            <!-- Content
            ============================================= -->
            <section id="content">
                <div class="content-wrap">
                    <div class="container clearfix">

                        <?php
                        //set it to writable location, a place for temp generated PNG files
                        $PNG_TEMP_DIR = dirname(__FILE__) . DIRECTORY_SEPARATOR . 'qr_code_generate/temp' . DIRECTORY_SEPARATOR;

                        //html PNG location prefix
                        $PNG_WEB_DIR = 'qr_code_generate/temp/';

                        include "qr_code_generate/qrlib.php";

                        //ofcourse we need rights to create temp dir
                        if (!file_exists($PNG_TEMP_DIR))
                            mkdir($PNG_TEMP_DIR);


                        $filename = $PNG_TEMP_DIR . 'test.png';

                        //processing form input
                        //remember to sanitize user input in real-life solution !!!
                        $errorCorrectionLevel = 'L';
                        if (isset($_REQUEST['level']) && in_array($_REQUEST['level'], array('L', 'M', 'Q', 'H')))
                            $errorCorrectionLevel = $_REQUEST['level'];

                        $matrixPointSize = 4;
                        if (isset($_REQUEST['size']))
                            $matrixPointSize = min(max((int) $_REQUEST['size'], 1), 10);


                        if (isset($_REQUEST['SpecialVisitorId'])) {

                            //it's very important!
                            if (trim($_REQUEST['SpecialVisitorId']) == '')
                                die('data cannot be empty! <a href="?">back</a>');

                            // user data
                            $filename = $PNG_TEMP_DIR . 'test' . md5($_REQUEST['EmailAddress'] . '|' . $errorCorrectionLevel . '|' . $matrixPointSize) . '.png';
                            QRcode::png('Special Visitor Id:' . $_REQUEST['SpecialVisitorId'] . '\nEmployee Name:' . $_REQUEST['EmployeeName'] . '<pre>Company Name:' . $_REQUEST['CompanyName'] . '<pre>Email Address:' . $_REQUEST['EmailAddress'] . '<pre>Mobile No:' . $_REQUEST['MobileNo'] . '<pre>Employee Id:' . $_REQUEST['EmployeeId'], $filename, $errorCorrectionLevel, $matrixPointSize, 2);
                        } else {

                            //default data    
                            QRcode::png('PHP QR Code :)', $filename, $errorCorrectionLevel, $matrixPointSize, 2);
                        }

                        echo '<div class="row">
						  <div class="col-md-6">
                                <form class="nobottommargin" action="qr_code_generate.php" method="post">
                                    <div class="col_full">
                                        <label for="SpecialVisitorId">Special Visitor Id:</label>
                                        <input type="text" name="SpecialVisitorId" value="' . (isset($_REQUEST['SpecialVisitorId']) ? htmlspecialchars($_REQUEST['SpecialVisitorId']) : '') . '" class="form-control" />
                                    </div>

                                    <div class="col_full">
                                        <label for="EmployeeName">Name:</label>
                                        <input type="text" name="EmployeeName" value="' . (isset($_REQUEST['EmployeeName']) ? htmlspecialchars($_REQUEST['EmployeeName']) : '') . '" class="form-control" />
                                    </div>
                                    <div class="col_full">
                                        <label for="CompanyName">Company:</label>
                                        <input type="text" name="CompanyName" value="' . (isset($_REQUEST['CompanyName']) ? htmlspecialchars($_REQUEST['CompanyName']) : '') . '" class="form-control" />
                                    </div>
                                    <div class="col_full">
                                        <label for="EmailAddress">Email:</label>
                                        <input type="text" name="EmailAddress" value="' . (isset($_REQUEST['EmailAddress']) ? htmlspecialchars($_REQUEST['EmailAddress']) : '') . '" class="form-control" />
                                    </div>
                                    <div class="col_full">
                                        <label for="MobileNo">Phone:</label>
                                        <input type="text" name="MobileNo" value="' . (isset($_REQUEST['MobileNo']) ? htmlspecialchars($_REQUEST['MobileNo']) : '') . '" class="form-control" />
                                    </div>
                                    <div class="col_full">
                                        <label for="EmployeeId">Employee Id:</label>
                                        <input type="text" name="EmployeeId" value="' . (isset($_REQUEST['EmployeeId']) ? htmlspecialchars($_REQUEST['EmployeeId']) : '') . '" class="form-control" />
                                    </div>
                                
						  </div>
						  <div class="col-md-6">';
                        //display generated file
                        echo '<img src="' . $PNG_WEB_DIR . basename($filename) . '" />';
                        echo '</div>
						</div>';

                        echo '<div class="row">';

                        echo '<div class="col-md-2"><select class="form-control" name="level">
								<option value="L"' . (($errorCorrectionLevel == 'L') ? ' selected' : '') . '>L - smallest</option>
								<option value="M"' . (($errorCorrectionLevel == 'M') ? ' selected' : '') . '>M</option>
								<option value="Q"' . (($errorCorrectionLevel == 'Q') ? ' selected' : '') . '>Q</option>
								<option value="H"' . (($errorCorrectionLevel == 'H') ? ' selected' : '') . '>H - best</option>
							</select></div>';

                        echo '<div class="col-md-1"><select class="form-control" name="size">';
                        for ($i = 1; $i <= 10; $i++)
                            echo '<option value="' . $i . '"' . (($matrixPointSize == $i) ? ' selected' : '') . '>' . $i . '</option>';
                        echo '</select></div>';

                        echo '<div class="col-md-9">
								<input class="button button-3d button-green nomargin" type="submit" value="GENERATE">
								</form>
								<button class="button button-3d button-yellow nomargin" >Print</button>
							</div>';

                        echo '</div>';
                        // benchmark
                        QRtools::timeBenchmark();
                        ?>


                    </div>

                </div>

            </section><!-- #content end -->

            <!-- Footer
            ============================================= -->
            <?php include('footer.php'); ?>
            <!-- #footer end -->

        </div><!-- #wrapper end -->

        <!-- Go To Top
        ============================================= -->
        <div id="gotoTop" class="icon-angle-up"></div>

        <!-- Footer Scripts
        ============================================= -->
        <script type="text/javascript" src="js/functions.js"></script>

    </body>
</html>