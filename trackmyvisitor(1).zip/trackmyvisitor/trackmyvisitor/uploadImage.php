<?php

$chunk = isset($_REQUEST["chunk"]) ? intval($_REQUEST["chunk"]) : 0;
$chunks = isset($_REQUEST["chunks"]) ? intval($_REQUEST["chunks"]) : 0;

if (!empty($_FILES['stock-input-file']['name'])) {
    $upload_img = generate_thumb_now('stock-input-file', 'images/visitors/', '', TRUE, 'images/visitors/thumbs/', '80', '100');

    //full path of the thumbnail image
    //$thumb_src = 'uploads/thumbs/' . $upload_img;
    //set success and error messages
    //$message = $upload_img?"<span style='color:#008000;'>Image thumbnail created successfully.</span>":"<span style='color:#F00000;'>Some error occurred, please try again.</span>";
} else {
    $thumb_src = '';
    $message = '';
}

function generate_thumb_now($field_name = '', $target_folder = '', $file_name = '', $thumb = FALSE, $thumb_folder = '', $thumb_width = '', $thumb_height = '') {
    //folder path setup
    $target_path = $target_folder;
    $thumb_path = $thumb_folder;
    //file name setup
    $filename_err = explode(".", $_FILES[$field_name]['name']);
    $filename_err_count = count($filename_err);
    $file_ext = $filename_err[$filename_err_count - 1];
    if ($file_name != '') {
        $fileName = $file_name . '.' . $file_ext;
    } else {
        $fileName = $_FILES[$field_name]['name'];
    }
    //upload image path
    $upload_image = $target_path . basename($fileName);
    //upload image
    if (move_uploaded_file($_FILES[$field_name]['tmp_name'], $upload_image)) {
        //thumbnail creation
        if ($thumb == TRUE) {
            $thumbnail = $thumb_path . $fileName;
            list($width, $height) = getimagesize($upload_image);
            $thumb_create = imagecreatetruecolor($thumb_width, $thumb_height);
            switch ($file_ext) {
                case 'jpg':
                    $source = imagecreatefromjpeg($upload_image);
                    break;
                case 'jpeg':
                    $source = imagecreatefromjpeg($upload_image);
                    break;
                case 'png':
                    $source = imagecreatefrompng($upload_image);
                    break;
                case 'gif':
                    $source = imagecreatefromgif($upload_image);
                    break;
                default:
                    $source = imagecreatefromjpeg($upload_image);
            }
			
			  // preserve transparency
			  if($file_ext == "gif" or $file_ext == "png"){
				imagecolortransparent($thumb_create, imagecolorallocatealpha($thumb_create, 255, 255, 255, 127));
				imagealphablending($thumb_create, true);
				imagesavealpha($thumb_create, true);
				$white = imagecolorallocate($thumb_create, 255, 255, 255);
				imagefill($thumb_create, 0, 0, $white); 
			  }
			
            imagecopyresized($thumb_create, $source, 0, 0, 0, 0, $thumb_width, $thumb_height, $width, $height);
            switch ($file_ext) {
                case 'jpg' || 'jpeg':
                    imagejpeg($thumb_create, $thumbnail, 100);
                    break;
                case 'png':
                    imagepng($thumb_create, $thumbnail, 100);
                    break;
                case 'gif':
                    imagegif($thumb_create, $thumbnail, 100);
                    break;
                default:
                    imagejpeg($thumb_create, $thumbnail, 100);
            }
        }
        //return $fileName;
        $arr["success"] = TRUE;
        $arr["DirName"] = "images/visitors/thumbs/";
        $arr["FileName"] = $fileName;
        echo json_encode($arr);
    } else {
        return false;
    }
}

?>