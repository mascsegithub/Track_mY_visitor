
var $ = jQuery.noConflict();

function resetForm(id) {
	$('#' + id).each(function() {
		this.reset();
	});
}

function validateEmail(email) {
    var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return re.test(email);
}

function onConfirmWhenRegister() {

    var Email = $("#EmailAddress").val();
    var error = 0;
    if (Email == '') {
        $("#invalidEmail").html('Please enter your email address');
        error = 1;
    }else if (!validateEmail(Email)) {
        $("#invalidEmail").html('Please enter valid email address');
        error = 1;
    }else {
        $("#invalidEmail").html('');
    }

    if (error == 1) {
        return false;
    }
    else {
    $.ajax({
        "async": true,
        url: baseUrl + "forgot-password-send-mail",
        "method": "POST",
        "data": $('#forgot-password-form').serialize(),
        success: function (response){
			if(response['error'] == 0){
				resetForm("forgot-password-form");
				$("#registerformsuccess").show();
				$("#registerform").hide();
				$("#validEmail").html(response['mailaddress']);
				
			}else if(response['error'] == 1){				
				$("#registerform").show();
				$("#registerformsuccess").hide();
				$("#invalidEmail").html(response['message']);
			}else{				
				$("#registerform").show();
				$("#registerformsuccess").hide();
				//$("#invalidEmail").html(response['message']);
			}
        }
    });
   }
}

$(function () {
    $('#forgot-password-form').submit(function () {
        onConfirmWhenRegister();
        return false;
    });

});
